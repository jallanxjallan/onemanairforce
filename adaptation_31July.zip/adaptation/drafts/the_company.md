The last memory was Muharto taking Tom Lee for a meal, and insisting he pay, over Tom's strenuous suggestions.  

In the present day, Budi jokes to Muharto about the “company" expense account. Muharto jokes that he might be right. as he visited Tom years later and found his wife driving a luxury convertible. Cameron admires the Affandi collection. Boedi suggests he go to the museum if in Jogja. 

After finally being paid for the quinine, Bob pays his bills and sends money home to buy an Oldsmobile for his parents. Muharto invites Tom Lee for dinner to pay him back for all of his generosity. Boedi tells him not to bother, as he is sure that all the drinks and dinner of last August was “on the company expense account”