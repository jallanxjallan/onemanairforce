---
identifier: 861d5036
title: Visiting Mbah Marijan
date: October 1988 
location: Merapi
---

``` {.synopsis}
Cameron accompanies Muharto to a village on the upper slopes of the
Merapi volcano to meet Muharto’s spiritual advisor, Mbah Maridjan. The
three hike the steep incline to a shrine, effortlessly in the case of
the sexagenarian duo, but with some difficulty by their companion, some
four decades their junior. Cameron watches respectfully as the two
intone Islamic prayers, then lay Hindu-style floral offerings at the
shrine to the gods of the fire mountain.
```

Cameron accompanies Muharto to a village on the upper slopes of the
Merapi volcano, to meet Muharto's spiritual advisor, Mbah Maridjan. The
three hike the steep incline to a shrine, effortlessly in the case of
the sexagenarian duo of Muharto and Maridjan, but with some difficulty
by their companion, some four decades their junior. Cameron watches
respectfully as the two intone Islamic prayers, then lay Hindu-style
floral offering at the shrine to the gods of the mountain.
