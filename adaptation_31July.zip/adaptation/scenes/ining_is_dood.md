---
identifier: 5c48e16a
title: Ining Is Dood
date: December 1947 
location: RI-002
---

``` {.treatment}
During a routine radio contact with Jogja, Boedi is told that Ining and Mas Ded were found dead of gunshot wounds at Ining's house. Muharto reports the incident to Major Primitivo, who accuses Muharto of being a communist and Mas Ded being complicit in Ining ’s death. 
```
