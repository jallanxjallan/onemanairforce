---
identifier: ffa4186f
title: Muharto Writes Letters
date: 28 September 1988 
location: Muhartos living room
---

``` {.treatment}
Muharto explains that he became aware of the discovery of the crash
site, wholly by accident, some five years previously. He wrote to his contacts
in the Air Force and to the officers who participated in the crash-site
investigation, but received vague, non-committal replies --- or only
silence. 
```
