---
identifier: e6f52dcc
title: Syd Edits Cameron
date: 29 September 1988 
location: JakPost
---

``` {.synopsis}
Syd Jardine, a burnt-out Old Asia Hand who is senior copy editor for the Jakarta Post, tells Cameron that his story on Bob Freeberg needs more historical context, and suggests he do additional research at the new National Library, a modern, well-run institution that he visits regularly.
```

In the Jakarta Post newsroom, Cameron finishes the first draft of the
Muharto interview, then hands it to Syd Jardine, a disheveled,
chain-smoking, older American sitting at the adjacent desk. After
reading it, Syd tells Cameron that the article is good, but a bit thin,
and needs more context to be understandable to the Post's foreign
readership. Syd suggests Cameron go to the national library and read the
book *Recruit to Revolution*, which has a chapter on Freeberg, and all
the historical background Cameron needs.
