---
identifier: 779db19d
title: Smuggled Gems
date: April 1948 
location: Manila Airport
---

``` {.treatment}
Filipino commandos enter RI-002 and open a compartment under the floorboard of the flight deck, taking out a bag of gems. But they hear the approach of a guard, and hurry out, leaving the hatch cover slightly ajar. 
```

Muharto and Boedi report to Jogja on the RI-002 radio, then Muharto is
the last to leave RI-002. Boedi goes on ahead, Muharto stops to talk
with a Philippines army officer waiting in the hanger. Some time later,
when all the lights around the hangar have been extinguished, the
officer enters RI-002 and emerges a short time later with a small
package in his hand.

Major Primitivo Muharto and Boedi report to Jogja on the RI-002 radio,
then is the last to leave RI-002. Boedi goes on ahead, Muharto stops to
talk with a Philippines army officer waiting in the hanger. Some time
later, when all the lights around the hangar have been extinguished, the
officer enters RI-002 and emerges a short time later with a small
package in his hand.
