---
identifier: a434873d
title: Fighter Planes Tailing Him
date: September 1948 
location: Hotel Merkeka
---

``` {.treatment}
While flying a group of international journalists to Jogja under cover of darkness, Fowler believes he spots fighter planes tailing him while his radio operator hears traffic on Dutch military frequencies. When he looks again, the fighters are gone. 
```
