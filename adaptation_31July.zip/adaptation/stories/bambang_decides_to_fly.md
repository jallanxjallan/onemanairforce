---
identifier: ee5dbecf
title: Bambang Decides To Fly
date:  
location: 
---

11. Bambang decides to fly RI-002 back to Jogja, but crashes on Mount
    Punggur.
