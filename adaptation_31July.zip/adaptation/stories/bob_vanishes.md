---
identifier: 8628025d
title: RI-002 Vanishes
date: 28 September 1988 
location: Muharto
---

``` {.synopsis}
Muharto tells Cameron that he flew with RI-002 until May 1948, when he was promoted to Major and assigned to a desk at headquarters. He saw little of Bob after that, but was looking forward to having Bob as guest of honor at his wedding in October. But three weeks before the wedding he was devasted to learn that RI-002 had vanished on a mission.  
```

Muharto tells Cameron that in May 1948 he was promoted to Major and
assigned administrative duties in Air Force headquarters. Thus, he was
not able to accompany RI-002 on another crucial mission, carrying
President Soekarno, who called Bob "our American friend", on a
month-long morale- and fund-raising tour of Republican areas. But they
had kept in contact, and Muharto looked forward to Bob attending his
wedding on 24 October. Then, on 2 October 1948, Muharto learned that
RI-002 had vanished while transporting a ton of Republican gold from
Java to Sumatra. Muharto explains that nothing was known of the crash,
and the Dutch authorities denied all knowledge. In April 1979, Muharto
says, farmers searching the remote mountainside for arable land stumble
across aircraft wreckage. Muharto shows Cameron photographs taken by Air
Force field investigators.

Seven weeks before Bob was to be guest of honor at Muharto's wedding,
RI-002 vanished while transporting a quarter ton of gold to safety in
Bukittinggi. Muharto explains that nothing was known of the crash, and
the Dutch authorities denied all knowledge. In April 1979, Muharto says,
farmers searching the remote mountainside for new land stumble across
the wreckage of an aircraft.
