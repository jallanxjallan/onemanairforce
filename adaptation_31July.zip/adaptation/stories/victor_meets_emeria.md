---
identifier: 29b855de
title: Victor Meets Emeria
date:  
location: 
---

4.  Victor meets Emeria at her studio.
