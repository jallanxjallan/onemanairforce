---
identifier: b2d12a19
title: Ining Is Training Guerrillas
date:  
location: 
---

5.  Spoor learns Ining is training guerrillas.
