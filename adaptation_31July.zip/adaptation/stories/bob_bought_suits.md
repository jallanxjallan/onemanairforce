---
identifier: 9596f6a0
title: Bob Bought Suits
date:  
location: 
---

Bob finally bought new suits, as well as the Olds for his parents. After
purchasing the supplies ordered by Suryadarma, Muharto and Boedi shopped
for clothes for their fellow officers.
