---
identifier: 2cd51520
title: Sabam Praises Cameron
date: 3 October 1988 
location: JakPost
---

``` {.synopsis}
The day the story about Bob Freeberg appears, Sabam berates Syd for sneaking an amusing tone-perfect translation of a lurid sex-crime story from a local paper into the Post. He then praises Cameron for the Muharto story, saying that his old friend was delighted. When Sabam leaves, Cameron turns to Syd and says he is intrigued by the story, and wants to return to the Library for further research. With a smile and  a wink, Syd tells Cameron to give his regards to Julia. 
```

Sabam strides into the newsroom, brandishing a copy of the paper, and
approaches a disheveled, chain-smoking older American sitting at the
desk adjacent to Cameron. Sabam points to an article headlined "Ladyboy
Molested By Sex-Crazed Gang", and says: "This is a family newspaper!".

Sabam then turns to Cameron, still holding the paper, and points to
another page with a photo of Bob Freeberg. He says that Muharto was
delighted with the article. Cameron agrees that was an intriguing story,
and says he would like to do some follow-up research. Sabam nods in
agreement, saying "On your own time, of course" and suggests he start
with a book he had recently stumbled across in the reference section of
the new national library. He writes the name of the book in the margin
of the paper in his hand, leaves it on Cameron's desk, and returns to
his office.

Cameron picks of a copy of the newspaper on his desk, turns a page, and
reads aloud: "And then the rapists took their turns to quench their
unnatural desires with the body of the hapless transvestite
hairdresser." The article carries the byline: "Our Reporter". Cameron
asks the American, Syd, how he gets away with it. Syd replies that he
and Sabam go way back. Sabam's biggest worry is that Cameron or another
foreign copy editors are not sufficiently familiar with the fine points
of Indonesian culture and history, and will let something slip through
that will rile some high official. Sabam relies on Syd as the last pair
of eyes before it all goes to press.

"Doing proper journalism in Indonesia is like walking a tightrope," Syd
says, "and I'm the safety net." Syd then turns away and takes a metal
flask from his desk drawer. There is a slight tremor in his hand as he
pours a splash from the flask into his coffee, replaces the flask in his
desk, and goes back to work.

Sabam storms out of his office, slams a copy of the paper in front of
Syd. He points to the headline: **Ladyboy Molested By Sex-Crazed**
**Gang**, and shouts: "This is a family newspaper!"

Sabam then turns to Cameron, now calm and composed, and says that
Muharto was delighted with the article about Freeberg and RI-002.
Cameron thanks Sabam for the praise, and says that he would like to do
more research into the story as a basis for a grad-school paper when he
returns home. Sabam agrees it would be an interesting and challenging
research topic, and wishes him luck. As he returns to his office, Sabam
turns back to Cameron and says: "On your own time, course. And don't
involve The Jakarta Post. You don't have a research permit so keep it
quiet."

After Sabam returns to his office, Syd tells Cameron that Sabam is
right. The government does not like journalists or academics reexamining
the past. If the fate of Bob Freeberg remains a mystery, they must think
it is for good reason, perhaps to avoid questions about what might have
happened to the gold.
