---
identifier: 179fa8fd
title: SE Air Bankrupt
date:  
location: 
---

16. On his final trip to Singapore, Bob learns that Hugh Savage has
    filed for bankruptcy of Southeast Airlines.
