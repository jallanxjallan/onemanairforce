---
identifier: 62c4038f
title: Recruit to Revolution
date: February 1948 
location: HotBuk
---

``` {.synopsis}
In *Recruit to Revolution*, John Coast describes Freeberg as “America’s Best Ambassador” after their first meeting. Nevertheless, he notes that American officials in Batavia, who wanted Indonesia to remain in Dutch hands, disapproved of his activities. 
```

experiences as a diplomatic consultant. He advised both Soekarno and
Hatta, and talked to American diplomats at length about the situation.
His conversations indicated that many Americans were sympathetic to the
Indonesian struggle, but the American government itself preferred that
the archipelago remain in Dutch hands for the time being as a bulwark
against encroaching communist influence from the north.

Coast also remarks on his encounters with Bob Freeberg. He found him to
be enigmatic, though modest and seemingly decent. He described Freeberg
as .
