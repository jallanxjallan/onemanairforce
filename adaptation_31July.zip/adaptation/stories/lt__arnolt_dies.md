---
identifier: 2e95cef3
title: Lt Arnolt dies
date:  
location: 
---

11. The mysterious death of KNIL Lt Arnolt prompts Spoor to investigate
    rumors of corruption in the military.
