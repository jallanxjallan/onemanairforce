---
identifier: ee759edf
title: Bambang Saptoadji Messes Landing
date:  
location: 
---

2.  Bambang Saptoadji messes up a landing during an air show in Bandung,
    severely damaging one of the Republic's few serviceable aircraft.
