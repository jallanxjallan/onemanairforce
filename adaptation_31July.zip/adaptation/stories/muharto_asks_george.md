---
identifier: 6f272f29
title: Muharto Asks George
date:  
location: 
---

5.  Muharto asks George to keep Ining company in Muharto's absence.
    George witnesses Ining berate the young recruits and sees the
    displeasure on their faces. Back in the house, Ining asks George to
    bring whiskey next time he visits.
