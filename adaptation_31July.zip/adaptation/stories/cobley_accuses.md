---
identifier: 714c97b5
title: Cobley Accuses
date:  
location: 
---

2.  Cobley accuses Bob of monopolizing Republican missions. Says he is
    taking the best business for himself, especially since he is now
    ârunning narcoticsâ.
