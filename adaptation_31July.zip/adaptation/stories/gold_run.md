---
identifier: a43756ac
title: Gold Run
date:  
location: 
---

17. Suryadarma assigns Bob mission to transport gold to Bukittinggi
