---
identifier: b04274fa
title: Syd Warns Cameron
date: October 1988 
location: JakPost
---

``` {.synopsis}
The stories from the Dutch side of RI-002 story fires Camerons's curiosity. Cameron tells Sabam that he would like to do more research into the story as a basis for a grad-school paper when he returns home. Sabam wishes him luck, but tells Cameron to do it on his own time and do not involve the Jakarta Post. Syd tells Cameron that Sabam is right. The government does not like journalists or academics reexamining the past. If the fate of Bob Freeberg remains a mystery, they must think it is for good reason, perhaps to avoid questions about what might have happened to the gold. 
```
