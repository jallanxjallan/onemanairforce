---
identifier: daa34499
title: Muharto Appalled
date: April 1948 
location: Manila
---

``` {.treatment}
At a party in Manila, Muharto is appalled when one of Bob's housemates
boasts of shooting down own squad leader. He decides to not tell Bob of his plan to smuggle gems into Manila to be traded for sidearms. 
```

At a party in Manila, Muharto is appalled when one of Bob's housemates
boasts of shooting down his own squad leader during the war in Europe.
He tells Boedi that he doesn't think Bob's friends are entirely *bona
fide*, and worries what might happen if Bob tells them.

Boedi not to mention the gem smuggling to Bob, who might tell the
roommate. that he will not tell and other general debauchery. He decides
to not tell Freeberg about the smuggled gems in case his roommates find
out.
