---
identifier: c9c3f25b
title: Madras Curry
date: August 1947 
location: Madras
---

``` {.synopsis}
As they wait for a buyer for the quinine Muharto, Boedi, and Pang eat one meal a day at a Indian restaurant. On most days Bob joins them and pays for all, inisting that he is responsible for their well-being until he returns them to Java.
```
