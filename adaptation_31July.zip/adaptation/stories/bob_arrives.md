---
identifier: 5d85bb7d
title: Bob Arrives
date:  
location: 
---

1.  Bob arrives in Manila in July 1946. He immediately is hired by CALI
    as a charter pilot.
