---
identifier: 27d0fa94
title: Ani Berates Westerling
date:  
location: 
---

8.  Ani berates Westerling when he and Muharto and stopped and searched
    on the evening of Operation Crow.
