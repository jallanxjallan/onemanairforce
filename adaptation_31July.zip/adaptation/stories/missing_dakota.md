---
identifier: ce60a9c7
title: Missing Dakota
date:  
location: 
---

6.  Bob returns to Manila from the CALi run to Jogja and discovers that
    the jointly owned Dakota is missing.
