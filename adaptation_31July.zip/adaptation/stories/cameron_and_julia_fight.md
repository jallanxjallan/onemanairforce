---
identifier: 37cb8762
title: Julia goes ballistic
date: November 1988 
location: Tanamur Back Bar
---

``` {.treatment}
Cameron and Julia argue over their interpretations of the research. 
```
