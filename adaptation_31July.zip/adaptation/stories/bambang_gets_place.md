---
identifier: 9ecdf448
title: Bambang Gets Place
date:  
location: 
---

8.  With the reassignment of Muharto to headquarters, Bambang gets his
    coveted permanent place in the right-hand seat.
