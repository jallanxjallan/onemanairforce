---
identifier: 33187a77
title: Bob Defies Suryadarma
date:  
location: 
---

12. Bob defies Suryadarma. Immediately after returning from the Soekarno
    Tour, Suryadarma orders Bob to Sumatra on another mission. Bob
    flatly refuses.
