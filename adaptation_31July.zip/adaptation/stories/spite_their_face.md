---
identifier: ecd45354
title: Spite Their Face
date: September 1948 
location: Hotel Merdeka
---

``` {.treatment}
Over whiskey with Fowler, Muharto, and Boedi at Hotel Merdeka, Bob complains about Suryadarma and some of his staff, saying they want this or that but never follow through. He says that many Indonesians (present company excepted) would cut off their nose to spite their face.
```
