---
identifier: f040b2de
title: Spoor takes command
date:  
location: 
---

1.  Spoor relocates from Australia to Batavia and takes command of KNIL.
    He hires Julius Tahija as his adjutant.
