---
identifier: 2271d892
title: Julia Meets Cameron
date: 5 October 1988 
location: library
---

``` {.synopsis}
Over coffee in the library canteen. Julia tells Cameron that she is in her final year of university, and hopes to get a scholarship to do her post-grad overseas. In the meantime, she was hired by the library because of her fluency in written English and Dutch. Julia also casually mentions that her father is a general.
```

He asks Julia where he can get some coffee. No liquids are allowed the
reading room, so Julia says she was just about to take a break herself,
and invites Cameron to join her in the canteen. As Cameron drinks his
coffee and Julia her tea, After two hours Cameron asks if he can get
some coffee. Julia says that no food or beverages are allowed in the
reading room, and offers to escort him to the library canteen. They chat
over coffee, Julia tells Cameron that she is in her final year, and is
doing her undergrad thesis, She is hoping for a scholarship to study
overseas. In the meantime, because of her fluency in both Dutch and
English, Julia has been hired to help organize the publications
collection of the new national library. Julia casually mentions that her
father, who is a general in Army Intelligence, probably knows all about
him, to Cameron's consternation.

Julia asks Cameron about how he likes living in Indonesia. Cameron
replies that he loves it, except for one annoying habit. Indonesians
always ask how old he is, where he is from, and whether he is married.
Cameron says that this is too personal to discuss with some random
stranger. Julia replies that Indonesians consider such inquiries to be
meaningless pleasantries, like "How are you", or "What's new". She then
assures Cameron: Don't worry, I won't bother you. If I want to know
anything I'll just ask my dad\".

At Cameron's quizzical look, Julia smiles and explains that her father
is a general with the the Army's Intel section. Though Julia is plainly
teasing him, Cameron nonetheless gulps down his coffee and says he
should get back to work.
