---
identifier: a8447577
title: Spoor Decides To Consider
date:  
location: 
---

8.  When he learns of the opium runs, Spoor decides to consider Freeberg
    a major criminal, and orders his fighters to use deadly force if
    they encounter RI-002.
