---
identifier: c2f9e53b
title: Deportation Offer
date:  
location: 
---

10. Bob takes June to party thrown by Salipada Penatun to celebrate the
    sale of the quinine. Salipada Penatun offers to have Walters
    deported. Tom Lee suggests that such a move would have unintended
    consequences. Bob thanks Penatun for his offer, but says they should
    just put everything behind them.
