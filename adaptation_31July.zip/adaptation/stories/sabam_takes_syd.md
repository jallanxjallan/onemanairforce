---
identifier: 46bc743f
title: Sabam Takes Syd
date:  
location: 
---

3.  Sabam takes Syd and Cameron for beer in favorite lapo.
