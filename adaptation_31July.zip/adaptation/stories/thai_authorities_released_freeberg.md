---
identifier: 733b35b7
title: Thai Authorities Released Freeberg
date:  
location: 
---

4.  Spoor is furious that Thai authorities released Freeberg.
