---
date: 1 June 1947
location: Maguwo
---

```synopsis
Muharto receives a telephone call from an army base in Tasikmalaya, reporting that a foreign pilot has landed on a remote beach nearby and asked for Muharto by name.   

```



Petit Muharto sits at his desk. An airman approaches his desk and speaks (without saluting first) that he someone wants to speak to him on the telephone. Muharto looks surprised, stands and walks to a neighboring office, where the only telephone in the building is kept. He listens intently, discerning only a few words through the crackle of static: “Tasikmalaya base”, “Foreign pilot”, “Captain Petit Muharto”. 



