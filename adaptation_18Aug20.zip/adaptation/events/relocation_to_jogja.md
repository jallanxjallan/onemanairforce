---
identifier: 6fde06ad
title: Relocation To Jogja
date:  
location: 
---

3.  Republican government relocates to Jogjakarta in February 1946
