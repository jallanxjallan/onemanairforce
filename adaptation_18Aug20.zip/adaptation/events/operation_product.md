---
identifier: c7e7f58e
title: Operation Product
date:  
location: 
---

6.  Spoor orders Operation Product on 21 July to 4 August 1947. Dutch
    sweep out of Batavia to secure north coast. Took Karangendah
    airfield but stopped short to Jogja.
