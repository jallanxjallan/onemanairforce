---
identifier: d447c759
title: Dutch Return
date:  
location: 
---

2.  Dutch return in force to reestablish authority in January 1946
