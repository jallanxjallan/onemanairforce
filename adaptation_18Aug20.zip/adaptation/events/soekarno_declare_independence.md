---
identifier: cbdb3549
title: Soekarno Declare Independence
date:  
location: 
---

1.  Soekarno and Hatta declare independence of Indonesia on 17 August
    1945
