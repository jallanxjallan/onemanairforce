---
identifier: 0f35b45c
title: Troops Invade Jogja
date:  
location: 
---

4.  Dutch troops invade Jogja on 27 Dec 1948. Capture Nationalist
    leaders
