---
identifier: adf3ee20
title: Cameron Says Goodbye
date:  
location: 
---

I'm sorry eyang. Juloa begins. But Cameron touches her arm and looks at
her. She stops speaking. Cam turnns to muharto and says: sorry sir.
Afus. Told is that he saw Bob later being taken to a truck. He was in
handcuffs and looked like he had been beaten.
