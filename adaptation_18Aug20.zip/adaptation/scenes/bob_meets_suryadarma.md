---
identifier: 92670446
title: Third CALI Run
date: 31 March 1947 
location: Maguwo
---

``` {.synopsis}
In Jogja, Muharto introduces Bob to Suryadarma, who thanks the American for his assistance, and asks him to perform some risky tasks on the return leg. Bob grins and readily agrees. 
```

As the aircraft is being unloaded and refueled for the return to
Singapore, Muharto introduces Bob to Suryadarma, who thanks him for his
assistance. Then Suryadarma takes Muharto aside and tells him that this
will be his last blockade run. An Indian businessman has offered to link
India with the Republic with his own Dakota, VT-CLA, and has the full
support of the Indian government. Muharto is both pleased at this
display of crucial international support, and dismayed that once again
he will be desk-bound. However, thanks to Bob, his last flight will be a
memorable one.
