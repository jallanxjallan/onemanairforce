---
date: 1 June 1947
location: Maguwo
---

```synopsis
Muharto reports the surprising call to Suryadarma, the commander of the Air Force. Suryadarma grins, saying: “Must be one of your foreign flyboy friends”, and sends Muharto to Tasik to investigate.

```

Muharto walks to another building, to the office of Suryadarma, the commander of the Air Force. Muharto explains that an officer at the Tasik army base had reported an unknown cargo plane making an emergency landing on a nearby beach, and that the foreign pilot had spoken his name. Suryadarma grins, saying: "Must be
one of your foreign flyboy friends", and sends Muharto to Tasik to
investigate. 

