---
identifier: e5c6dc0a
title: Bob the Best
date: October 1947 
location: RI-002
---

``` {.treatment}
Bob stations himself at the Hotel Merdeka in Jogja taking RI-002 on both military and civilian missions in support of the Republic.
```
