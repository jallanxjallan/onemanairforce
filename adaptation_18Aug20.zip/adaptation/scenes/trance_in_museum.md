---
identifier: 0461e339
title: Museum Trance
date: 16 October 1988 
location: Museum
---

``` {.synopsis}
Muharto takes Cameron to the Air Force museum in Jogja, a re-purposed
hanger filled with decommissioned aircraft and other exhibits, which stir evoke vivid memories of the role of the Air Force in the struggle for independence. In the curator's office, Muharto handles the dynamo with the bullet lodged in the windings, and has a mystical vision of RI-002 in the seconds before the crash.
```

Muharto takes Cameron to the Air Force museum in Jogja, a re-purposed
hanger filled with decommissioned aircraft and other exhibits. Muharto
points to a model of the Zogling training glider, and tells Cameron of
training village boys who had never seen an airplane to become skilled
pilots in mere weeks. Muharto seeks out the curator, who invites them
into his office. Muharto asks the curator to retrieve scraps from the
RI-002 wreckage stored at the museum. One of the items is the dynamo
with the bullet inexplicably lodged in the windings. Muharto picks it
up, and from his point of view, the room around him fades into mist. The
room comes back into focus, and Muharto sees the concerned faces of
Cameron and the curator. Muharto places the dynamo back into the storage
box and says, in a wavering voice, that they will miss their train back
to Jakarta if they don't hurry.
