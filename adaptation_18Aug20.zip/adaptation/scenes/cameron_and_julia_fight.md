---
identifier: 87f71b13
title: Julia goes ballistic
date: November 1988 
location: Tanamur Back Bar
---

``` {.treatment}
Cameron and Julia argue over their interpretations of the research. 
```
