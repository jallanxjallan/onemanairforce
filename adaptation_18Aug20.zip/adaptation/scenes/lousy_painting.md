---
date: October 1947
location: Marketplace Jogja
---

```treatment
Affandi has set up his easel in a marketplace. The only food on display
is withered vegetables, rotten casava, and a single, scrawny chicken.
The vendors are dressed in rags. Affandi paints in his expressionistic
style, with vibrant colors and distorted figures. One young man becomes
enraged at seeing the artist, takes some mud and throws it at the
canvas, shouting: "It's bad enough you draw us when we are clothed only
in rags. But you make a lousy painting we can't understand!"
```


