Muharto reads of crash site discovery in 1977
Muharto researches in  AURI  and other collections. Finds only disorder and obstruction as librarians make life difficult.
Investigation report asks more questions than it answers.
American embassy helps with records
Photo of dynamo with bullet in windings
Sulaiman  and team investigate wreckage
Find empty crates of gold 
Find dynamo with bullet
Muharto tries to contact Sulaiman but gets no answer
Old Auri classmate claim no knowledge
Victor Panggebean evasive
