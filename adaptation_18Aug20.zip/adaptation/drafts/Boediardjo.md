Syd suggests Cameron meet Boedi , He was head of Deppen when Syd was bureau chief for a wire service, so they often interacted. and bonded on shared interest in art and classical music. 
a foreign correspondent
who gently teases Muharto, and tells amusing stories of being stranded in Manila with Aviation Brotherhood. 
Tells of 
Boedi tells of initial missions with Bob, and how he loved his mother's buntil. 

- Boedi gently teases Muharto, and tells amusing stories of being stranded in Manila with Aviation Brotherhood. 
- Boedi tells of initial missions with Bob, and how he loved his mother's buntil. 

Boedi says muharto has a lot to regret in his life (foreshadowing Permesta revelation) and that maybe Cameron should help him. Who knows, he says, you might get a best selling book if you solve the mystery.

Boedi has fond recollection of the party thrown by Salipada Penatun to celebrate the sale of the quinine. 