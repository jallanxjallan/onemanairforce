


• RI-002 lands on Sumatran runway at night, lit only by two lines of obor, bamboo and coconut oil torches. 

• Republic fears a move by the Dutch in the coming months, and so are planning to move all valuable assets to Bukittinggi.




1. Compare with rags worn in Jogja and Muharto/Boedi going on shopping trips in Manila and Singapore.

• They all stay with Ani's sister and husband. Cameron and Julia are, pointedly, given separate rooms at opposite ends of the house. This can be quite funny, with Julia being given a nice room overlooking the garden, while Cameron is led through a labyrinth to a windowless servant's quarters, the sister apologizing profusely all the way. 



Bob and Muharto return to Jogjakarta,  Bob takes a holiday, swimming in  Kaliurang 



Cameron mentions paratrooper story. Boedi replies: He wasn't there. That's not how it happened.

Bob does not confront his partner directly, but instead makes discreet inquiries. He is directed to a small airfield on the outskirts of Manila. He relocates the disputed aircraft himself, choosing another airfield with a short runway hemmed in by houses. Only a pilot with Bob's exceptional skill could land a large Dakota there.

