---
identifier: 48b32204
title: Agus Interview
date:  
location: 
---

17. Agus tells of seeing Santoso with the others in detention.
