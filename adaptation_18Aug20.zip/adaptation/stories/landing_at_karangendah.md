---
identifier: 20501bec
title: Landing at KarangEndah
date: 31 March 1947 
location: Karangendah
---

``` {.treatment}
Muharto asks Bob to make a test landing on a refurbished wartime airstrip designed for smaller aircraft such as fighters. Bob happily complies, and sets the Dakota down with only a few meters to spare on the runway. Muharto introduces Bob to Santoso, the base commander.
```

Before takeoff on the return trip to Singapore, Muharto asks Bob if he
can attempt a landing on a refurbished Japanese airstrip at Karenengah.
Bob readily agrees. They circle the strip and Bob ponders the attempt.
Muharto asks if he can land a plane this size. Bob replies that he did
this all the time in the war. He can "land on a dime and give you a
nickel change." Then Muharto asks if he can take off again. Bob replies:
"I certainly hope so. We seem to be smack dab in the middle of nowhere."
Bob lands. and Santoso, the base commander climbs aboard to meet them.
After a short conversation, Santoso exits, and Bob takes off, the wheels
finally lifting off the runway a few meters before the end.
