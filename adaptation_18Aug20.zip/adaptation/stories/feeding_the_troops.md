---
identifier: afa1537c
title: Feeding the troops
date:  
location: 
---

3.  As recruits pour into Java, Spoor realizes that he cannot feed them
    all with the limited agricultural resources of the Dutch-controlled
    territories. He mobilizes the military in a lightning strike,
    seizing agricultural land, ports, and oil fields.
