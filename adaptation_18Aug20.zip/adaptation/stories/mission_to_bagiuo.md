---
identifier: 27ae8dc7
title: Mission to Bagiuo
date: 30 November 1947 
location: RI-002
---

``` {.synopsis}
Freeberg, Muharto and Boedi fly Republican economists and other experts to Manila to meet
with United Nations representatives in the hill town of Baguio. The delegates, who are all prominent figures in the Republic and have cosmopolitan backgrounds, treat Bob with as much respect as do the hero-worshipping common people of Jogja.
```
