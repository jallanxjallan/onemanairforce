---
identifier: a64da112
title: Syd Slips Reporter Article
date:  
location: 
---

3.  Syd slips Our Reporter article into Post when Sabam gets back to the
    office late, and drunk, after embassy reception.
