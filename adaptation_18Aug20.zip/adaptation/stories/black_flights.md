---
identifier: 5d5e2be3
title: Black Flights
date:  
location: 
---

11. Suryadarma orders Bob to transport several tons of Republican opium
    to Bukittinggi.
