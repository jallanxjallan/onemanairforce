---
identifier: 0e804f9b
title: Cobley Attempts Engine Takeoff
date:  
location: 
---

8.  Cobley attempts one-engine takeoff and crashes Catalina when
    attacked in Jambi on 28 December.
