---
identifier: 0c33d523
title: Appeal to Foote
date:  
location: 
---

6.  Appeals to American consul Walter Foote to do something about
    Freeberg. Though Foote also disagrees with Freeberg's actions, he
    can do nothing.
