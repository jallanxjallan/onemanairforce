---
identifier: deaafe36
title: Ambassador Mentions CIA
date:  
location: 
---

5.  Victor overhears discussions between Spoor and Foote in which the
    American ambassador mentions the CIA.
