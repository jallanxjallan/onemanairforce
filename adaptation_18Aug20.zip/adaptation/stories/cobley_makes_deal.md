---
identifier: aff672fd
title: Cobley Makes Deal
date:  
location: 
---

1.  Cobley makes a deal with finance ministry and registers Catalina as
    RI-003. Suryadarma is annoyed at being circumvented.
