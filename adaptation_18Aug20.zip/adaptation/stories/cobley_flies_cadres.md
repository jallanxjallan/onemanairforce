---
identifier: 9562e44d
title: Cobley Flies Cadres
date:  
location: 
---

4.  Cobley secretly flies exiled communist cadres into a lake near the
    town of Madiun.
