---
identifier: 144e4788
title: Detained in Bangkok
date: October 1947 
location: Bangkok
---

``` {.synopsis}
Bob flies two Indonesian aviators to Bangkok, who will purchase RI-003 and fly it back to Jogja. Bob is detained by Thai authorities at the insistence of Dutch diplomats, but is released soon afterward in a tacit recognition of the legitimacy of the new Republic of Indonesia. 
```

Bob flies Halim and Iswandi to Bangkok. They will fly a recently
purchased Avro Ansen airplane back to Indonesia, where it will become
RI-003. Freeberg is detained by Thai authorities at the request of the
Dutch. However, the Thais can find no evidence of wrongdoing, as so
release him, to Dutch fury.
