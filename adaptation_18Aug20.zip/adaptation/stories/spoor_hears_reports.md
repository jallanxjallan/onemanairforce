---
identifier: 6bd06165
title: Spoor Hears Reports
date:  
location: 
---

2.  Spoor hears alarming reports of gun running. He imposes a tight an
    air and sea blockade around the entire archipelago.
