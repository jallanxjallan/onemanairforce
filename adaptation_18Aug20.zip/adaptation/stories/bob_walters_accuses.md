---
identifier: 29c12b19
title: Bob Sues Walters
date: August 1947 
location: ABBar
---

``` {.synopsis}
Bob Walters complains to Boedi about his business dealings with Bob Freeberg. 
```

The gregarious and charismatic Boedi had been wholly accepted by the
Aviation Brotherhood, the freewheeling foreign pilots seeking their
fortunes or reliving wartime adventures in often-dangerous charter
flights into remote areas of the region. Over drinks in the AB bar,
Boedi learns more about Bob, particularly the recognition by his peers
that he is the most skillful and courageous aviator in Southeast Asia.
Boedi also learns that Freeberg is in considerable financial difficulty,
and is in a legal battle with another aviator, Bob Walters, his partner
in purchasing the aircraft now known as RI-002. Walters is scathing in
his condemnation, calling Bob a thief and a con man.
