---
identifier: 5c3e3c01
title: Ining Was Found Dead
date:  
location: 
---

7.  During a routine radio contact with Jogja, Boedi learns that Ining
    was found dead of gunshot wounds along with Mas Ded at Ining's
    house.
