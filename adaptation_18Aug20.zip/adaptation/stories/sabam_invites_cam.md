---
identifier: 041a942f
title: Sabam Invites Cam
date:  
location: 
---

13. Sabam invites Cam and Syd to his favorite lapo after a disturbing
    phone call from deppen.
