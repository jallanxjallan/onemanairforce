---
identifier: 7b6b0cc3
title: Bambang Cannot Conceal Envy
date:  
location: 
---

5.  Bambang cannot conceal his envy of Moeljono when his fellow aviator
    flies the twin-engine RI-005 Avro-anson from Bukittinggi to
    Jogjakarta.
