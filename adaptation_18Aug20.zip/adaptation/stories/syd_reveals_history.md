---
identifier: 9bf2df40
title: Syd Reveals History
date:  
location: 
---

6.  Syd reveals secret history of CIA in Indonesia.
