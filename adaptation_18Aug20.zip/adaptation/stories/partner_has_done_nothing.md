---
identifier: 075e3da4
title: Partner Has Done Nothing
date:  
location: 
---

13. Bob learns that his partner Hugh Savage has done nothing to start
    Southeastern airlines. Savage complains that Walter's constant
    defamations had soured potential investors.
