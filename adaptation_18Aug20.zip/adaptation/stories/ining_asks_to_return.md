---
identifier: bee9d90d
title: Ining Asks To Return
date:  
location: 
---

6.  Ining asks to return home in a a letter to Primitivo, but is seconds
    too late to give it to Muharto to take to Manila. George sees that
    Ining is upset. George is on active duty, so he asks Muharto's
    brother, Mas Ded, to look after Ining.
