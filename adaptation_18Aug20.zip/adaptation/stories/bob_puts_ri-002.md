---
identifier: 94ed4c53
title: Bob Puts Ri-002
date:  
location: 
---

10. During the propaganda leaflet run over Madiun, Bambang watches
    intently as Bob puts RI-002 through tree-top maneuvers. Expression
    on his face reflects thoughts that he could do it himself.
