---
identifier: 010901e9
title: Newspaper Calls Ining
date:  
location: 
---

9.  Newspaper calls Ining a gun runner in an article in a Manila
    newspaper after Ining's funeral speculates that Ining's death
    resulted from an arms deal gone disastrously wrong.
