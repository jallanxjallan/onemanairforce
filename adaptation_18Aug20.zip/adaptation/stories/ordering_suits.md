---
identifier: ccf1b51c
title: Ordering Suits
date:  
location: 
---

3.  Bob orders suits from back home to suit his new role as businessman.
    With the shortage of textiles cheaper to order from US.
