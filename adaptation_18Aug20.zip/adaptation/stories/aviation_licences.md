---
identifier: a2f4eaad
title: Aviation Licences
date:  
location: 
---

2.  Muharto sees an opportunity to escape his desk work buy accepting an
    invitation to accompany a friend to Australia on business.
    Suryadarma reluctantly lets him go, but orders him to make as many
    aviation contacts as he can.
