---
identifier: 7855337a
title: Ani Berates Muharto
date:  
location: 
---

4.  Ani berates Muharto for trying to learn to fly. Better to stick to a
    safe job as a bureaucrat, like his father.
