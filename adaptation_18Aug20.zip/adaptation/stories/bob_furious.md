---
identifier: accb2820
title: Bob Furious
date: April 1948 
location: Manila Airport
---

``` {.treatment}
Bob enters the RI-002 cockpit and immediately discerns that someone had been there the previous night. He angrily confronts Muharto. 
```

Bob returns to RI-002 the following morning and is instantly aware that
someone had rummaged around his beloved Dakota the previous night. He
angrily confronts Muharto, who tells him about the deal with the jewels
to buy guns, and adds: "The jewels were entrusted to me by my
government," "They are my sole responsibility. This has nothing to do
with you." Bob replies: "Damn you, Muharto! It has everything to do with
me! I'm the captain---responsible for whatever happens on my ship,
whatever she carries. If you get caught, I also go to jail!"
