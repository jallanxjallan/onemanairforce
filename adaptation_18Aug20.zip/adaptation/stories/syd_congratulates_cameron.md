---
identifier: 13450158
title: Syd Congratulates Cameron
date:  
location: 
---

4.  Syd congratulates Cameron on story. Says he should do more research
    in library. And say hi to Julia
