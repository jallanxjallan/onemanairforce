---
identifier: aa999ed2
title: Bob Gives Bambang
date:  
location: 
---

4.  Bob gives Bambang a flying lesson in RI-002 that runs into problems
    because of Bambang's weak command of English.
