---
identifier: cf3a1885
title: Spoor Orders Night Patrol
date:  
location: 
---

9.  Spoor orders a night patrol not to engage a blockade running POAS
    flight because he is informed that American and other civilians are
    passengers.
