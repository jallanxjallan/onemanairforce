---
identifier: 3ca7a34a
title: Victor Arrives
date:  
location: 
---

1.  Victor marches off troop ship with other recruits. Made a point of
    learning Indonesian and teaching other recruits during voyage. Picks
    up Indonesian language newspaper in Medan and manages to read it.
    Commandant noted this. Brought his own camera with him. Assigned to
    Mapping department as has good visual eye and can draw.
