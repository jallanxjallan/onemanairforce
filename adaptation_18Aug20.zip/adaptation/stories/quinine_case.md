---
identifier: 4fcdfb49
title: Quinine Case
date: 20 June 1947 
location: Courtroom
---

``` {.synopsis}
Bob and Muharto attend their first court session to decide who owns Dutch representatives take them to court over possession of the quinine cargo.
```

Their lawyer, Salipada Penatun, who is also a sitting senator with
extensive high-level contacts, lays out the legal justification for
ownership of the quinine, then lets Muharto give an impassioned plea,
claiming that the money from selling the quinine will buy medicines and
other essentials unavailable in the besieged capital. The Dutch counter
by calling a plantation expert to testify that the Republic does not
have the capability to process quinine, so the drug must have been
produced in a Dutch-owed factory before the war. Muharto jumps to his
feet, ready to protest this insult to his people's technological skill,
but Penatun motions for him to sit down, then calmly tells the judge: "A
foreigner is not qualified to discuss the internal matters of the
sovereign Republic of Indonesia." The judge considers this, obviously
with some sympathy, and adjourns the session.
