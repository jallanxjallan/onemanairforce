---
identifier: 64c62c57
title: Cia Supported Foote
date:  
location: 
---

11. Cameron becomes convinced that the newly formed CIA supported Walter
    Foote and Spoor in their first attempt at regime change. âThis is
    where it all startedâ
