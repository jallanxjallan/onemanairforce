---
identifier: 12330d4f
title: Expat Party
date:  
location: 
---

2.  First fight is when Cameron takes Julia to an expat party in Kemang,
    and she is mistaken for a bar girl.
