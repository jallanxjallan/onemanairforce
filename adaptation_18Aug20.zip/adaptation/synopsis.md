# Interviewing Muharto

In September 1988, Sabam Siagian, managing editor of The Jakarta Post, assigns Cameron, a  American recent journalism graduate doing a year's internship as a copy editor, to interview Petit Muharto, 

Cameron visits Muharto, who tells him of meeting Freeberg, having his unregistered aircraft designated  RI-002, and his essential role in facing down Dutch aggression by running essential supplies through the blockade. Muharto ends his recollection by explaining how Freeberg vanished  while transporting a fortune in gold to safety ahead of an expected Dutch invasion. Farmers had stumbled upon the wreckage of RI-002 on a remote mountainside ten years previously, but could not identify Freeberg's remains from the few fragments of bones they found.  

Cameron is struck by the genuine sadness in Muharto that his friend and comrade-in-arms had vanished from history. He writes up the interview, and gives it to Sabam. However, Sabam is on his way to a diplomatic dinner, and simply hands the pages to Syd and rushes out the door. Syd reads the piece, and suggests that Cameron flesh it out with some library research for the benefit of foreign readers. He tells him to go the newspaper archives at the National library and talk to Julia, an intern who can find exactly what he needs. 

# Meeting Julia

Cameron visits the library and meets Julia. He discovers that Syd is correct, Julia brings him exactly what he requires from the restricted rare books section. He is not allowed to take the books with him, so he reads and takes notes all morning. He is not allowed to bring liquids into the reading room, so Julia takes Cameron to the library canteen for coffee. Julia tells Cameron about her desire to take her post graduate degree in Europe or American. In return, Cameron attempts to tell Julia about his background, but Julia cuts him off, saying, with a mischievous grin, that she can learn all about him from her father, a general in military intelligence.     

# Meeting Victor

Julia takes initiative. Phones Cameron at the post to congratulate him on the story. Suggest he visit again on Wednesday. She will introduce him to victor, who is there every Wednesday



# Trip to Jogja

