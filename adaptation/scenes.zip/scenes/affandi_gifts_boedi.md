---
date: 16 October 1988
location: Affandi Museum Jogjakarta
---

```treatment
Affandi dashes off and signs a self-portrait for Cameron to give to Boedi.
```

Cameron asks what happened to the painting. Affandi laughs and explains
that he and his friends at buried the propaganda paintings in the forest
when the Dutch overran Jogja. When the Dutch withdrew from Jogja six
months later, they returned to the forest, only to discover that
villagers had dug them up in the meantime. Muharto reappears, greets
Affandi with respect, and tells Cameron it is time to go. Affandi grabs
a sketch pad, dashes off a self-portrait, signs it, and hands it
Cameron, explaining that it was a gift for Boedi to thank him for
sending him a new friend.