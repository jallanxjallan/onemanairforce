---
date: November 1948
location: Library
---

```treatment
Cameron receives a lengthy letter from Dave Fowler through Frank Reuneker. He reads it to Julia.
```

