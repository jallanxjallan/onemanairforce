---
date: January 1948
location: KNIL Headquarters
---

```treatment
Julius witnesses Spoor raging about the news that RI-002 seemingly had assited Espina to smuggle guns into Indonesia. He vows to end the blockade runs by any means nescessary.
```

