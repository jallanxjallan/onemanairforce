---
date: 8 June 1947
location: Tasik Army Base
---

```treatment
In Tasik Muharto meets Pang Soeparto, the junior army officer who telephoned him, who takes him (and two barrels of aviation fuel) to the beach at Cikolong. As soon as Muharto sees the beach, bookended by two rivers and the gap between the water and palm trees scarcely more than the Dakota's wing span, he knew that, of all the pilots he had met, only Bob Freeberg had the skill to make that landing.
```

Muharto meets Pang Suparto, the army officer who had telephoned him, and together they take two barrels of aviation fuel to the beach where Freeberg is stranded. On seeing the beach, Muharto is astounded that Freeberg was able to land there safely. 

Muharto tells Cameron that in Tasik he met Pang Soeparto, the junior army officer who telephoned him, who takes him (and two barrels of aviation fuel) to the beach at Cikolong. He tells Cameron that as soon as he saw the beach, bookended by two rivers and the gap between the water and palm trees scarcely more than the Dakota's wing span, he knew that, of all the pilots he had met, only Bob Freeberg had the skill to make that landing.