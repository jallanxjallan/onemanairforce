---
date: April 1949
location: forest outside jogja
---

```treatment
Villagers wearing rags that are literally falling off their bodies
appear in the forest and dig up the propaganda posters and paintings
buried there. The cut and fashion them into garments, proudly wearing
new pants and shirts lurid with colorful images.
```


