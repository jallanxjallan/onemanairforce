---
date: 1 June 1947
location: Muhartos office Maguwo
---

```treatment
Muharto receives a telephone call in Air Force headquarters in Jogja from an army base in Tasikmalaya to report that a foreign pilot has landed on a remote beach nearby and asked for Muharto by name. Suryadarma, the Air Force commander, sends Muharto there to investigate.  

```



Petit Muharto sits at his desk. An airman approaches his desk and speaks (without saluting first) that he someone wants to speak to him on the telephone. Muharto looks surprised, stands and walks to a neighboring office, where the only telephone in the building is kept. He listens intently, discerning only a few words through the crackle of static: “Tasikmalaya base”, “Foreign pilot”, “Captain Petit Muharto”. 

Muharto walks to another building, to the office of Suryadarma, the commander of the Air Force. Muharto explains that an officer at the Tasik army base had reported an unknown cargo plane making an emergency landing on a nearby beach, and that the foreign pilot had spoken his name. Suryadarma grins, saying: "Must be
one of your foreign flyboy friends", and sends Muharto to Tasik to
investigate. 

