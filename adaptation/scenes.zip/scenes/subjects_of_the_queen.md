---
date: 12 June 1947
location: Tom Lee Kitchen
---

```treatment
Over breakfast at Tom Lee's house, Tom reads the newspaper headlines
about "Fearless Bob Freeberg" and his "Javanese Crew". One article
reports that the Dutch are laying claim to the valuable quinine cargo as
the "Javanese Crew" are "subjects of the Dutch Queen". Boedi laughs, but
Muharto is outraged.
```


