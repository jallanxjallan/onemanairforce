---
date: October 1988
location: Boedi living room
---

```treatment
Cameron attends a lecture on cultural tourism to visiting American academics. He is invited to the sponsor's reception, where he meets Boedi and discovers that he had been radio operator of RI-002. At Cameron's urging, he tells amusing anecodes of his days with RI-002 to his guests. 
```

The organization sponsoring Cameron's internship invites him to attend a gathering of visiting academics in the cultural and tourism field. The host is Boediardjo, a former Air Force officer and government minister. In the spacious reception area of his colonial-era mansion in Menteng, Jakarta's most-exclusive neighborhood. Cameron is impressed by the European and Indonesian artworks covering the extensive wall space, and by the McIntosh tube amp and Quad speakers denoting a true, and well-heeled, audiophile. Boedi recognizes Cameron as the writer of the Jakarta Post article about Bob Freeberg, inquires about Muharto's well-being, and informs Cameron that he had been the radio operator of RI-002 until July 1948. Cameron is taken aback, and asks for an interview. The other guests must leave soon after dinner to catch an early flight, so Boedi invites Cameron to stay behind.     

Boedi begins by describing Bob as one of the most patient, unflappable persons he had ever met. Smiling, Boedi remarks that this was a necessary quality for flying with Indonesians during the early years of nation hood. During colonial times, the Dutch had only admitted a handful of native sons into flight school. So even Air Force officers had had little hands-on experience with actual aircraft, as Captain Muharto proved when Bob asked him to sit in the co-pilot seat as they approached Manila on the first flight of RI-002. 

> 







