---
date: October 1988
location: Hotel Borobudur
---

```treatment
Cameron drops Julia at the front entrance to the hotel, impressing her friends, who decides that he must be rich.
```



Cameron pulls up at the hotel entrance, impressing Julia’s friends, who
are waiting for her by the door. Cameron drives away to park his Harley,
while Julia and her friends go to their event, a birthday party for
another general's daughter where the gifts include a house and a car.
The friends press Julia for information about Cameron, and suggest that
since he rides a huge motorcycle, and is a *bule*, he must be rich, teasing her that since her father, unlike other generals, does not give his daughter unlimited amounts of money, she needs a rich boyfriend.  Cameron and Julia walk into the lobby of the Hotel Borobudur together,
where her friends are waiting. Julia introduces Cameron to them, then he walks toward
the bar. Julia's friends grill her about the bule, with Julia insisting
that they are not even friends, just new acquaintances. The friends, who
are all *anak jendral*, insist that Julia should go out with him. All bule
are rich, they say, and maybe with his money Julia can finally come with
them on shopping trips to Singapore.