---
date: 31 March 1947
location: CALI aircraft cockpit
---

```treatment
On the third blockade run, with Bob Freeberg as captain, the overcast sky forces Muharto to navigate by asking Bob to fly low enough to follow the railway line to Jogja. 
```

Muharto stands in the cockpit between Bob and his co-pilot, guiding the aircraft by landmarks he has seen twice before on previous blockade runs. But today, overcast obscures the terrain save tops of the volcanoes poking through the clouds. Miss Brown, a comely Filipina who, incongruously, is the stewardess on what is basically an illegal flight, hands Muharto a cup of tea, then looks at the solid overcast with obvious concern. 

Bob points to the peaks and asks if there is any high ground in between. Muharto thinks for a moment, then replies: I don't think so. Nothing above a few hundred meters. To Muharto's horror, Bob noses the aircraft down through the overcast, emerging perilously close to the terrain. Muharto gulps, and frantically looks for any type of landmark. He sees a rail line that he knows will lead them through valleys and plains all the way to Jogja. He tells Bob to follow that line, and Jogja appears a few minutes later, to Miss Brown's great relief. 