---
date: October 1947
location: Presidential Palace Jogja
---

```treatment
Muharto takes Bob to meet Soekarno . At the presidential palace. As was
his custom in private conversation, Soekarno treats Bob as an equal and
urges him to stay and help the struggle.
```


