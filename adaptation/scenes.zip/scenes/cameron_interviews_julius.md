---
date: November 1988
location: Caltex Office
---

```treatment
Cameron interviews Julius Tahija, who admires his writings about the capital market and so is open and opinionated. At the end of the interview, Cameron asks about his experiences as adjudant to General Spoor. 
```

