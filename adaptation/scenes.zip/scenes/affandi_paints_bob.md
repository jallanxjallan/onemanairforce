---
date: October 1947
location: Maguwo Airfield Jogja
---

```treatment
Affandi sketches Bob in front of RI-002.
```

Affandi is sketching at the edge of the runway, near where RI-002 is
parked. Bob walks up to him and compliments the sketch. Affandi, who
speaks some English, asks Bob to briefly pose for him. Affandi was
struck at the immense respect Bob enjoyed from military and government
officials, and the adoration, the outright hero worship, of the common
Indonesians. Affandi painted Freeberg standing in front of RI-002 as
though he were Bima, a hero in the wayang legends of ancient Java.
Freeberg, like Bima, was tall and imposing, strong and exceptionally
skilled. And, like Bima, Freeberg was modest and unpretentious, a gentle
soul in a warrior's body.