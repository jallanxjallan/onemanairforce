---
date: 31 March 1947
location: CALI Dakota cockpit
---

```treatment
Bob uses his wartime aviation skills to parachute Air Force engineers and their gear to a bull's eye landing on a pot-holed highland airstrip they are tasked to refurbish.  
```

The CALI Dakota flies over the Bukit Barisan mountaintops, and drops
into a valley toward the town of Bukittinggi. At Muharto's direction,
Bob passes low over an airstrip, which is plainly full of potholes and
unusable. The co-pilot leaves his seat and goes to the cargo
compartment, motioning to Miss Brown and Muharto to sit down far from
the door. The two other passengers are donning parachutes and preparing
to jump. The co-pilot wrenches open the door, and scraps of paper and
cardboard swirl as the air stream enters the cabin. The two parachutists
jump out the door. Muharto looks out of the window behind him, sees the parachutists land squarely on the airstrip, and remarks on Freeberg's piloting skills.