---
date: 16 October 1988
location: Affandi Museum Jogjakarta
---

```treatment
Cameron meets Affandi, who tells him amusing stories of making propaganda posters to raise morale during the blockade. 
```

Muharto drops Cameron at the entrance to the Affandi museum, says he
will pick him up again in two hours, then drives away. Affandi, an
animated, disheveled elderly man, is sitting on a bench on the grounds
of the compound, as though he is homeless person seeking rest, not the
owner of the sprawling estate and a fortune in paintings and sculptures.
Affandi greets Cameron pleasantly, in English, and then becomes effusive
when Cameron brings greetings from Boedi. The fall into animated
conversation. Cameron explains the purpose of his visit, and Affandi
launches into a humorous and poignant narrative of painting propaganda
posters amid the privation and danger of besieged Jogjakarta, including
an encounter with Bob Freeberg.
