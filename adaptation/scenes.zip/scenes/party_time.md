---
date: 10 September 1947
location: AB Bar
---

```treatment
At the party to celebrate the sale of the quinine and their return to Java, Ining shows himself to be a party animal, buying rounds for his companions flirting with the foreign women in the Aviation Brotherhood bar. When he hits on the teenage daughter of an American pilot, tempers flare, and Freeberg and Boedi have to hustle him out of the bar. 
```

