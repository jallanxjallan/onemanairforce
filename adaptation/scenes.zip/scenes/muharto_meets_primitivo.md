---
date: August 1947
location: Intel HQ Manila
---

```treatment
During the long wait to sell the quinine, Muharto acts as de facto military representative of the Republic. He meets Major Primitivo of the intelligence service, who introduces Muharto to Captain Ignacio Espina, a guerrilla who fought the Japanese occupation of the Philippines. Espina, nicknamed Ining, will accompany RI-002 back to Jogja, where he will transfer his guerrilla warfare skills to the young militia members of the Tentara Pelajar.
```

