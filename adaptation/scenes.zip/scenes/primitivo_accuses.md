---
date: December 1947
location: Intel HQ Manila
---

```treatment
When Muharto reports on the news from Jogja to Primitivo, the major accuses Muharto and his brother of being clandestine communists.  
```

