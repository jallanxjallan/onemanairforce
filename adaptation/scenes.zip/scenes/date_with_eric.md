---
date: October 1988
location: Hotel Hilton
---

```treatment
Julia goes on a date with Eric, the son of a friend of her father, a successful businessman. Eric reveals that their fathers are joining forces with an American venture capitalist to artifically inflate the value of his father's company for the sale on the capital market. 
```

Julia goes on a date with Eric, which as set up by her father. Eric dominates the conversation with boasting about the deal their respective fathers are making with a Bruce Rappaport-style American stock hustler to sell his father's company at an inflated price after the capital market is deregulated. Julia objects that this is corruption, something General Eddy has never done during his career. Eric dismisses her concern, stating that: "It isn't corruption to take money from foreigners."