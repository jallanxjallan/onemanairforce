---
date: 17 October 1947
location: RI-002 in flight
---

```treatment
Bob drops paratroopers into the Kalimantan forest. This is the first time in an aircraft for all, so Bob gives a pep talk to the terrified troopers, translated by Boedi. 
```

Bob drops paratroopers into a Republican area. It was the first jump for
everyone, and many are terrified. One soldier pulls his ripcord,
spilling his parachute on the deck. He swears it was an accident, but
others grip their cords, possibly ready to do the same. Boedi reports
the situation to Bob, who turns the controls over to Moeljono and goes
back to the cargo area. With Boedi interpreting, he gives the soldiers a
pep talk, telling of his own terror flying in the war. The soldiers all
agree to jump. Boedi watches as the parachutes drift down and are
enveloped by the endless forest.