---
date: September 1947
location: Madras Curry Manila
---

```treatment
Muharto attempts to pay for their meals at Madras Curry, explaining that
it is an honorarium for the talk to the lady lawyers. To his surprise,
Bob chastises him for "taking money for nothing".
```

