---
date: 30 May 1948
location: Bukittinggi
---

```treatment
The starboard landing gear collapses just as RI-002 is about to take
off. Nevertheless, Bob and the airstrip crew right the craft,
repressurize the hydraulics, and take off as Dave Fowler shakes his head
in dismay.
```



In Bukittinggi, Dave Fowler looks on in shock as the right-side landing gear collapses just as RI-002 is planning to take off. Bob grins, and says: “You know how it is. 99 times out of a hundred you can get away with it." Fowler replies: “I guess this was the 100th time.”

Bob and the ground crew jack up the wing on blocks as Bob resets the gear, then walks along the wing checking for cracks. He sees one sizable crack, kneels down to inspect it, then shouts to Fowler that “it will hold”,  Bob goes back to the cabin, fires up the engines, and takes off while Dave Fowler shakes his head.