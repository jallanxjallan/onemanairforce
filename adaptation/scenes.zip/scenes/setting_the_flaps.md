---
date: 10 July 1947
location: RI-002 cockpit in flight
---

```treatment
Bob invites Muharto to sit in co-pilot seat and assist him with the flap controls during the final approach to Manila. But when Bob gives the command, the nervous Muharto pushed the levers to the full causing the Dakota to make a dramatic drop. Bob instantly repositions the levers, and gently reminds Muharto to not pass the half-flaps setting until they see the runway.	
```



Approaching Manila, Muharto sits in co-pilot seat. Nervous, he mishears Bob's instructions, and deploys full flaps, causing the Dakota to make a dramatic drop. Bob instantly corrects the setting, and gently reminds Muharto to not pass the half-flaps setting until they see the runway.