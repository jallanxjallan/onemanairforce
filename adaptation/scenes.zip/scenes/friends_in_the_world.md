---
date: June 1948
location: Sumatra Airfield
---

```treatment
Soekarno gives a speech near where RI-002 had landed. Soekarno points to
Bob resting in the shade with Boedi under a wing and says: "Here is a
foreigner, but he is on our side."
```



Soekarno Tour props up support for the independence struggle and to
raise money to purchase a presidential aircraft, to be named RI-001.
