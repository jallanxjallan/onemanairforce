---
date: October 1988
location: Tanamur
---

```treatment
Julia and Cameron party with her friends at the Tanamur. The friends want to go next to an after-hours place, where girls are admitted free but men must pay a steep cover charge. Because of his tight budget, Cameron must demur, and Julia is embarrassed for her new friend. 
```

Julia and Cameron meet her friends at the Tanamur. All talk excitedly
about studying overseas. The girls want to go to an after-hours club in
Kota. Girls get in free, but Cameron has to pay a steep cover charge.
Cameron looks uncomfortable, Julia makes an excuse.