---
status: final
name: Where is the Gold
---
[SLUGLINE]{name="Where is the Gold" date="5 July 1988" location="Jakarta Times" category="interview"} On the afternoon the article is published, Muharto visits Cameron at the Jakarta Times to thank him. Muharto tells Cameron and Syd that old comrades have been contacting him all day, praising the article and wondering what happened to the gold. 

Muharto recounts his frustrating attempts in [SLUGLINE]{name="Adventures in Archives" date="5 July 1980" location="Air Force Archives" category="scene"} to seek clues to the mystery in air force archives and state libraries, only to be stymied by chaotic cataloging and officious bureaucrats. 

[SLUGLINE]{name="Motivation and Ability" date["5 July 1988" location="Jakarta Times" category="interview"}  Syd Jardine says that since unloading a quarter ton of gold would require considerable resources, discovering who might have had the motivation and ability to transport and sell the gold could solve the mystery of RI-002. Muharto agrees, and asks Cameron if he would be willing to help do more research on this angle. Cameron nods, and says he knows just the person who can assist them. 

