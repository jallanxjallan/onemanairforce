---
status: new
title: Telephone Terror
---
[SLUGLINE]{name="Telephone Terror"}  Cameron receives a telephone call at his home. The gruff voice on the other end suggests
that Cameron stop poking into matters that are none of his business.

