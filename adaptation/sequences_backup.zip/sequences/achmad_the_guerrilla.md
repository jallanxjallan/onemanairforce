---
status: draft
title: Achmad the Guerrilla
---
[SLUGLINE]{name="Painful Memories" category="interview" date="22 July 1988" location="Muharto Residence"}  Cameron tells Muharto of his interview with George
Rueneker, and cajoles him into telling of the events following the
death of Ining. 

[SLUGLINE]{name="Achmad the Guerrilla" category="scene" date="04 December 1947" location="RI-002"}  During a routine radio contact with Jogja, Boedi is
told that Ining and Mas Ded were found dead of gunshot wounds at Ining's
house.

[SLUGLINE]{name="Baseless Accusation" category="scene" date="05 December 1947" location="Manila"}  Muharto reports Ining's death to Primitivo. Muharto
is astounded when the major accuses Muharto and his late brother of
being clandestine communists, and detains Muharto for interrogation.

[SLUGLINE]{name="Kaliurang Holiday" category="scene" date="24 December 1947" location="Maguwo"}  RI-002 returns to Jogja. Suryadarma tells Bob to lay
low while they deal with the fallout from Ining's death. Bob spends an
idyllic few days in Kaliurang, a resort on the slopes of Mount Merapi.

[SLUGLINE]{name="Airworthiness Issues" category="scene" date="29 December 1947" location="Changi"}  RI-002 departs for Pekanbaru carrying 14 Republican
officials and a coffin containing Ining's remains. Bad weather over
Pekanbaru forces RI-002 to divert to Singapore. Dutch representatives on
the island pressure the British into grounding the Dakota because of
"airworthiness" issues.

[SLUGLINE]{name="Finally To Manila" category="scene" date="15 January 1948" location="Changi"}   British officials open Ining's coffin, searching for
contraband. Finding none, and with RI-002 brought up to minimal
airworthiness standards, they grant Bob permission to depart, to the
great annoyance of the Dutch.
