---
status: rework
title: Political Artist
---
[SLUGLINE]{name="Political Artist" category="interview" date="21 July 1988" location="Taman Sari"}. Julia visits Taman Sari. Asking around, she is directed to Hendra's modest dwelling. Hendra is astonished, and wary, at the unexpected visit, but Julia wins him over. Hendra tells Julia of a frightening incident at Emeria's Salon. 

[SLUGLINE]{name="Hiding Hendra" category="scene" date="10 October 1947" location="Emeria Salon"} A squad of KNIL soldiers burst into the salon looking for Hendra. Emeria invites them to search the nooks and crannies of the studio. But when a soldier attempts to enter a side room, Emeria stops him, stating that it is her private bedroom and off-limits to any man. Emeria cows the ethnic-Javanese commander with her imperious tone. He apologises to Emeria, and orders his men to leave. After they depart, Hendra emerges from her bedroom. 