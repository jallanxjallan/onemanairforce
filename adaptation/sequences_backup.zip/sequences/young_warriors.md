---
status: final
name: Young Warriors
---
[SLUGLINE]{name="Young Warriors" category="interview" date="21 July 1988" location="Earthquake"} Sanyoto introduces Cameron to George Rueneker, a retired Air Force officer
who owns an aviation-services company. Reuneker expresses interest his investigations, so Cameron recaps his research so far, and mentions Muharto abruptly halting the interview with Pang Soeparto at the mention of Captain Espina. George suggests this stirred painful memories, and tells Cameron the tragic story of the Filipino guerrilla.    

[SLUGLINE]{name="Kids With Guns" category="scene" date="07 October 1947" location="Jalan Jetis"} Muharto and George take Ining to a house on the slopes of Mount Merapi, adjacent to the forested areas where Ining
will train students to become guerrilla fighters. Muharto tells Ining that George will look after his requirements whenever Muharto is away on a mission with RI-002. Ining breaks out one of the bottles of whiskey he brought from Manila, and they toast the new adventure. 

[SLUGLINE]{name="Military Babysitter" category="scene" date="21 October 1947" location="Jalan Jetis"} George visits Ining, bringing, as requested, a bottle of local spirits. He witnesses Ining berate the young recruits and sees
the displeasure on their faces. Later, as he drinks his arak, Ining complains about the isolation and lack of entertainment options. He had spent the entire war living in the forests of Mindinao, and feels he now deserves a soft desk job. 

[SLUGLINE]{name="Letter to the Major" category="scene" date="30 November 1947" location="Maguwo"} Ining writes a letter Major Primitivo asking to be
relieved of his assignment and returned home. He rushes to Maguwo, but
is seconds too late to give it to Muharto to take to Manila. George, on
duty as flight controller, is on the tarmac. He sees that Ining is
upset, so he asks Muharto's brother, Mas Ded, to take Ining back to
Jalan Jetis and stay with him until he calms down. 

[SLUGLINE]{name="Young Warriors" category="interview" date="21 July 1988" location="Earthquake"}  George tells Cameron that Ining and Mas Ded were found at the Jalan Jetis house a few days later, both dead of gunshot wounds. The incident was labelled an accident, and Ining's body secretly returned to Manila on RI-002. 
