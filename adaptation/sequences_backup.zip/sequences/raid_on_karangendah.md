---
status: new
title: Raid on Karangendah

---
[Triple Shift]{cat="scene"}[13 December 1988]{cat="date"}  Cameron asks Syd to fill in while he takes three
days off to go to Karangendah. But the other copy editors flake out,
leaving Sid alone on the copy desk. He works three triple shifts,
getting his protein from whiskey and his vitamins from cigarettes.

[Interview With A Preman]{cat="scene"}[04 December 1988]{cat="date"}  Anwar reveals that KNIL officers had paid him to
smuggle a substantial quantity of gold to Singapore. Anwar also
introduces Cameron to several men who had been employed at Karangendah
in menial civilian jobs. They attest that they had seen the crew in
captivity. However, no one remembers seeing Freeberg. Anwar Congo
reveals that gold was used to purchase guns smuggled from Malaya, which
then taken overland to Lampung by Sumatra preman.

[Death in the Kos]{cat="scene"}[17 December 1988]{cat="date"}  Cameron returns from Karangendah on the morning
flight and goes directly to Syd's room to tell him the news. He finds
his friend dead in his favorite reading chair, a book on his lap and a
glass of whiskey at his side.

[Julia Choice]{cat="scene"}[16 December 1988]{cat="date"}  Julia turns down Cameron's offer and announces her decision to take her masters at UI.  