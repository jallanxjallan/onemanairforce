---
status: new
title: Into the Kampung
---
[SLUGLINE]{name="Into the Kampung"} Emeria takes Victor along (out of uniform) as she
sketches portraits of people crowded into the poorer sections of Batavia. Many have been driven from their villages by neighbors who support continued Dutch rule. 

