---
status: new
title: Squadron Leader

---
[Squadron Leader]{cat="scene"}[04 November 1988]{cat="date"}  Muharto takes Cameron to meet his friend Alex
Kawilarang, Also present is a Paul Verspoor, a retired Dutch
airforce officer vacationing in Indonesia. Verspoor, who had been a KNIL
squadron leader, tells Cameron about his "very boring mission" waiting
to intercept RI-002 near Bukittinggi on 1 October 1948. Afterward, as he
escorts Muharto and Cameron to the door, Alex winks at Cameron and tells
him to keep looking, as his old friend Paul knows more than he lets on.

[Awkward Confession]{cat="scene"}[15 December 1988]{cat="date"}  Cameron arranges to meet Alex and Paul at the
Earthquake the night before Paul will return to the Netherlands. After
several drinks, and with Alex urging him on, Paul reveals that
Westerling had contacted him in early 1949 to ask if his squadron would
support a coup against the colonial government. Verspoor knew that many
of his squadron would support Westerling, and so gave a vague,
noncommittal answer. Verspoor realizes his indiscretion, and begs
Cameron to not repeat this information, as most of his former comrades
are still alive.
