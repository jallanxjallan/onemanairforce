---
status: new
title: Real Gunrunner
---
[Real Gunrunner]{cat="scene"}[15 April 1948]{cat="date"}  At a party in Manila, Muharto is appalled when one of
Bob's housemates boasts of shooting down own squad leader. He decides to
not tell Bob of his plan to smuggle gems into Manila to be traded for
sidearms. He arranges for Filipino commandos to enter RI-002 and
retrieve the gems from a concealed niche. The following morning, Bob
notices that the cockpit had been disturbed, and confronts Muharto.

[New Copilot]{cat="scene"}[07 May 1948]{cat="date"}  Bambang finally gets his permanent assignment as
RI-002 co-pilot when Muharto is promoted and reassigned to headquarters.
He starts his first mission by suggesting a route, as Muharto would do
as mission leader. But Bob rebukes him, saying his only job is to watch
and learn.

[Not Ready for Airplanes]{cat="scene"}[07 May 1948]{cat="date"}  Bob waits in the pre-dawn gloom for Bambang and the
crew to show up for an opium run that must be completed before sunrise. It is well after dawn, when they drive up, laughing and
joking. Bob is furious, but keeps his voice measured, telling Bambang
and the others that they are "Not Ready for Airplanes", they jumping
into their automobile and telling the driver to take him back to the
hotel.
