---
status: final
name: Cute and Nerdy
---
[SLUGLINE]{name="Cute and Nerdy" date="30 June 1988" location="Library" category="research"}  Cameron uses his "foreign correspondent" credentials to gain access to the reference section of the National Library. Julia Suryakusuma, an attractive, bookish woman in her early 20s who speaks fluent English and Dutch, is assigned to assist him. Cameron explains his mission, and Julia disappears into the stacks, returning shortly with books written by foreigners about the period. 

One account of an incident in [SLUGLINE]{name="Sharing The Wealth" date="10 January 1948" location="Raffles Hotel" category="scene"} shows how most aviators considered Freeberg the most skilled and courageous of their brotherhood, but were envious of how he seemed to monopolize contracts with the Republic. One pilot, Ralph Cobley, had openly threatened Frreberg if he did not "share the weath". 

[SLUGLINE]{name="Disturbing Coffee Break" date="30 June 1988" location="Library" category="research"} Cameron is tired from reading. Julia invites him to join her for coffee in the canteen. She tells of her childhood in the Netherlands, where her father had been a military diplomat, her frustrations living in conservative, parochial Indonesia, and her dream of taking her post-graduate studies in America. When Cameron attempts to tell his story, she interrupts and, with a sly grin, says if she wants to know anything about him she will ask her father, who is now a colonel in Army intelligence. 

