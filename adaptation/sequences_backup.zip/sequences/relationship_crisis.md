---
status: new
title: Relationship Crisis
---
[SLUGLINE]{name="Relationship Crisis"} Cameron voices suspicions to Syd that Julia is leaking information about the investigation. 