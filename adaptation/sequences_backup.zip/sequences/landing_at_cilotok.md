---
status: final
name: Landing At Cilotok
---
[SLUGLINE]{name="Landing At Cilotok"}  Bob Freeberg lands his unmarked Dakota cargo plane on
a remote beach in southwest Java, the huge aircraft shuddering to
a stop a few meters from a rocky outcrop. Villagers appear, marveling
at this colossus from the sky. They are friendly and offer Bob and his
two Filipino crew members food and a place to sleep. But the following
morning, Indonesian soldiers appear. One points to the lack of
registration on the Dakota's tail and shouts "*Mata-Mata*!", "Spy!" They
point their rifles directly at Freeberg. He replies with the only words they
might understand, a name: "Captain Petit Muharto"
