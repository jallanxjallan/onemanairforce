---
status: final
name: Military Comfort Zone
---
[SLUGLINE]{name="Military Comfort Zone" category="interview" date="15 July 1988" location="Earthquake"} Syd takes Cameron to the Earthquake, a nightclub near his rented room in Central Jakarta. Sanyoto, the owner and a close friend, was an Air Force drill sargeant, and later a fixer for foreign oil companies. Most patrons are senior military officers and government officials. Sanyoto introduces Cameron to Sudaryono, one of the first tranche of cadet pilots. Sudaryono relates amusing stories of the rivalry between the two best cadet pilots in the class: Bambang Sudarmadji and Moeljono.

[SLUGLINE]{name="Crushing Disappointment" category="scene" date="29 July 1947" location="Maguwo" exact_date="True"} Bambang feels crushing disappointment when his fighter is grounded moments before the squadron took off to bomb Dutch positions. He could only stand on the tarmac and watch Moeljono fly away to glory.
