---
status: new
title: Our Hotel in Bali

---
[Our Hotel in Bali]{cat="scene"}[5 October 1988]{cat="date"}  Julia is processing a shipment of English-language
books about Indonesia for inclusion in the library collection when one book,
*Our Hotel in Bali*, catches her eye. The author is Louise Koke, and a 
quick glance at the contents confirms that Louise is the wife of Robert
Koke. The book about the couple establishing Bali's first "bohemian-chic"
hotel in the 1930s. The portrait of Robert Koke emerging from the pages
wholly contradicts the perception of a CIA officer seeking to
destabilize a regime. 

[Master of Dissemination]{cat="scene"}[6 October 1988]{cat="date"}  Julia tells Cameron about her discovery that Robert Koke had run a hotel in Bali, and that his seeming empathy and respect for Indonesians -- or at least the Balinese. Cameron
dismisses her, insisting that CIA agents are masters at dissemination.
Julia is annoyed and offended, but remains silent. Instead, she sends a
letter to Koke through the book's publisher, expressing her interest about his time in Batavia. 
