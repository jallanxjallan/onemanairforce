---
status: rework
name: Javanese Crew
---
[SLUGLINE]{name="Javanese Crew" category="interview" date="12 July 1988" location="Soeparto Residence"} Muharto takes Cameron to visit Pang Soeparto. Pang is effusive in praising Muharto for winning the court case for the quinine, and tells of how Freeberg kept up spirits during the weeks of penury in August 1947 as they were trying to sell the quinine and return home. 

[SLUGLINE]{name="Javanese Selebrities" category="interview" date="10 June 1947" location="Manila"}Pang has fond memories of partying with Freeberg, Muharto, and Boediarjo when they sold the quinine in September 1947, and how Captain Ignatio Espina, the Filipino army commando who they would be taking back to Jogja to train youth militias, become so boisterously drunk that Freeberg and the other pilots had to restrain him. 

[SLUGLINE]{name="Javanese Crew" category="scene" date="12 July 1988" location="Soeparto Residence"}Muharto's face clouds, and tells Pang they must be going now. Cameron asks Muharto why they are in such a hurry, but he does not respond.
