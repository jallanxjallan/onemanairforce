---
status: final
name: Charismatic Artist
---
Julia's curiosity about Emeria grows in the days after meeting Victor. [SLUGLINE]{name="Charismatic Artist" category="research" date="15 July 1988" location="Library"}  She researches
Emeria in the art publications from the period, learning that she had been was the
first female Indonesian painter of modern art, with extensive connections at the highest levels of both Dutch and Indonesian society. Julia reads about her passionate defense of artistic freedom in a review of an Indonesian artist exhibition at the Kuntzkrieg. 

[SLUGLINE]{name="Defending Hendra" category="scene" date="21 October 1947" location="Kuntzkrieg"} Emeria gives a forceful defense of Hendra Gunawan and his heroic depictions of Indonesian freedom fighters at an exhibition.

[SLUGLINE]{name="Finding Hendra" category="research" date="15 July 1988" location="Library"} Julia looks for mentions of Hendra in local publications, finding nothing. She eventually stumbles upon an article in a foreign arts review, which provides enough clues for her to discover that Hendra is still alive and lives in a Jakarta kampung. 

