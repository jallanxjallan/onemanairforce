---
status: final
name: Birth of RI-002
---
[SLUGLINE]{name="Birth of RI-002" date="28 June 1988" location="Muharto Residence category="inteview" exact_date="True"} Petit Muharto, a lively, dapper Indonesian in his late 60s, is sitting
with his wife Ani in their cosy living room in a Jakarta suburb when
they hear the roar of a large motorcycle approaching. Muharto, in jest,
covers his ears, and is then surprised when the motorcycle stops in
front of their house. A moment later, there is a knock on the door. His wife Ani
opens it to find Cameron Bishop, an engaging, disheveled young American freelance journalist, who says has an appointment to interview Muharto about his experiences during Indonesia's post-war struggle for independence. Muharto recovers from his astonishment that a "Hell's Angel" has come to interview him, and begins by telling Cameron of a message he received one morning at his desk in Maguwo air base in Jogjakarta.

[SLUGLINE]{name="Surprise message" date="08 June 1947" location="Maguwo" category="scene" exact_date="True"}  Muharto is surprised to be given a message from Army Lieutenant Pang Soeparto, stationed in Tasikmalaya, informing him that a foreign pilot
had landed an unmarked cargo aircraft on a nearby beach and,
astoundingly, had asked for Muharto by name. Muharto takes this
information to his commander, Suryadarma, who tells him to fly to Tasikmalaya
and find out which of Muharto's "foreign flyboy friends" it might be. 

Muharto flies to the army base at Tasikmalaya, where he meets Pang Soeparto. They load two barrels of aviation fuel onto a jeep and drive to Cilotok Beach. On arrival, Muharto recognizes Freeberg as the pilot of a previous blockade run that Muharto had organized. Muharto and Pang
marvel that Freeberg had been able to land on this short stretch of
beach, bookended by high bluffs.  Fearing that a patrolling Dutch fighter could appear
at any time, Muharto, in a stirring speech, implores the assembled
villagers to tear apart their houses to fashion an improvised runway
from the bamboo mats used as walls. They do so, and with Muharto and
Pang on board, the Dakota takes off and flies to Maguwo.

In Jogja, Suryadarma contracts Freeberg to fly a load of high-value quinine and vanilla to Manila, returning with much-needed vehicle parts and medicines. As the war-surplus Dakota has not yet been registered, Muharto suggests they paint the numbers RI-002 on the tail to forestall problems with aviation authorities. 

Freeberg flies RI-002 to Manila with Muharto, Pang Soeparto, and Budiardjo, a young airman, like Muharto fluent in English and Dutch, who will operate the radio. In Manila, Freeberg and his "Javanese Crew" become media celebrities, but are stranded their for months fighting the efforts of Dutch diplomats for ownership of the cargo. Freeberg is also in court, attempting to reach an agreement with Bob Walters, his former partner, over ownership of RI-002. 

Muharto and Pang finally win their case, sell the quinine, and RI-002 returns to Jogja. For the next six months, Freeberg, often with Muharto in the co-pilot seat, links the besieged Republic of Indonesia with the rest of the world. Freeberg is hailed as a hero, gaining the respect of everyone from common citizens to President Soekarno himself. 

Freeberg's haggard appearance and premature greying reflects the constant strain of being the Republic's "One Man Air Force". In May 1948 Muharto is offered a promotion to major and reassignment to a desk job. Worried about his friend, Muharto considers declining the promotion. However, he is now engaged to his girlfiend Ani, and must think about their future. 

Busy with his own duties, Muharto sees little of Freeberg until 30 September 1948, when he visited his friend as he was readyng RI-002 to ferry Republican gold to safety in Sumatra ahead of a feared invasion of Jogja. Freeberg had seemed tired and distracted, nothing like the cheerful, competent pilot of the previous year. RI-002 was reported missing on the following day. Army units in Sumatra searched for the wreckage until the Dutch overran all Republican-controlled areas in December 1948.

[SLUGLINE]{name="Wartime Regrets" date="28 June 1988 location="Muharto Residence" category="interview"} Muharto tells Cameron that the wreckage of RI-002 was discovered in April 1977 on a remote mountain. He shows Cameron a newspaper report that that no gold was found, only a few skeletal fragments. A photograph dated 29 July 1977 in the Air Force magazine shows the five coffins containing the remains of the Indonesian crew being loaded onto a truck, while a sixth coffin, larger that the others, remains behind.  Muharto tells Cameron that none of the remains were ever identified. Muharto wonders if he had elected to continue flying with Freeberg, the tragedy might have been averted.    

