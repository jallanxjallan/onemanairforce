---
status: new
name: Life During Wartime

---
[SLUGLINE]{name="Life During Wartime"}  Cameron and Julia have dinner with Muharto and
Ani. Afterward, Cameron and Muharto fall deep into discussion about the
revelations of their investigations. Ani and Julia agree that their men
are plummeting down a conspiracy rabbit hole, but keep their
views to themselves. Instead Ani tells Julia stories about when her husband
was a dashing young officer, and of the hardships of life in besieged
Jogja.

[SLUGLINE]{name="Rice Kitchen"}  Ani helps out at a communal kitchen to
feed the thousands of refugees pouring into Jogjakarta. She is
overwhelmed, never having set foot in a kitchen in her life, but soon
sees how the process could be more efficient and orders the cooks to form
an assembly line.



[Get a desk job]{cat="scene"}[07 April 1948]{cat="date"}  Ani's father questions Muharto about his career
path. He notes that as nominal co-pilot of RI-002 he is no more than an
airborne truck driver. If he wants to marry his
daughter, he will need to put himself on a fast promotion track by
assuming managerial duties at headquarters.
