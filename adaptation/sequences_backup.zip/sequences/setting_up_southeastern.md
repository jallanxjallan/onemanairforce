---
status: rethink
n: Setting Up Southeastern
---
[Setting Up Southeastern]{cat="scene"}[04 March 1947]{cat="date"}  Bob partners with Singapore-based businessman Hugh Savage to start Southeastern Airlines.

[Buying War Surplus]{cat="scene"}[04 March 1947]{cat="date"}  Bob Freeberg joins with Bob Walters to purchase a
war-surplus Dakota. They agree to equal ownership of the craft, and will
equally contribute to making it airworthy.

[Palm Beach Suits]{cat="scene"}[1 February 1947]{cat="date"}  Freeberg realizes that as a businessmen Bob must dress in more than flight gear. With post-war shortages driving up the cost of textiles in Southeast Asia, he decides to order Palm Beach suits from the US.

[Missing Dakota]{cat="scene"}[01 April 1947]{cat="date"}  Bob returns to Manila to find the jointly owned Dakota
is missing. Suspecting an April Fools joke, Bob plays along, but becomes
concerned when the aircraft does not reappear. Bob does not confront
Walters, Instead, he discovers the location, and moves it himself to
another strip on the outskirts of Manila.
