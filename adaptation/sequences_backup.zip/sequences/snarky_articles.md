---
status: final
name: Snarky Articles
---
[SLUGLINE]{category="research" date="6 July 1988" name="Snarky Articles" location="Library"}  Cameron enlists Julia's
assistance to research the history of RI-002. Julia is eager to help, and disappears into the stacks,
emerging with bound volumes of Dutch-language newspapers. She sight-translates news articles printed in the days after the aircraft disappeared. 

[SLUGLINE]{category="scene" date="05 October 1948" name="Claiming Ignorance" location="Library"}  Jan Boon, a reporter from the Bataviaasch Nieuwsblad newspaper,
accosts General Spoor in the hallway and badgers him for information of
the fate of RI-002. Spoor claims ignorance, and grows visibly annoyed
when the reporter press him, breaking off the interview and slamming the
door to his office.

[SLUGLINE]{category="research" date="6 July 1988" location="Library" name="A Possible Source"} Julia notes that the snide tone of the language in the article suggests
the reporter was convinced that Spoor was hiding something. She suggests
they might get more information from Victor de Jong, a Dutch-born,
naturalized Indonesian photographer who consults for the museum. Victor,
Julia explains, had been working in KNIL headquarters as an assistant
photographic technician and reporting directly to Spoor. 

Julia telephones Victor, confirms he is in IPPHOS, the photographic archives he manages. To Cameron's surprise, Julia informs her colleagues that she is leaving early and beckons Cameron to follow her out the door. In the parking lot, Julia is nonplussed to see their transportation: Cameron's 
Harley Davidson motorcycle. During the thrilling
ride to IPPHOS, she briefly grabs Cameron's waist, to her embarrassment. 

