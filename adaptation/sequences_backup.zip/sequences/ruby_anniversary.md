---
status: new
title: Ruby Anniversary

---
[Ruby Anniversary]{cat="scene"}[24 October 1988]{cat="date"}  Julia and Cameron attend the 40th wedding anniversary of Ani and Petit Muharto. 
[Joy and Sadness]{cat="scene"}[24 October 1948]{cat="date"}  Ani and Muharto marry. The day is marked by equal
measures of joy and sadness, as the absence of Bob Freeberg weighs heavy
on Muharto's heart.

[Westerling Sweep]{cat="scene"}[27 December 1948]{cat="date"}  A Dutch patrol stops Muharto and Ani as they return
home. The soldiers point to Muharto's khaki shorts and accuse him of
being in the military. Ani summons all the imperious passion of a
high-born Javanese women to give the commanding officer a vicious tongue
lashing, diverting attention while Muharto swallows his Air Force
identification.
