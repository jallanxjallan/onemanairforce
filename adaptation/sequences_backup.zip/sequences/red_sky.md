---
status: new
title: Red Sky

---
[Cadres Sneak In]{cat="scene"}[15 June 1948]{cat="date"}  In mid June 1948, Cobley repatriates communist cadres exiled during the
colonial era. He secretly transports them to isolated Campurdarat lake
in eastern Java where they continue to Madiun.
