---
status: new
title: Prodigal Pilot Returns

---
[Prodigal Pilot Returns]{cat="scene"}[15 August 1948]{cat="date"}  Bob flies RI-002 from Manila to Jogja. Both the pilot
and aircraft have are in top condition, and Bob looks forward to getting
back to work.

[No Fuel For You]{cat="scene"}[04 September 1948]{cat="date"}  Suryadarma takes away Fowler's fuel allowance. Fowler
resolves the issue by going over Suryadarma's head and complaining
directly to Muhammad Hatta.

[Reconciliation]{cat="scene"}[21 August 1948]{cat="date"}  Freeberg invites Boedi to share a bottle of whiskey
he brought from Manila. Boedi shows up with Muharto, and charms Freeberg
into speaking with his former "co-pilot" and reconciling their
differences.
