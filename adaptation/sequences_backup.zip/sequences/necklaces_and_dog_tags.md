---
status: new
title: Necklaces and Dog Tags
---
[SLUGLINE]{name="Necklaces and Dog Tags"}  Muharto and Cameron visit the widow and son of
Santoso. The son, Hadi, admits that the night before the ceremony he
talked a guard into letting him view his father's remains, and took a
necklace belonging to his father when the guard's back with turned. He
gave the neckace his mother, who was holding it at the ceremony the
following morning when she feel into trance and had a horrifying vision
of being in the cockpit as it crashed. Muharto asks to hold the
necklace. He intones prayers and matras and falls into a trance. He
opens his eyes to find he is in the RI-002 cockpit, this time sitting in
the co-pilot seat, where he had spent hundreds of hours. He turns to the
left, expecting to see Bob, but instead sees Bambang flying the Dakota.
