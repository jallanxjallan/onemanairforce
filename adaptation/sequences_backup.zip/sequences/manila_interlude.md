---
status: new
title: Manila Interlude
---
[SLUGLINE]{name="Suit Saga Ends"} Accepting that his ordered suits have been stolen in transit, Bob purchases tailor-made suits in Manila. 

Salipada Penatun offers to have Bob Walters deported. On the advice of Tom Lee, Bob declines the offer.

 Bob finally receives his share from the sale of the
quinine. He sends a sizable amount to an automobile dealership in
Parsons to purchase an Oldsmobile for his parents.

Muharto shops for clothes for his fellow
officers.
