---
status: new
title: Pemuda Pancasila Threatens

---
[Pemuda Pancasila Threatens]{cat="scene"}[07 December 1988]{cat="date"}  Leaving the Earthquake, Cameron is
waylaid by Pemuda Pancasila thugs. Sanyoto appears, and whacks the
leader on the nose with his cane.

[The Godfather Card]{cat="scene"}[07 December 1988]{cat="date"}  Sanyoto arranges meeting with Yapto, the head of
the Pemuda Pancasila. Yapto is affable, and expresses a sincere
apology for the unpleasantness with his boys, which must have been a
case of mistaken identity. Yapto gives Cameron a signed business card to
show to any Pemuda Pancasila members who might threaten him in the future.
