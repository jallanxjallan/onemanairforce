---
status: new
title: Trusted Companion
---
[Trusted Companion]{cat="scene"}[1 December 1988]{cat="date"}  Julia learns that Spoor's bodyguard, Hermann Bennick, left KNIL after Spoor's death and took Indonesian citizenship. She tracks him down. Hermann tells Julia that Spoor asked him to investigate Spoor's suspicion of corruption in KNIL. Hermann believes that Spoor had been poisoned because he was about to purge corrupt officers. 