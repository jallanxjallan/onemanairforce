---
status: new
title: A Real Pilot

---
[A Real Pilot]{cat="scene"}[07 December 1988]{cat="date"}  George Rueneker introduces Cameron to Captain
Jack, who had flown with Dave Fowler on oil-field supply runs. After marrying an Indonesia women from Flores he embraced Christianity and now flies missionary aircraft in Papua. For this, George calls him a real pilot and treats him with enormous respect. During
the hundreds of hours they spent together in the cockpit, Captain Jack
had heard all of Fowler's stories, and is happy to repeat them to
Cameron.

[Landing Gear Collapse]{cat="scene"}[04 May 1948]{cat="date"}  The landing gear collapses just as RI-002 is
preparing to take off from the strip at Bukittinggi. Bob checks the wing
for damage, and decides that the new crack in not serious. Later that
morning he takes off. Dave Fowler looks on, shaking his head.

[Fighter Planes Disengage]{cat="scene"}[10 September 1948]{cat="date"}  While flying a group of international journalists
to Jogja under cover of darkness, Fowler believes he spots fighter
planes tailing him. His radio operator hears traffic on Dutch military
frequencies. When when Fowler looks again, the fighters are gone.

[Spite Their Face]{cat="scene"}[21 September 1948]{cat="date"}  Over whiskey with Muhartoat Hotel Merdeka Freeberg and Fowler complain about Suryadarma cutting off his fuel allowance because they act like commercial aviation pilots, not serving Air Force officers. 

[Golden Refusal]{cat="scene"}[29 September 1948]{cat="date"}  Suryadarma orders Fowler to transport a quarter ton
of gold to Bukittinggi. Fowler refuses the commission as being too
risky. Suryadarma has no choice but to turn to Bob Freeberg.

[Night Patrol]{cat="scene"}[10 September 1948]{cat="date"}  Spoor orders a night patrol not to engage a
blockade running POAS flight because he is informed that civilians are passengers.
