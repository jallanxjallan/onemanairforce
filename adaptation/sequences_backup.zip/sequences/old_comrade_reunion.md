---
status: final
name: Old Comrade Reunion
---
[SLUGLINE]{name="Old Comrade Reunion" category="scene" date="10 July 1988" location=Muharto Residence"}  Muharto organizes a meeting of former RI-002 crew, who tell stories of flying with Freeberg in 1947. One tells of flying paratroopers to Kalimantan in [SLUGLINE]{name="Kalimantan Paratroopers" category="scene" date="10 October 1947" location="RI-002"}. It was the first jump for all, and they had been reassured by the calm, confident presence of Freeberg at the controls. Another relates a humorous story of Thai authorities detaining Freeberg on what was supposed to be a day trip to Bangkok. Freeberg was put up in a comfortable hotel, but the crew was forced to seek accommodation in the only place they could afford: the rolicking bar district.  

