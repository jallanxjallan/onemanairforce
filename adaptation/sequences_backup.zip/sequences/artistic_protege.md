---
status: final
title: Artistic Protege
---
[SLUGLINE]{name="Artistic Protege" category="research" date="1 September 1988" location="Library"}  Julia reads a review of an exhibition conducted in Jakarta some years before
by an amateur watercolorist named Regina Artista Maya. In the article, Regina credits Emeria as a major influence. Julia contacts the exhibition venue, acquires Regina's contact information, and arranges a meeting. 

[SLUGLINE]{name="Life in the Salon" category="interview" date="5 September 1988" location="Regina Studio"} Regina tells Julia that she hails from a village in the ancestral region of Emeria's family. When she turned 16 she was sent to Batavia to work as a domestic helper for Emeria, who would sponsor her education. She remembers Emeria as being highly intelligent and charismatic, with many friends.  

[SLUGLINE]{name="Artistic Inspiration" category="scene" date="10 October 1947" location="Regina Salon"} Regina brings steaming plates of food to a table where Emeria sits with guests. One guest, a young Dutchman, rises and says he has to leave. The others protest, saying it is only 9 pm, but the youth is adamant and takes his leave. Auke Sonnega laughs and says: "Has to be back in the barracks by curfew. If I were him I would defect!"

