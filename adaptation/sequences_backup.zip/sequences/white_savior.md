---
status: final
name: White Savior
---
[SLUGLINE]{name="White Savior" date="29 June 1988" location="Jakarta Times" category="scene"}  Cameron submits his article to Syd Jardine, a retired foreign correpondent assisting the Jakarta Times, a start-up English-language newspaper, as a copy editor.  Syd remarks that Freeberg comes across as a "white savior" singlehandedly responsible for Indonesia gaining freedom from the Dutch. He notes that there were many foreign pilots helping the Indonesians, and suggests Cameron do his own research to add historical context.
