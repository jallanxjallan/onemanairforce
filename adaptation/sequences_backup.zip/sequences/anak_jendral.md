---
status: transferred
name: Anak Jendral
---
Julia tells Cameron that she is meeting friends, all daughters of generals or high officials, for coffee at the Mandarin Hotel. That hotel is also the watering hole for the foreign press, so Cameron offers to give her a lift and then meet his colleagues for a beer. 

Julia's friends are impressed to see them roaring up the the hotel entrance on the Harley. In the coffee shop, they grill her about Cameron. Julia insists that they have only a professional relationship: research assistant to a journalist. When they are about to leave, Julia tries to contribute to the bill, but her friends laugh, saying "Honest Eddy's daughter has to save her money! Maybe you should get more friendly with Harley Boy." 



