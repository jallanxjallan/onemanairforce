---
status: new
title: Julia in Jogja

---
[Art Teacher]{cat="scene"}[07 December 1988]{cat="date"}  Julia tracks down Emiria teaching art to children
in a village on the outskirts of Jogja. Emeria reveals that she after
independence she traveled to the Netherlands on a "colonial guilt"
scholarship and married a Dutch academic. On his retirement, they moved to Jogja. Emeria regrets using Victor, but says
that in war you have to choose sides.

[Hard Truth]{cat="scene"}[07 December 1988]{cat="date"}  Julia tells meets Victor to tell him about her
encounter with Emeria. Victor now confesses to Julia that he did not
resign from KNIL after independence, but deserted during the taking of
Jogja so he would be with Emeria. Julia then explains that Emeria was
just using him to get information about Spoor. Victor does not speak as
he turns away to sort photographs.
