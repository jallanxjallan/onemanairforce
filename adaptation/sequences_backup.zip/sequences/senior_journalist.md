---
status: new
title: Senior Journalist

---
[Senior Journalist]{cat="scene"}[1 December 1988]{cat="date"}  Julia discovers Jan Boon is still alive and arranges an interview