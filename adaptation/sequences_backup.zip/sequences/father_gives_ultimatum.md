---
status: new
title: Father Gives Ultimatum
---
[SLUGLINE]{Father Gives Ultimatum]{cat="scene"}[15 May 1948]{cat="date"}  Muharto visits the father of Ani to ask for her hand. The father says he will give his blessing only if he accepts the promotion and takes a desk assignment. 

