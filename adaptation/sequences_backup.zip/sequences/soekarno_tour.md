---
status: new
title: Soekarno Tour

---
[Safety First]{cat="scene"}[15 June 1948]{cat="date"}  During the Soekarno tour, Bob refuses Soekarno's order
to land on unsafe airfield. Soekarno is annoyed, but then commends Bob
for standing up to him.

[Hustling for a job]{cat="scene"}[15 June 1948]{cat="date"}  Bambang ingratiates himself with
Soekarno in the hope of being selected to fly RI-001. Boedi finds his
efforts, and Soekarno's condescending replies, amusing.

[The American Friend]{cat="scene"}[21 June 1948]{cat="date"}  During a speech on an airstrip, Soekarno stands on the
RI-002 wing and speaks to a small, enthralled crowd of local residents.
Toward the end of the speech, Soekarno points to Bob in the cockpit,
proclaiming: "This is Bob Freeberg, a brave, good man and a friend of
all Indonesians"

[Contract Aviator]{cat="scene"}[01 July 1948]{cat="date"}  On his return to Jogja, Suryadarma orders Bob to Sumatra on another mission. Bob
refuses, and infuriates Suryadarma by flying to Manila that day.
