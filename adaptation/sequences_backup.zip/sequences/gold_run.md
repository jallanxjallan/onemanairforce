---
status: new
title: Gold Run

---
[Gold Run]{cat="scene"}[30 September 1948]{cat="date"}  Suryadarma reluctantly assigns Bob Freeberg the mission to
transport gold to Bukittinggi.

[Documentary Shoot]{cat="scene"}[25 September 1988]{cat="date"}  Tom Lee accompanies the last RI-002 flight to Jogja to
"study veterans claims". Tom and Bob apply for a license to shoot a
documentary film.

[Southeastern Crashes and Burns]{cat="scene"}[29 September 1948]{cat="date"}  Hugh Savage tells Bob that Southeast Airlines has
failed, their one aircraft has been repossessed, and he has lost his
investment.

[Loading The Gold]{cat="scene"}[30 September 1948]{cat="date"}  Muharto visits Bob as he is preparing RI-002 for the flight to Gorda. He reminds Bob that his wedding is scheduled for three weeks away. 

[Last Flight Of RI-002]{cat="scene"}[05 October 1948]{cat="date"}  Bambang takes control and flies back to Branti. When
they reach the mountain range on the border with Republican controlled
Lampung, the escorting fighters attack. Bambang dives into valleys,
recreating what Bob did the previous week.
