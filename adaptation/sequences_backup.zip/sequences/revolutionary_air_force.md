---
status: new
title: Revolutionary Air Force

---
[Revolutionary Air Force]{cat="scene"}[21 November 1988]{cat="date"}  Julia finds Muharto's name mentioned in article
about Permesta, the failed military rebellion against the Soekarno government. "Colonel" Muharto had commanded the Revolutionary Air
Force, a squadron of fighters and bombers provided by the CIA, and had
participated in at least one bombing raid himself. One of the CIA
pilots, Allen Pope, had been shot down and captured, embarrassing the
US. The Revolutionary Air Force was disbanded soon afterward, and
Muharto and his family had fled to exile in Malaya.

[Growing Doubt]{cat="scene"}[22 November 1988]{cat="date"}  Julia confronts Cameron with the evidence that
Muharto was the point man for the CIA air force. Cameron insists that
Julia has misinterpreted the article.
