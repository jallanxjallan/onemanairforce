---
status: new
title: Madiun Rebellion

---
[Leaflets Over Madiun]{cat="scene"}[28 September 1948]{cat="date"}  RI-002 drops leaflets over Madiun. Santoso is
valuable in pointing out neighborhoods where residents may be receptive
to message from government to stay loyal to the Republic. On the return  
Bambang closely watches Bob demonstrate how to guide RI-002 through low-level
maneuvers to evade enemy fighters.
