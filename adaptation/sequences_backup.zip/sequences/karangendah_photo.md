---
status: new
title: Karangendah Photo

---
[Karangendah Photo]{cat="scene"}[15 December 1988]{cat="date"}  Julia finds a photo in a misfiled volume of  BN.
The image shows a Dakota with "002" painted on the nose guarded by a
KNIL soldier. 
