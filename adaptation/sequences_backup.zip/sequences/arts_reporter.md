---
status: new
title: Arts Reporter

---
[Arts Reporter]{cat="scene"}[25 November 1988]{cat="date"}  Julia finds a decade-old magazine article profiling Jan Boon as a pioneering journalist who elected to take Indonesian citizenship. The magazine editor confirms that Jan Boon is still living in Jakarta, and gives Julia his contact info. 
