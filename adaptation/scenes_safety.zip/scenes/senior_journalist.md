---
category: research
date: 1 December 1988
location: Library
name: Senior Journalist
status: new

---
Julia discovers Jan Boon is still alive and arranges an interview