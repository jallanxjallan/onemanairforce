---
category: past
date: 05 October 1948
status: rework
title: Last Flight of RI-002
---


Bambang takes control and flies back to Branti. When
they reach the mountain range on the border with Republican controlled
Lampung, the escorting fighters attack. Bambang dives into valleys,
recreating what Bob did the previous week.
