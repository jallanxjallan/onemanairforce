---
category: past
date: 04 August 1947
status: synopsis
title: Money For Nothing

---

Muharto attempts to pay for their meals at
Madras Curry, explaining that it is an honorarium for a talk about the
Indonesia struggle for freedom to a group of women lawyers. To his
surprise, Bob chastises him for "taking money for nothing".
