---
status: draft
title: Julia and her friends
date: 7 July 1988
category: present
synopsis: "Julia's friends urge her to get closer to Cameron, noting that her father, who unlike theirs only mildly corrupt, cannot afford to send Julia to graduate school in America."     
---
Julia tells Cameron that she is meeting friends at the Mandarin Hotel. That hotel is also the watering hole for the foreign press, so Cameron offers to give her a lift and meet his colleagues for a beer. Julia ponders a moment, but finally agrees. 

Cameron and Julia roar up tp the front entrance. The doorman is a Harley owner himself, and let's Cameron park near the door. 

Cameron and Julia walk into the lobby together,
where her friends are waiting. Julia introduces Cameron to them, then he
walks toward the bar, while Julia and her friends proceed to the coffee shop. 

Julia friends grill her about the bule. Julia insists that they have only a professional relationship, research assistant to a journalist. When they are about to leave, Julia tries to contribute to the bill, but her friends laugh, saying "Honest Eddy's daughter can't afford to pay for her own drinks!" If she
wants to do that, they say, she had better get friendly with Harley
boy.

