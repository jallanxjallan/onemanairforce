---
status: synopsis
title: Muharto Flies to Tasik
date: 7 June 1947
category: past
synopsis: Muharto flies to Tasik, thinking about who the mystery pilot might be. He remembers his final blockade run two months previously, with Bob Freeberg as captain.
---
Muharto flies to Tasik in a Nikosoren, was one of a score barely serviceable planes the Japanese had left behind. The air force mechanics kept these aircraft flying through skill and guesswork, but Muharto was aware that any flight could end in disaster. To keep his mind from this eventuality, Muharto  thought about the American pilots he had met during the blockade runs he had organized from Singapore to Jogjakarta. He  decided that only Bob Freeberg possessed the skill and nerve to land at night on a remote beach. Bob had been the pilot of the third blockade run. Though these had been standard charter flights -- they even had a flight attendant, a lovely Filipina named Miss Brown -- the third flight would test the skills of any aviator.  
