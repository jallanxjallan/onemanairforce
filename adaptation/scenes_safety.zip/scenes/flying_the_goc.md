---
category: past
date: 30 October 1947
status: omit
title: Flying The GOC
---

Bob flies three United Nations representatives to
Sumatra, where they will assess popular support for the Republic.
