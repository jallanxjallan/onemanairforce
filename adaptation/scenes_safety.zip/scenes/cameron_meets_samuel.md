---
status: draft
title: Cameron Meets Samuel
date: 15 August 1988 
category: present
synopsis: Syd takes Cameron to the Earthquake to hear a keroncong band beloved by the older clientele. Sanyoto introduces Cameron to Samuel Quiko, the band leader.
---
One evening at the Earthquake, the music is supplied by a band playing keroncong, a
guitar-driven genre that features sentimental Dutch-language lyrics.
Regarded as "music for old folks" the audience of senior and retired
military officers laps it up. Afterward, Sanyoto introduces Syd and
Cameron to Samuel Quiko, the band leader. Sanyoto mentions that Samuel
had been active in the revolution, and might have interesting stories to
tell.