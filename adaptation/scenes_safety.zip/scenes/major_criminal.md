---
category: past
date: 15 April 1948
status: synopsis
title: Major Criminal
---


Spoor learns that RI-002 is flying the Republican
stockpile of opium to Bukittinggi. He decides to brand Freeberg as a
narcotic smuggler, which would allow his fighters to use deadly force if
they encounter RI-002.
