---
category: present
date: 22 July 1988
status: draft
title: Eric explains corruption
synopsis: Julia has an arranged dinner with Eric, son of a family friend. Eric boasts that their respective parents are cooking up a business deal involving selling insider information to foreign investors. 
---


Julia is sitting in a restaurant
with Eric, a young Indonesian man of good family. Eric mentions his
surprise Julia's mother phoned his mother to suggest he take her to
dinner. Eric dominates the conversation, insisting, with the
authoritative confidence typical of the offspring of new wealth, how he
is an essential component in the business deal that their respective
fathers are cooking up. Julia wants more details about this "business
deal", but decides it would be better to remain silent.
