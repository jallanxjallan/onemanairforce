---
status: rework
title: Eddy Warns Julia
date: 9 July 1988
category: present 
---
"Pak Eddy" lectures Julia at the breakfast table of their home. He warns his daughter against getting into a relationship Cameron, who is penniless and
with a spotty academic record. Julia retorts that her relationship with
Cameron is purely professional. If the story they are researching
results in a book, her expert facilitation will look good on a future
application for graduate school. Eddy  does state that since Julia is his only child, he will do anything for her, including sending her off to school in a foreign land, it that is what she truly wishes. Julia reminds him that
his nickname is "Honest Eddy" and that his only income is his military
wage. Eddy replies that he is making arrangements. Julia is doubtful,
but agrees to go along with whatever he plans, as long as it is not an
arranged marriage to some rich brat.Eddy has a heart-to-heart talk with
Julia, letting her know that he opposes Julia marrying a foreigner. 
