---
category: wrapper
date: 6 July 1988
title: Julia Suggests Victor
status: draft
synopsis: Julia suggests they speak to Victor de Jong, a Dutch conscript who was posted in Spoor's office and stayed on to become an Indonesian after independence. 
---

Julia notes that the snide tone of the language in the article suggests
the reporter was convinced that Spoor was hiding something. She says
they might get more information from Victor de Jong, a Dutch-born,
naturalized Indonesian photographer who consults for the museum. Victor,
Julia explains, had been a working in KNIL headquarters as an assistant
photographic technician/analyst and reporting directly to Spoor. She telephones Victor, confirms he is in his office, and somewhat to Cameron's surprise, informs her colleagues that she is leaving early and beckons Cameron to follow her out the door. 

In the parking lot, Julia is nonplussed to see their transportation: Cameron's 
Harley Davidson motorcycle. During the thrilling
ride to IPPHOS, she briefly grabs Camerons waist, to her embarrassment. 
