---
category: past
date: 04 May 1948
status: draft
title: Landing Gear Collapse
synopsis: RI-002 cracks a wing when the landing gear collapses prior to takeoff. 
---


The landing gear collapses just as RI-002 is
preparing to take off from the strip at Bukittinggi. Bob checks the wing
for damage, and decides that the new crack in not serious. Later that
morning he takes off. Dave Fowler looks on, shaking his head.
