---
category: past
date: 07 May 1948
status: draft
title: Not Ready For Airplanes
synopsis: Freeberg is furious when Bambang shows up too late for an opium run, forcing him to cancel the mission, saying that Indonesian are not ready for airplanes. 
---


Bob waits in the pre-dawn gloom for Bambang and the
crew to show up for an opium run that must be completed before sunrise. It is well after dawn, when they drive up, laughing and
joking. Bob is furious, but keeps his voice measured, telling Bambang
and the others that they are "Not Ready for Airplanes", they jumping
into their automobile and telling the driver to take him back to the
hotel.
