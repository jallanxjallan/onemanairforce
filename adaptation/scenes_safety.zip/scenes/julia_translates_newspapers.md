---
category: research
date: 6 July 1988
status: synopsis
title: Julia Translates Newspapers 
---

Cameron returns to the library to enlist Julia's
assistance. Julia is eager to help, and disappears into the stacks,
emerging with bound volumes of Dutch-language newspapers. She reads
aloud, in English, some news articles printed in the days after the
disappearance.

