---
category: research
date: 15 July 1988
status: synopsis
title: Julia Researches Emeria
---

Julia's curiosity about Emeria grows in the days after meeting Victor. She researches
Emeria in the art publications from the period. learning that she had been was the
first female Indonesian painter of modern art, with extensive connections at the highest levels of both Dutch and Indonesian society. Julia reads about her passionate defense of artistic freedom in a review of an Indonesian artist exhibition at the Kuntzkrieg. 
