---
status: omit
title: Weekend in Jogja
date: 1 August 1988 
category: present 
---
Muharto and Cameron travel to Jogjakarta: Muharto on the train and Cameron on his Harley. Cameron arrives first, and visits the Affandi Musuem. 