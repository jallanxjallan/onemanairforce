---
category: present
date: 5 October 1988
status: draft
title: Julia Reads About Robert Koke
synopsis: Julia finds a book written by Robert Koke's wife. The depiction of Koke as a supporter of Indonesian independence contradicts the image of a CIA coup-monger.  
---


Julia is processing a shipment of English-language
books about Indonesia for inclusion in the library collection when one book,
*Our Hotel in Bali*, catches her eye. The author is Louise Koke, and a 
quick glance at the contents confirms that Louise is the wife of Robert
Koke. The book about the couple establishing Bali's first "bohemian-chic"
hotel in the 1930s. The portrait of Robert Koke emerging from the pages
wholly contradicts the perception of a CIA officer seeking to
destabilize a regime. 
