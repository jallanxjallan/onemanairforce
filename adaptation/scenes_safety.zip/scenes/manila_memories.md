---
category: interview
date: 12 July 1988
status: synopsis
title: Manila Memories
---


Muharto takes Cameron to visit Pang Soeparto.
Pang is effusive in praising Muharto for winning the court case for the
quinine, and how Muharto kept up spirits during the weeks of penury
trying to sell the quinine and return home.
