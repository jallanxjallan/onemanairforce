---
category: past
date: 28 September 1948
status: draft
title: RI-002 Drops Leaflets
synopsis: RI-002 drops propaganda leaflets over communist-held Madiun. 
---

RI-002 drops leaflets over Madiun. Santoso is
valuable in pointing out neighborhoods where residents may be receptive
to message from government to stay loyal to the Republic. On the return  
Bambang closely watches Bob demonstrate how to guide RI-002 through low-level
maneuvers to evade enemy fighters.
