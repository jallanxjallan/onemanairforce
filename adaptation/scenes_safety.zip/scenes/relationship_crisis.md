---
category: present
date: 1 November 1988
location: Jalan Jaksa
name: Relationship Crisis
status: new

---
Cameron voices suspicions to Syd that Julia is leaking information about the investigation. 