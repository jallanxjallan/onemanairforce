---
category: present
date: 1 September 1988
status: synopsis
title: Julia Meets Regina
---

Julia reads a review of an exhibition conducted in Jakarta some years before
by an amateur watercolorist named Regina Artista Maya, who credits Emeria as a major influence. Julia contacts the exhibition venue, acquires Regina's contact information, and arranges a meeting. 
