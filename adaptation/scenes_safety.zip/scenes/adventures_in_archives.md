---
category: interview
date: 5 July 1988
status: synopsis
title: Adventures in Archives
---

Muharto tells Cameron and Sid of the frustrations he encountered trying
to find clues to solve the mystery in official archives and libraries.
