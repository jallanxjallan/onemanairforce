---
category: past
date: 17 April 1977
status: synopsis
title: Crash Site Discovery
synopsis: Two farmers lead Air Force investigators to the RI-002 crash site, where they find human remains, but no gold. 
---


Two wiry men dressed in shabby clothes lead a squad of
airmen and their officer, Lt. Sulaiman, through a forested hillside to
the wreckage of RI-002. The airmen set up camp and search the area. They
find fragments of a wing with the faded letters: RI-00, other airplane
parts, including a dynamo with a bullet wedged between the windings and
armature. There are a few fragments of human remains, which the soldiers
reverently dig from the earth and carefully wrap in cloth. They also
find two empty wooden crates labeled: "Gold", but a thorough search of
the area does not find any trace of the treasure itself.
