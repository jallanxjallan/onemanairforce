---
category: present
date: 21 October 1988
status: synopsis
title: Cameron Suspects Robert Koke
---


Victor tells Cameron of
Robert Koke, who his Indonesian friends identified as a CIA operative.
Cameron becomes convinced that the newly formed CIA supported Walter
Foote and Spoor in their first attempt to foment a military coup against
the colonial government.
