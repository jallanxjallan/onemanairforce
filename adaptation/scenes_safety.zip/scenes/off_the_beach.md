---
category: past
date: 09 June 1947
status: draft
title: Off the Beach
synopsis: Muharto and Pang inspire villages to build a bamboo runway so RI-002 can take off before spotted by a Dutch patrol.
---

Muharto flies to the army base at Tasikmalaya, where he meets Pang Soeparto. They load two barrels of aviation fuel onto a jeep and drive to Cilotok Beach. On arrival, Muharto recognizes Freeberg as the pilot of a previous blockade run that Muharto had organized. Muharto and Pang
marvel that Freeberg had been able to land on this short stretch of
beach, bookended by high bluffs.  Fearing that a patrolling Dutch fighter could appear
at any time, Muharto, in a stirring speech, implores the assembled
villagers to tear apart their houses to fashion an improvised runway
from the bamboo mats used as walls. They do so, and with Muharto and
Pang on board, the Dakota takes off and flies to Maguwo.
