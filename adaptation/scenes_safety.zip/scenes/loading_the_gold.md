---
status: synopsis
title: Loading The Gold
date: 30 September 1948
category: past
---
Muharto visits Bob as he is preparing RI-002 for the flight to Gorda. He reminds Bob that his wedding is scheduled for three weeks away. 
