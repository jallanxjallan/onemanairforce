---
category: interview
date: 15 December 1988
status: synopsis
title: Verspoor Confesses
---

Cameron arranges to meet Alex and Paul at the
Earthquake the night before Paul will return to the Netherlands. After
several drinks, and with Alex urging him on, Paul reveals that
Westerling had contacted him in early 1949 to ask if his squadron would
support a coup against the colonial government. Verspoor knew that many
of his squadron would support Westerling, and so gave a vague,
noncommittal answer. Verspoor realizes his indiscretion, and begs
Cameron to not repeat this information, as most of his former comrades
are still alive.
