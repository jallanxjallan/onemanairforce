---
category: present
date: 15 July 1988
status: synopsis
title: Julia Pressures Victor
---


Julia returns to confront Victor with her suspicion that he and Emeria were lovers.  
