---
category: present
date: 21 July 1988
status: draft
title: Eddy Promises Funding 
synopsis: Colonel Eddy promises to make arrangdments to fund Julia's post-grad. Julia hopes that the arrangements to not include an arranged marriage to another anak jendral.  
---


Eddy tells Julia that he is determined to fulfill
the dream of his only child to study overseas. Julia reminds him that
his nickname is "Honest Eddy" and that his only income is his military
wage. Eddy replies that he is making arrangements. Julia is doubtful,
but agrees to go along with whatever he plans, as long as it is not an
arranged marriage to some rich brat.
