---
category: past
date: 04 August 1947
status: draft
title: Bob Walters Bitches
synopsis: Boedi has a beer with But another American aviator, Bob Walters, Freeberg's co-owner of RI-002, who calls Bob a thief and a con man.
---

The gregarious and charismatic Boedi has been wholly
accepted by the Aviation Brotherhood, the freewheeling foreign pilots
seeking their fortunes or reliving wartime adventures in often-dangerous
charter flights into remote areas of the region. At the AB bar, Boedi
learns more about Freeberg, particularly how his peers regarded him as the most skillful and courageous aviator in Southeast Asia. 



