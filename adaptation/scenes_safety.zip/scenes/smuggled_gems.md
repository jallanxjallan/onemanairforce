---
category: past
date: 15 April 1948
status: draft
title: Smuggled Gems
synopsis: Freeberg is furious to discover that Muharto has smuggled gems on RI-002 to trade for handguns.
---

At a party in Manila, Muharto is appalled when one of
Bob's housemates boasts of shooting down own squad leader. He decides to
not tell Bob of his plan to smuggle gems into Manila to be traded for
sidearms. He arranges for Filipino commandos to enter RI-002 and
retrieve the gems from a concealed niche. The following morning, Bob
notices that the cockpit had been disturbed, and confronts Muharto.
