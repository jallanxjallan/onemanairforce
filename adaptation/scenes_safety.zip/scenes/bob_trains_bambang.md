---
category: past
date: 04 October 1947
status: synopsis
title: Bob Trains Bambang
---

Bob checks out Bambang's qualifications to be co-pilot
of RI-002. Problems arise because of Bambang's weak command of English.
