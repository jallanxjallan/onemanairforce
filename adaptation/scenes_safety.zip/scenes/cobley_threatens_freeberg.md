---
category: past
date: 08 March 1948
status: draft
title: Cobley Threatens Freeberg 
synopsis: British aviator Richard Cobley threatens to damage RI-002 if Freeberg does not share his aviation contracts with the Republic.
---

One account of an incident in  shows how most aviators considered Freeberg the most skilled and courageous of their brotherhood, but were envious of how he seemed to monopolize contracts with the Republic. One pilot, Ralph Cobley, had openly threatened Frreberg if he did not "share the weath". 
