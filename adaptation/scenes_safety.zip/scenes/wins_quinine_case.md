---
category: past
date: 29 July 1947
status: synopsis
title: Wins Quinine Case
---


The judge rules in favor of Muharto and Pang and
releases the quinine to them. The Dutch protest, but the ruling is
final.
