---
status: synopsis
title: Cameron Interviews Sudaryono
category: interview
date: 15 July 1988
---
Sanyoto introduces Cameron to Sudaryono, one of the first tranche of cadet pilots. Sudaryono tells of going from a village boy who had only glimpsed a aircraft in flight to being at the controls of a high-performance fighter in only a few months. Sudaryono also relates amusing stories of the rivalry between the two best cadet pilots in the class: Bambang Sudarmadji and Moeljono.