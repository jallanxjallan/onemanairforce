---
category: past
date: 25 September 1988
status: synopsis
title: Tom Lee In Jogja
---


Tom Lee accompanies the last RI-002 flight to Jogja to
"study veterans claims". Tom and Bob apply for a license to shoot a
documentary film.
