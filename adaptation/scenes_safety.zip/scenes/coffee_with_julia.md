---
category: scene
date: 30 June 1988
status: draft
title: Coffee With Julia
synopsis: "Cameron has coffee with Julia, who casually informs him that her father is a military intelligence officer."
---

After an hour of research, Cameron asks Julia where he can get some coffee. Julia informs him that beverages are not allowed in the reading room, but since she is also due for a break, he can join her in the library canteen., Over coffee, She tells of her childhood in the Netherlands, where her father had been a military diplomat, her frustrations living in conservative, parochial Indonesia, and her dream of taking her post-graduate studies in America. . Cameron attempts, in turn, to tell of his dreams of
becoming an international investigative journalist, to be free to write
follow his own leads and write bestselling books. But Julia stops him,
saying, with a mischievous smile, that if she wants to know anything
about him she will simply ask her father, who is a senior officer in
military intelligence. Cameron puts down his coffee, looks around
involuntarily, then tells Julia it is time for him to get back to work.

Cameron is tired from reading. Julia invites him to join her for coffee in the canteen. When Cameron attempts to tell his story, she interrupts and, with a sly grin, says if she wants to know anything about him she will ask her father, who is now a colonel in Army intelligence.
