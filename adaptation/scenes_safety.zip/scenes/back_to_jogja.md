---
category: past
date: 24 December 1947
status: draft
title: Back to Jogja
synopsis: RI-002 returns to Jogja so Muharto can deal with the fallout from Ining's death. 
---

RI-002 returns to Jogja. Suryadarma tells Bob to lay
low while they deal with the fallout from Ining's death. Bob spends an
idyllic few days in Kaliurang, a resort on the slopes of Mount Merapi.
