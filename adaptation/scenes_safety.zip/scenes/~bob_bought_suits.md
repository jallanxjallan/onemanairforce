---
status: synopsis
title: Bob Bought Suits
date: 15 February 1948
category: past
---
Accepting that his ordered suits have been stolen in transit, Bob purchases tailor-made suits in Manila. 
