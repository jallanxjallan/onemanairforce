---
category: research
date: 07 December 1988
status: draft
title: Robert Koke Replies
synopsis: Robert Koke replies with accounts of his adventures as a CIA officer in Batavia.
---

Julia receives a letter from Florida. It is not
from Robert Koke, but a nephew, who explains that his uncle is reticent to talk
about his days with the CIA. Nevertheless, the nephew is enthralled by
the stories, so he used Julia's letter as an excuse to ply his uncle
with a few whiskeys to loosen his tongue. The nephew is a born storyteller himself, and Julia
is immediately drawn into the vivid descriptions of events in post-war
Batavia.
