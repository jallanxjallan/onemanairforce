---
category: past
date: 17 October 1947
status: draft
title: Kalimantan Paratroopers
synopsis: Bob and Boedi fly ten paratroopers to be dropped near an insurgent stronghold in the forests of Kalimantan. 
---

Bob and Boedi fly ten paratroopers to be dropped
near an insurgent stronghold in the forests of Kalimantan. None have
jumped before, or even been in a aircraft, so tension is high. There is
an uproar as the parachute of one trooper opens and dumps onto the cabin
floor. The trooper swears it was an accident, but all others accuse him
of cowardice. The troopers look at each other, wondering if any one will
be next. Boedi enters the cabin. Though he is only an airman, the
charismatic Boedi takes command of the situation, assuring the troopers
that Bob has much wartime experience flying paratroopers and will drop
them safely. He goes to the cockpit and talks with Bob for a moment. The
Bob turns the aircraft over to his co pilot, leaves his seat and stands
in the doorway, his body filling the frame. With Boedi translating, Bob
assures the troops that he has done this many times during the war, and
will drop them exactly on the requested target. Emboldened by Bobs air
of quiet competence, each trooper moves forward and shakes Bobs hand.
Bob returns to his seat, the dropmaster issues the command to jump, and
the cabin empties, save for the dropmaster and a lone recruit wondering
what fate is in store for him back at Maguwo. Boedi watches as the
parachutes drift down and land are enveloped by the endless forest.
Boedi asks Bob how many paradrops he made. Bob grins and answers: "None.
I was a Navy pilot. All my missions were over water."
