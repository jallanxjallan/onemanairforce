---
category: research
date: 20 July 1988
location: library
name: Finding Hendra
status: synopsis

---
Julia looks for mentions of Hendra in local publications, finding nothing. She eventually stumbles upon an article in a foreign arts review, which provides enough clues for her to discover Hendra's current location. 
