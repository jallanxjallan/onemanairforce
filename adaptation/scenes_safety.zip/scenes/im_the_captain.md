---
category: past
date: 15 June 1948
status: synopsis
title: Im The Captain
---


During the Soekarno tour, Bob refuses Soekarno's order
to land on unsafe airfield. Soekarno is annoyed, but then commends Bob
for standing up to him.
