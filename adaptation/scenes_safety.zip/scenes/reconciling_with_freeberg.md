---
category: past
date: 21 August 1948
status: synopsis
title: Reconciling With Freeberg
---


Freeberg invites Boedi to share a bottle of whiskey
he brought from Manila. Boedi shows up with Muharto, and charms Freeberg
into speaking with his former "co-pilot" and reconciling their
differences.
