---
category: past
date: 21 October 1947
status: synopsis
title: Last Corned Beef
---


Bob invites Muharto to join him for
dinner at the Hotel Merdeka. Bob is embarrassed when served the last can
of corned beef left by the GOC delegates.
