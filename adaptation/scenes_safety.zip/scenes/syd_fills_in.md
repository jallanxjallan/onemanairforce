---
category: present
date: 13 December 1988
status: synopsis
title: Syd Fills In
---


Cameron asks Syd to fill in while he takes three
days off to go to Karangendah. But the other copy editors flake out,
leaving Sid alone on the copy desk. He works three triple shifts,
getting his protein from whiskey and his vitamins from cigarettes.
