---
category: present
date: 07 November 1988
status: synopsis
title: Cameron Terrorized
---

Cameron receives a telephone call at his home. The gruff voice on the other end suggests
that Cameron stop poking into matters that are not his own business.
