---
category: interview
date: 21 July 1988
location: Hendra Studio
name: Political Artist
status: synopsis
---
Julia visits Taman Sari. Asking around, she is directed to Hendra's modest dwelling. Hendra is astonished, and wary, at the unexpected visit, but Julia wins him over. Hendra tells Julia of a frightening incident at Emeria's Salon. 
