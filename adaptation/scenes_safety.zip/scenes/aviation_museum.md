---
status: omit
title: Aviation Museum
date: 2 August 1988 
category: interview
---
Muharto takes Cameron to the Air Force museum, a re-purposed hanger filled with decommissioned aircraft and other exhibits. Muharto points to a model of the Zogling training glider, and tells Cameron of  the time he pulled rank and flew the Zogling himself.

