---
category: past
date: 28 December 1947
status: omit
title: Spoor Dumbfounded
synopsis: Spoor is dumbfounded when he reads that RI-003 was not running guns, but household items such as dinner plates and cutlery.
---

Spoor is dumbfounded when he reads the report on
the crash of RI-003. Spoor investigators discover that the plane, though
carrying medicine and spare parts, was not carrying guns. Instead, it
was overloaded with household items such as dinner plates and cutlery.
