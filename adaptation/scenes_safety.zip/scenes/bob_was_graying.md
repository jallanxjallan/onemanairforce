---
status: synopsis
title: Bob Was Graying
date: 25 November 1988
category: interview
---
Muharto tells Cameron that by early 1948 he had become worried about Bob as the demands of the missions took their toll. There was no mission too dangerous, no cargo too heavy for Bob, who cheerfully accepted each assignment. 