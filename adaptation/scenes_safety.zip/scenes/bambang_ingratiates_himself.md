---
category: past
date: 15 June 1948
status: synopsis
title: Bambang Ingratiates Himself
---


Bambang ingratiates himself with
Soekarno in the hope of being selected to fly RI-001. Boedi finds his
efforts, and Soekarno's condescending replies, amusing.
