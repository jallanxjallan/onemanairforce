---
category: interview
date: 07 December 1988
title: Captain Jack
status: synopsis
---

George Rueneker introduces Cameron to Captain
Jack, who had flown with Dave Fowler on oil-field supply runs. After marrying an Indonesia women from Flores he embraced Christianity and now flies missionary aircraft in Papua. For this, George calls him a real pilot and treats him with enormous respect. During
the hundreds of hours they spent together in the cockpit, Captain Jack
had heard all of Fowler's stories, and is happy to repeat them to
Cameron.
