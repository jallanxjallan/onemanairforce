---
category: past
date: 15 August 1948
status: synopsis
title: Bob Returns
---


Bob flies RI-002 from Manila to Jogja. Both the pilot
and aircraft have are in top condition, and Bob looks forward to getting
back to work.
