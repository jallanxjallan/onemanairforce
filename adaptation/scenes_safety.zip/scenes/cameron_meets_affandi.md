---
status: omit
title: Cameron Meets Affandi
date: 1 August 1988 
category: interview
synopsis: Cameron meets Affandi, who tells him of his activities as a painter during the struggle for independence. 
---
Cameron roars up the driveway of the Affandi Museum, in the process startling a
disheveled elderly man, is sitting on a bench on the grounds
of the compound, more resembling a homeless person seeking rest than the owner of this sprawling estate containing a fortune in paintings and sculptures. Affandi openly admires the motorcycle, and smiles in greeting as Cameron introduces himself. Affandi becomes effusive
when Cameron tells him he brings greetings from Boedi. They fall into animated
conversation. Cameron explains the purpose of his visit, and Affandi
launches into a humorous and poignant narrative of painting propaganda
posters amid the privation and danger of besieged Jogjakarta. 