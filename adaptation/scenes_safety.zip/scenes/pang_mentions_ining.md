---
category: interview
date: 12 July 1988
title: Pang Mentions Ining
status: synopsis
---


At the mention of Espina, Muharto's face clouds, and tells Pang they
must be going now. Cameron asks Muharto why they are in such a hurry,
but he does not respond.
