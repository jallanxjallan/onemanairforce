---
status: synopsis
title: Come What May
date: 10 June 1947 
category: past
synopsis: Muharto, Boedi, and Pang are anxious about their reception in Manila, but take inspiration from Freeberg, who flew to Java with inadequate charts and no idea of what he would find there. 
---
In the air, Muharto, Pang and Boedi worry about the reception they could expect in Manila.  what they will face in Manila. For Bang and Boedi this is their first trip out of Indonesia. Muharto shows his comrades the rudimentary chart that Bob used to navigate to Java, which shows important navigational landmarks as mere specks in the ocean. He tells the others that if Bob can dare to take risks for what he believes in then so can we. 