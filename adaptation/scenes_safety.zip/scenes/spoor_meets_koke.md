---
category: past
date: 15 October 1947
status: synopsis
title: Spoor Meets Koke
synopsis: Victor sees Robert Koke arrive with Walter Foote. He hears Koke speaking fluent Indonesian to a local soldier.
---


Walter Foote arrives at Spoor's office with a guest, Robert Koke. Julius
Tahija apologizes that Spoor will be busy for a few more minutes and
invites them to wait. Tahija calls out "Nyoman" (a common name in Bali)
to an office boy. Nyoman enters the room and asks what they would like
to drink while they wait. Koke replies in fluent Balinese. Nyoman is
astounded, and Koke explains that he lived in Bali for many years before
the war. Victor is intrigued, and chats with Koke, who is charming and
affable, but evasive. Julius calls them to enter, Victor follows, camera
at the ready. Spoor waves him away, saying "No photos". Victor clicks
the shutter, coughing to hide the sound, and then leaves.
