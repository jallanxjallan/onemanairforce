---
status: synopsis
title: Quikio Confesses
date: 4 December 1988
category: interview
---
Julia returns to Samuel Quiko, who admits that he was the go-between with rogue KNIL officers and the Republicans to buy arms. But he did not realize that the "Republicans" were actually communists who wanted the guns to fight the Soekarno government. It was Quiko who passed along the information the RI-002 would fly gold to Sumatra on 1 October.