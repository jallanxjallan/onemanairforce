---
category: past
date: 20 October 1947
status: draft
title: Grounded in Bangkok
synopsis: Freeberg flies two Indonesian aviators to Bangkok, where they will purchase and fly back an Avro Anson. Under pressure from the Dutch, the Thais detain Freeberg, but soon release him and allow RI-002 to depart. 
---

Bob flies two Indonesian aviators, Halim and Iswandi,
to Bangkok where they will purchase a twin-prop airplane that will
become RI-003. Dutch authorities pressure the Thai government to detain
Freeberg as a blockade runner. The Thais briefly detain Freeberg in a
comfortable hotel room, but the Indonesian crew must find their own
accommodation. They can only afford rooms in a bar district. Boedi is
delighted, but Halim and Iswandi are appalled. Both are engaged to be
married, and worry that the families of their fiancées will learn that
they have stayed in such a disreputable environment.
