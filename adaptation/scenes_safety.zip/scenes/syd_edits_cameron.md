---
category: present
date: 29 June 1988
status: synopsis
title: Syd Edits Cameron
synopsis: Syd Jardine, a retired foreign correpondent living in Jakarta, edits Cameron's interview. He remarks that Freeberg comes across as a "white savior", and suggests Cameron do his own research to flesh out his character and motives. 
---

Cameron submits his article to Syd Jardine, a retired foreign correpondent assisting the Jakarta Times, a start-up English-language newspaper, as a copy editor.  Syd remarks that Freeberg comes across as a "white savior" singlehandedly responsible for Indonesia gaining freedom from the Dutch. He notes that there were many foreign pilots helping the Indonesians, and suggests Cameron do his own research to add historical context.

Cameron writes up the interview at the Jakarta Times, an English-language daily newspaper run as a hobby by a business mogul who wants to promote foreign investment in Indonesia. The owner lets Cameron use a desk, telephone, and fax in exchange for favors like this article. Cameron gives the draft to Syd Jardine, an Old Asia Hand who is the offical language consultant, but unoffical managing editor. Syd remarks that Freeberg comes off
as some sort of "foreign savior" who alone was responsible for saving the Republic. He suggests Cameron flesh out the story with accounts of Bob in the reference section of the newly
opened National Library.
