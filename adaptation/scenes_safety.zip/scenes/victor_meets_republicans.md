---
category: past
date: 04 November 1947
status: synopsis
title: Victor Meets Republicans
---


Emeria takes Victor along (out of uniform) as she
sketches portraits of people crowded into the poorer sections of Batavia. Many have been driven from their villages by neighbors who support continued Dutch rule. 
