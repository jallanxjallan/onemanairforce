---
category: interview
date: 30 September 1988
title: Ani Reminisces
status: draft
synopsis: As Cameron and Muharto fall deeper into their conspiracy rabbit hole, Ani tells Julia of the hardships of life in besieged Jogja.
---

Cameron and Julia have dinner with Muharto and
Ani. Afterward, Cameron and Muharto fall deep into discussion about the
revelations of their investigations. Ani and Julia agree that their men
are plummeting down a conspiracy rabbit hole, but keep their
views to themselves. Instead Ani tells Julia stories about when her husband
was a dashing young officer, and of the hardships of life in besieged
Jogja.
