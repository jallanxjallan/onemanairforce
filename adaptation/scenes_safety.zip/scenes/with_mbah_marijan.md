---
status: omit
title: With Mbah Marijan
date: 2 August 1988 
category: present
synopsis: Cameron and Muharto visit a guru on Mount Merapi to seek spiritual support for the success of their investigation. 
---
Cameron accompanies Muharto to a village on the
upper slopes of the Merapi volcano to meet Muharto's spiritual advisor,
Mbah Maridjan. The three hike the steep incline to a shrine;
effortlessly in the case of the sexagenarian duo of Muharto and
Maridjan; with some difficulty by their companion, some four decades
their junior. Cameron watches respectfully as the two intone Islamic
prayers, then lay Hindu-style floral offerings at the shrine to the gods
of the mountain.