---
status: synopsis
title: Defending Hendra
date: 1 October 1947
location: Kuntzkrieg
category: past
---
Emeria gives a forceful defense of Hendra Gunawan and his heroic depictions of Indonesian freedom fighters at an exhibition in the Kuntzkrieg.

