---
category: research
date: 25 November 1988
location: Library
name: Arts Reporter
status: synopsis
---
Julia finds a decade-old magazine article profiling Jan Boon as a pioneering journalist who elected to take Indonesian citizenship. The magazine editor confirms that Jan Boon is still living in Jakarta, and gives Julia his contact info. 
