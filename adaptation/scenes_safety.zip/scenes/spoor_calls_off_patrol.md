---
category: past
date: 10 September 1948
status: synopsis
title: Spoor Calls Off Patrol
---


Spoor orders a night patrol not to engage a
blockade running POAS flight because he is informed that civilians are passengers.
