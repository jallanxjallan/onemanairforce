---
category: past
date: 01 April 1947
status: synopsis
title: Missing Dakota
synopsis: Bob returns to Manila to find the jointly owned Dakota is missing. he discovers the location, and moves it himself to another strip on the outskirts of Manila.
---

Bob returns to Manila to find the jointly owned Dakota
is missing. Suspecting an April Fools joke, Bob plays along, but becomes
concerned when the aircraft does not reappear. Bob does not confront
Walters, Instead, he discovers the location, and moves it himself to
another strip on the outskirts of Manila.
