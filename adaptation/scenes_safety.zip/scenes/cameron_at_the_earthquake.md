---
category: present
date: 15 July 1988
status: synopsis
title: Cameron at the Earthquake
synopsis: Syd takes Cameron to the Earthquake. Sanyoto, the owner and a close friend, was an Air Force drill sargeant during the revolution. Most patrons are senior military officers and government officials.  
---

After putting the paper to bed one evening, Syd invites
Cameron to join him for a few drinks at his favorite bar, the
Earthquake. He introduces Cameron to the owner. Sanyoto had been a drill
sergeant in the Air Force, then worked as a fixer for foreign oil
companies until he retired and opened the bar. Sanyoto maintains wide
contacts in the highest levels of government and the military, so the
Earthquake is popular with generals and cabinet ministers. Sanyoto tells
Cameron that, as a friend of Syd, he is always welcome here, as long as
he minds his manners and doesn't "needle" any of his regular guests.

