---
category: interview
date: 5 September 1988
title: Julia interviews Regina
status: draft
synopsis: Regina describes her experiences as a teenage servant in the Emeria salon. 
---

Regina tells Julia that she hails from a village in the ancestral region of Emeria's family. When she turned 16 she was sent to Batavia to work as a domestic helper for Emeria, who would sponsor her education. She remembers Emeria as being highly intelligent and charismatic, with many friends.  
