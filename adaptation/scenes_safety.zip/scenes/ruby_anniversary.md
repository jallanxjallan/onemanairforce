---
status: synopsis
title: Ruby Anniversary
date: 24 October 1988 
category: present
---
Julia and Cameron attend the 40th wedding anniversary of Ani and Petit Muharto. 