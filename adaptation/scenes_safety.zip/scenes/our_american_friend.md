---
category: past
date: 21 June 1948
status: synopsis
title: Our American Friend
---


During a speech on an airstrip, Soekarno stands on the
RI-002 wing and speaks to a small, enthralled crowd of local residents.
Toward the end of the speech, Soekarno points to Bob in the cockpit,
proclaiming: "This is Bob Freeberg, a brave, good man and a friend of
all Indonesians"
