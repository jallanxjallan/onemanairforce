---
category: past
date: 18 October 1947
status: synopsis
title: Thai Authorities Released Freeberg
---

Spoor is furious when he learns that Thai authorities have released
Freeberg.
