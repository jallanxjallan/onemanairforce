---
status: omit
title: Museum Trance
date: 2 August 1988 
category: present
synopsis: Muharto goes into trance when he handles a piece of RI-002 wreckage in the Aviation Museum. 
---
Muharto seeks out the curator, who invites them into his
office. Muharto asks the curator to retrieve scraps from the RI-002
wreckage stored at the museum. One of the items is the dynamo with the
bullet inexplicably lodged in the windings. Muharto picks it up, and
from his point of view, the room around him fades into mist.

Muharto is astounded to realize he is somehow in the radio nook of
RI-002 on the day of the crash. The airplane shutters as the engines
scream in protest. Muharto sees two shadowy figures in the pilot seats,
and a forested mountainside fills the window.

The museum office comes back into focus, and Muharto sees the concerned
faces of Cameron and the curator. Muharto places the dynamo back into
the storage box and says, in a wavering voice, that he will miss his
train back to Jakarta if he doesn't hurry.