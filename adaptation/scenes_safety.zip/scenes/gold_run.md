---
category: past
date: 30 September 1948
status: expand
title: Gold Run
---

Suryadarma reluctantly assigns Bob Freeberg the mission to
transport gold to Bukittinggi.
