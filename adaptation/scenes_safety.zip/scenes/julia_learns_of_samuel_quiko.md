---
category: present
date: 16 August 1988
status: draft
title: Julia Learns of Samuel Quiko
synopsis: Cameron tells Julia of meeting Samuel Quiko. Julia wants to interview him, but Cameron dismisses the suggestion as a waste of time. 
---

Cameron
mentions his meeting with Samuel Quiko to Julia. She remarks on distinctive
name, indicating a Portuguese heritage, and remembers seeing it in a
review of a musical performance in 1947. She disappears into the stacks,
reappearing with an armful of magazines containing articles about
keroncong. Julia sees that in several of the photos Samuel is with
Emeria. Julia suggests that they interview Samuel Quiko. Cameron demurs,
saying that a guy who plays "music for seniors" would be of little value
in investigating the fate of RI-002.
