---
category: past
date: 30 November 1947
status: draft
title: Ining Asks To Return
synopsis: Ining writes a letter to Major Primitivo begging to be recalled, but arrives at Maguwo seconds too late to give to Muharto. George Rueneker sees he is distraught, as askes Mas Ded to escort him back to Jalan Jetis. 
---


Ining writes a letter Major Primitivo asking to be
relieved of his assignment and returned home. He rushes to Maguwo, but
is seconds too late to give it to Muharto to take to Manila. George, on
duty as flight controller, is on the tarmac. He sees that Ining is
upset, so he asks Muharto's brother, Mas Ded, to take Ining back to
Jalan Jetis and stay with him until his calms down.
