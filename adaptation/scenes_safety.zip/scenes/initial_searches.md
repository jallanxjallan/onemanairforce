---
category: past
date: 5 July 1988
status: draft
title: Initial Searches
synopsis: Muharto tells Cameron of the disappearance of RI-002, and the discovery of the wreckage 30 years later. 
---


Muharto tells Cameron that on the afternoon of 1 October 1948 he heard
reports that RI-002 had not arrived at Bukittinggi. In the following
days, the Dutch denied any knowledge of the disappearance, and the
Republic was unable to mount more than a cursory search. Muharto shows
Cameron a clipping dated 1983 about rattan gatherers finding wreckage on
a remote mountain in South Sumatra. Muharto said that he used his AURI
credentials to research the archives for the investigation report. He
found, to his astonishment, that the wreckage had actually been
discovered in April 1977.
