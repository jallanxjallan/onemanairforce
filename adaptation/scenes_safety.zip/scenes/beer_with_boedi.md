---
status: draft
title: Beer With Boedi
date: 20 October 1988
category: interview 
synopsis: Cameron visits Boediardjo again to deliver the self portrait. 
---
Cameron meets Boediardjo again to give him the sketch from Affandi. Boedi laughs and says Affandi was must have been testing your character: you could have sold this for a thousand dollars. Boedi invites Cameron to stay for a beer, and asks about the progress of his investigations. Cameron replies that every new discovery raises a host of questions. Boedi says that he is not surprised, as Muharto is not telling you everything. 

