---
category: past
date: 29 December 1947
status: synopsis
title: Grounded In Changi
synopsis: RI-002 flies Ining to Manila, but is forced by bad weather to land in Singapore. Dutch representatives on the island pressure the British into grounding the Dakota.
---

RI-002 departs for Pekanbaru carrying 14 Republican
officials and a coffin containing Ining's remains. Bad weather over
Pekanbaru forces RI-002 to divert to Singapore. Dutch representatives on
the island pressure the British into grounding the Dakota because of
"airworthiness" issues.
