---
category: past
date: 18 December 1947
status: synopsis
title: Primitivo Accuses Muharto
---


Muharto reports Ining's death to Primitivo. Muharto
is astounded when the major accuses Muharto and his late brother of
being clandestine communists, and detains Muharto for interrogation.
