---
category: past
date: 07 May 1948
status: synopsis
title: Bambang Takes His Seat
synopsis: Bambang finally gets his permanent assignment as RI-002 co-pilot when Muharto is promoted and reassigned to headquarters.
---

Bambang finally gets his permanent assignment as
RI-002 co-pilot when Muharto is promoted and reassigned to headquarters.
He starts his first mission by suggesting a route, as Muharto would do
as mission leader. But Bob rebukes him, saying his only job is to watch
and learn.
