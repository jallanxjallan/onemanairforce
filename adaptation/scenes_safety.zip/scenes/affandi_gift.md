---
status: omit
title: Affandi's Gift
date: 1 August 1988 
category: interview
---
Affandi grabs
a sketch pad, dashes off a self-portrait, signs it, and hands it
Cameron, explaining that it is a gift for Boedi to thank him for
sending him a new friend.

