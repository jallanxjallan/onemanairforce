---
category: past
date: 27 December 1948
status: synopsis
title: Victor In Jogja
---


Spoor sends Victor to Jogja with the invading
troops to prove photograph what he expects to be a warm welcome as
liberators. The reception is anything but that. Victor is part of the
squadron that accosts Muharto and Ani in the market, and witnesses Ani
berating the squad commander.
