---
category: past
date: 15 April 1948
status: synopsis
title: Bambang Cannot Conceal Envy
---


Moeljono pilots the newly purchased twin-engine
RI-005 Avro-anson from Bukittinggi to Jogjakarta. Bambang is beside
himself with envy, and redoubles his efforts to claim the co-pilot seat
of RI-002.
