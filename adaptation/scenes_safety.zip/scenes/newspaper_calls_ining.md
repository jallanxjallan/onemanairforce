---
category: past
date: 15 January 1948
title: Newspaper Calls Ining
status: synopsis
---


Spoor reads an article in a Manila newspaper
speculating that Ining's death resulted from an arms deal gone
disastrously wrong. He decides to make stopping the blockade runners a
priority.
