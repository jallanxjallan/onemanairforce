---
category: past
date: 15 July 1948
status: draft
title: Ani Serves Rice
synopsis: Ani helps to run a communal kitchen to feed the thousands of refugees pouring into Jogjakarta. 
---

Ani helps to acquire rice for a communal kitchen to
feed the thousands of refugees pouring into Jogjakarta. She is
overwhelmed, never having set foot in a kitchen in her life, but soon
sees how the process could be more efficient and orders the cooks to form
an assembly line.
