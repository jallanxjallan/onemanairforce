---
category: present
date: 15 December 1988
status: synopsis
title: Julia Finds RI-002 Photo
---

Julia finds a photo in a misfiled volume of  BN.
The image shows a Dakota with "002" painted on the nose guarded by a
KNIL soldier. 
