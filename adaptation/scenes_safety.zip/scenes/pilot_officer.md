---
category: past
date: 10 June 1947
status: synopsis
title: Pilot Officer
---


At Manila airport  Bob is told to identify his co-pilot, a
requirement for twin-engine aircraft on long-haul flights. Muharto
gambles the Filipino officers cannot read Indonesian and so falsely translates the rank on his Air Force identification as "Pilot Officer".
