---
status: omit
title: Captured Spy
date: 15 October 1988 
category: interview
---
Cameron notices a realistic portrait of a young man crouched against a wall in a posture of defeat. Affandi explains he had been a teenager accused of spying for the Dutch and summarily executed moments after he had finished the sketch for the painting. 

