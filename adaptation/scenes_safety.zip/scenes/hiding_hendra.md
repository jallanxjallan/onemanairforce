---
status: synopsis
title: Hiding Hendra
date: 10 October 1947 
location: Emeria Salon
category: past
---
Emeria dismisses a squad of native KNIL soldiers looking for Hendra, who is hiding in her bedroom. 