---
status: omit
title: Propaganda Paintings
date: 4 August 1947 
category: past
synopsis: Affandi and Hendra crouch in the foliage a hundred meters from Dutch outpost. When Affandi stands to get a better view, the soliders spot him, and laugh. 
---
After repeated attempts, Hendra finally convinces Affandi to join them to make propaganda paintings. They travel to the demarcation line south of Semarang. They crouch in the vegetation a hundred meters from a Dutch outputs. At first, Affandi cowers, unwilling to raise his head enough to see the output. Then, he leaps up, saying "If I die, I die!" and sketches furiously. The soldiers spot him, turn their binoculars for a closer look, then burst into laughter. 

When the Dutch invade, Pelukis Rakyat members bury the propaganda paintings in the forest. They return six months later only to discover that in the meantime
villagers had dug them up to make clothing, tired of being dressed in old rice sacks since the Japanese occupation.