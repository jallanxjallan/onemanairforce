---
title: Artistic Inspiration
date: 5 September 1988
status: draft
category: interview
synopsis: "Regina tells Julia that Emeria inspired her to practice art. A frequent guest, a youthful Dutch man, tutored her on sketching. Regina does not remember his name, but suspects he may have been a soldier, since he would always leave early in the evening, even when food and drink was flowing freely."
---
Regina brings steaming plates of food to a table where Emeria sits with guests. One guest, a young Dutchman, rises and says he has to leave. The others protest, saying it is only 9 pm, but the youth is adamant and takes his leave. Auke Sonnega laughs and says: "Has to be back in the barracks by curfew. If I were him I would defect!"