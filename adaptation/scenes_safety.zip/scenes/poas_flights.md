---
category: past
date: 04 March 1948
status: synopsis
title: POAS Flights
---


Muhammad Hatta invites John Coast to to begin regular
services to Jogja. Coast and investors in Bangkok form Pacific Overseas
Air Charter, or POAS, and hire American Dave Fowler as head pilot.
