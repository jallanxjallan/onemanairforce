---
status: synopsis
title: De Facto Liaison
date: 15 August 1947
category: past
---
Salipada Penatun arranges for Muharto to meet Major Primitivo of Philippine Army Intelligence to form an unofficial liaison with the Republican military. Primitivo introduces Muharto to Captain Ignatius Espina. a guerrilla fighter during the Japanese occupation. Primitivo offers to send Espina to the Republic as a clandestine military advisor to train youth militias. 

