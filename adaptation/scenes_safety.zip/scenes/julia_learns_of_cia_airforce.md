---
category: present
date: 21 November 1988
status: synopsis
title: Julia Learns of CIA Airforce
---


Julia finds Muharto's name mentioned in article
about Permesta, the failed military rebellion against the Soekarno government. "Colonel" Muharto had commanded the Revolutionary Air
Force, a squadron of fighters and bombers provided by the CIA, and had
participated in at least one bombing raid himself. One of the CIA
pilots, Allen Pope, had been shot down and captured, embarrassing the
US. The Revolutionary Air Force was disbanded soon afterward, and
Muharto and his family had fled to exile in Malaya.
