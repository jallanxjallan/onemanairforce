---
category: interview
date: 28 June 1988
status: draft
name: Muharto Introduces Freeberg
synopsis: 'American freelance journalist Cameron Bishop interviews retired Air Force Major Petit Muharto about his experiences with Bob Freeberg as co-pilot of RI-002.'
---
Petit Muharto, a lively, dapper Indonesian in his late 60s, is sitting
with his wife Ani in their cosy living room in the Jakarta suburbs when
they hear the roar of a large motorcycle. Muharto, in jest,
covers his ears, and is then surprised when the motorcycle stops in
front of their house. A moment later, there is a knock on the door. His wife Ani
opens it to find Cameron Bishop, an engaging, disheveled young American freelance journalist, who says has an appointment to interview Muharto about his experiences with Bob Freeberg. Muharto recovers from his astonishment that a "Hell's Angel" has come to interview him, and begins by telling Cameron of a message he received one morning at his desk in Maguwo air base in Jogjakarta.
