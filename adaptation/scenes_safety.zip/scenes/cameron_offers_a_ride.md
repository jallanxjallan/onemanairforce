---
name: Cameron offers a ride
date: 7 July 1988
location: IPPHOS
category: scene
status: draft
synopsis: "Julia tells Cameron that she is meeting friends, all daughters of generals or high officials, for coffee at the Mandarin Hotel. That hotel is also the watering hole for the foreign press, so Cameron offers to give her a lift and then meet his colleagues for a beer. "
---

Julia tells Cameron that she is meeting friends, all daughters of generals or high officials, for coffee at the Mandarin Hotel. That hotel is also the watering hole for the foreign press, so Cameron offers to give her a lift and then meet his colleagues for a beer. 

 
