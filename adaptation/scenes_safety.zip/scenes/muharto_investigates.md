---
category: past
date: 04 January 1980
status: draft
title: Muharto Investigates
synopsis: Muharto writes to his contacts in the Air Force and to the officers who participated in the crash-site investigation, but receives vague, non-committal replies -- or only silence. 
---

Muharto writes to his contacts in the Air Force and to the
officers who participated in the crash-site investigation, but receives
vague, non-committal replies --- or only silence. He then tries his luck
in Air Force archives and government libraries, but finds only disorder
or even active obstruction as civil-service librarians question his
qualifications and motives. The only solid result of his efforts is the
report on the investigation of the crash site. One intriguing document
is a photograph of a radio-set dynamo with a bullet lodged in the
windings.
