---
category: present
date: 17 December 1988
status: synopsis
title: Syd Dies
---


Cameron returns from Karangendah on the morning
flight and goes directly to Syd's room to tell him the news. He finds
his friend dead in his favorite reading chair, a book on his lap and a
glass of whiskey at his side.
