---
category: present
date: 16 December 1988
location: Airport
name: Julia Choice
status: new

---
Julia turns down Cameron's offer and announces her decision to take her masters at UI.  