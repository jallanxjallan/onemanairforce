---
category: past
date: 04 October 1945
status: synopsis
title: Bersiap
---


Youth gangs armed with deadly bamboo spears roam the
streets, threatening Europeans and any Indonesians deemed to be allied
with the Dutch. Samuel leads his neighbors in setting up nightly patrols
of Kampung Tugu and barricading entrances to the village.
