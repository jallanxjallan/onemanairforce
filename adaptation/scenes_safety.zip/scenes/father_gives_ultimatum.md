---
category: past
date: 15 May 1948
status: synopsis
title: Father Gives Ultimatum
---

Muharto visits the father of Ani to ask for her hand. The father says he will give his blessing only if he accepts the promotion and takes a desk assignment. 

