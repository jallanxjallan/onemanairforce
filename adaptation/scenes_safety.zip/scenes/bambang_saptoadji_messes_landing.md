---
category: past
date: 04 February 1947
status: synopsis
title: Bambang Saptoadji Messes Landing
---

Bambang Saptoadji messes up a landing during an air
show, severely damaging one of the Republic's few serviceable aircraft.
