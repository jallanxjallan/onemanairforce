---
category: past
date: 07 December 1948
status: synopsis
title: Spoor Warns Victor
---


Spoor warns Victor about fraternizing with
Emeria and the Republican artists. Spoor threatens to reassign Victor to
a combat unit.
