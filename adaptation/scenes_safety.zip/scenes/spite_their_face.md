---
category: past
date: 21 September 1948
status: synopsis
title: Spite Their Face
---

Over whiskey with Muhartoat Hotel Merdeka Freeberg and Fowler complain about Suryadarma cutting off his fuel allowance because they act like commercial aviation pilots, not serving Air Force officers. 
