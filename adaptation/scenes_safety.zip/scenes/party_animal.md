---
category: past
date: 15 September 1947
status: synopsis
title: Party Animal
---


At a party to celebrate the sale of the quinine,
Ining shows himself to be a party animal, buying rounds for his
companions and flirting with the foreign women. Freeberg and Boedi hustle him
out of bar after he hits on American colonels teenage daughter.
