---
category: past
date: 15 November 1947
status: draft
title: Into The Typhoon
synopsis: Freeberg flies into a severe storm to evade detection by a Dutch fighter. He reassures a terrified Muharto by saying when a Navy test pilot he would fly into typhoons.  
---


In the co-pilot seat, Muharto spots an small airplane near the horizon
as they fly near Dutch territory. This is most likely a Dutch fighter on
patrol, so Bob steers RI-002 into a tropical storm. Boedi grins when he
sees Muharto's terrified face as the Dakota is violently buffeted, with
sickening plunges in altitude. Bob tells Muharto to not worry; when a
Navy test pilot he would fly through typhoons.
