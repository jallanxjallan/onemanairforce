---
category: past
date: 15 February 1948
status: omit
title: Muharto Shops in Manila
---

Muharto shops for clothes for his fellow
officers.
