---
category: interview
date: 22 July 1988
status: synopsis
title: Painful Memories
---


Cameron tells Muharto of his interview with George
Rueneker, and cajoles him into telling of the events following the
death of Ining. 
