---
category: past
date: 04 February 1948
status: synopsis
title: Deportation Offer

---


Salipada Penatun offers to have Bob Walters deported. On the advice of Tom Lee, Bob declines the offer.
