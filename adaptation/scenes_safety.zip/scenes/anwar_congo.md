---
category: interview
date: 04 December 1988
status: synopsis
title: Anwar Congo
---

Anwar reveals that KNIL officers had paid him to
smuggle a substantial quantity of gold to Singapore. Anwar also
introduces Cameron to several men who had been employed at Karangendah
in menial civilian jobs. They attest that they had seen the crew in
captivity. However, no one remembers seeing Freeberg. Anwar Congo
reveals that gold was used to purchase guns smuggled from Malaya, which
then taken overland to Lampung by Sumatra preman.
