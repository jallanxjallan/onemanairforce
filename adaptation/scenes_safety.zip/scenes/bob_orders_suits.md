---
status: omit
title: Bob Orders Suits
date: 1 February 1947
category: past 
---
Freeberg realizes that as a businessmen Bob must dress in more than flight gear. With post-war shortages driving up the cost of textiles in Southeast Asia, he decides to order Palm Beach suits from the US.
