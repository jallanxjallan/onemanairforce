---
category: interview
date: 18 August 1988
title: Samuel Proves Patriotism
status: synopsis
---

Samuel tells Julia that during the Bersiap period he sought the
protection of the local preman. To prove his loyalty to the Republic, he
offered to use his unique position of being able to access both colonial
and Republican worlds to act as a courier or even a spy. 
