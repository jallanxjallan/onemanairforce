---
category: past
date: 04 March 1947
status: synopsis
title: Southeastern Airlines
---


Bob partners with Singapore-based businessman Hugh Savage to start Southeastern Airlines.
