---
category: past
date: 04 March 1947
status: synopsis
title: Two Bobs buy a Dakota
---


Bob Freeberg joins with Bob Walters to purchase a
war-surplus Dakota. They agree to equal ownership of the craft, and will
equally contribute to making it airworthy.
