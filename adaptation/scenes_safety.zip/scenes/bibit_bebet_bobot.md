---
category: present
date: 12 October 1988
status: synopsis
title: Bibit Bebet Bobot
synopsis: Eddy tells Julia that she must be careful in her choice of a future husband. 
---


Eddy has a heart-to-heart talk with
Julia, letting her know that he opposes Julia marrying a foreigner. Eddy
has checked into Cameron's background, and found he is penniless and
with a spotty academic record, though he excelled in journalism and
seems to be a good writer. Julia retorts that her relationship with
Cameron is purely professional. If the story they are researching
results in a book, her expert facilitation will look good on a future
application for graduate school.
