---
category: past
date: 04 July 1947
status: draft
title: Crushing Disappointment
synopsis: Bambang is crushed when his fighter is grounded minutes before he was to take off for the raid on Ambarrawa. 
---


Bambang prepares to fly as wing man to the squadron
tasked with bombing Dutch facilities on the north coast of Java. Bambang
is crushed when the final pre-flight check reveals that the machine gun
on his fighter is jammed and must be disassembled. Bambang can only
watch as the squadron flies off on their historic mission.
