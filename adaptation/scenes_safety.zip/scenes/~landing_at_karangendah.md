---
status: synopsis
category: past
title: Landing At Karangendah
date: 31 March 1947
synopsis: Freeberg tests the usability of a Japanese airstrip by simply landing on it. 
---
On the return leg to Singapore, Muharto asks Bob if he
can attempt a landing on a refurbished Japanese airstrip at Karangendah.
Bob readily agrees. They circle the strip and Bob ponders the attempt.
Muharto asks if he can land a plane this size. Bob replies that he did
this all the time in the war. He can "land on a dime and give you a
nickel change." 

Bob makes a spectacular landing, engines roaring with reverse thrust. Muharto asks if he can take off again. Bob replies:
"I hope so. We seem to be smack dab in the middle of nowhere." 

Santoso, the base commander climbs aboard to meet them. After a short conversation, Santoso exits, and Bob takes off, the wheels finally lifting off the runway a few meters before the tree line.

