---
category: past
date: 21 October 1947
status: draft
title: Military Babysitter
synopsis: George Rueneker visits Ining to check up on him when Muharto is away. He is disturbed to see the anger in their faces as Ining yells at the recruits. 
---

Muharto sees that Ining is isolated living among
the youth militia in the forest. He asks George Rueneker to keep Ining company in
his absence. George witnesses Ining berate the young recruits and sees
the displeasure on their faces. Ining asks George to bring whiskey
whenever his visits.
