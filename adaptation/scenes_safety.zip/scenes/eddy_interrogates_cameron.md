---
category: present
date: 20 July 1988
status: draft
title: Eddy Interrogates Cameron
synopsis: Sanyoto introduces Cameron to Colonel Eddy without disclosing his relationship to Julia. After a few minutes of conversation, Cameron begins to feel he is being skillfully interrogated.  
---

Cameron is conversing with Sanyoto at the bar when a middle-aged Indonesian, clearly a military man though out of uniform, takes the empty stool beside him. Sanyoto introduces him as "Pak Eddy"
and leaves them to chat. Eddy is affable, and asks Cameron
general questions about how he likes Indonesia and other inoccuous questions Indonesians ask of foreigners. But the conversation soon shifts to pointed inquiries about Cameron's
education and life goals. After Eddy leaves, Cameron remarks to Sanyoto
that he feels like he has just been interrogated. 
