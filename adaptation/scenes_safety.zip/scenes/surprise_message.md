---
category: scene
date: 08 June 1947
status: draft
name: Surprise Message
synopsis: 'Muharto is astounded to receive a message that a foreign pilot has landed on a remote beach and asked for him by name.' 
---

Muharto is surprised when  given a message from Army Lieutenant Pang Soeparto, stationed in Tasikmalaya, informing him that a foreign pilot
had landed an unmarked cargo aircraft on a nearby beach and,
astoundingly, had asked for Muharto by name. Muharto takes this
information to his commander, Suryadarma, who tells him to fly to Tasikmalaya
and find out which of Muharto's "foreign flyboy friends" it might be. 
