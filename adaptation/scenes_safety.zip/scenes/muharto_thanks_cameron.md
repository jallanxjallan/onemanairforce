---
category: present
date: 5 July 1988
status: draft
title: Muharto Thanks Cameron
synopsis: Muharto visits Cameron at the Jakarta Times to thank him for the article.
---


Muharto 
visits The Jakarta Times to personally thank Cameron and Syd and pick up any extra copies of the edition. He says
he he has been bombarded with calls from old Air Force comrades, asking
about what happened to the gold. Muharto goes on to say that he had
tried to solve the mystery himself, but had gotten nowhere.
