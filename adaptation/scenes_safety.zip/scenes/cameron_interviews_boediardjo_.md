---
category: interview
date: 10 July 1988
title: Cameron Interviews Airmen
status: synopsis
---


Muharto organizes a meeting of former RI-002 crew, who tell stories of flying with Freeberg in October to December 1947. 
