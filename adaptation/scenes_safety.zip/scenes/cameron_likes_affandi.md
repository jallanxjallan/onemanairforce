---
status: omit
title: Cameron Likes Affandi
date: 15 October 1988
category: interview
synopsis: Cameron admires the Affandi paintings Boediardjo owns. Boediardjo is pleased, and suggests Cameron visit the artist whenever he travels to Jogja.
---
As they are about to leave, Cameron admires the Affandi paintings covering the wall of the salon. Boedi explains that Indonesia's greatest painter is an old friend. Cameron mentions that he and Muharto will go to Jogja the following week. Boedi suggests he interview Affandi for his newspaper, and to give him his warmest regards. 
