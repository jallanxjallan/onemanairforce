---
status: draft
title: Republican Lifeline
date: 28       June 1988
category: interview
synopsis: Muharto tells Cameron of the critical missions Freeberg undertook in late 1947.
---
Muharto tells Cameron that they finally sold the quinine and returned to Java in late September. For the next year, he flew with Bob Freeberg on missions that provided an essential lifeline for the Republic. Though he and Bob were basically aerial truck drivers, bringing badly needed spare parts and medicines to Jogja, the ever-present danger of encountering a Dutch patrol made for some exciting moments. 