#!/home/jeremy/Python3.7Env/bin/python
# -*- coding: utf-8 -*-
#
#  script.py
#
#  Copyright 2019 Jeremy Allan <jeremy@jeremyallan.com>

from operator import itemgetter
from pathlib import Path
from document.document import Document
from storage.cherrytree import CherryTree
from scripts.proofreader import Proofer
from document.pandoc import PandocArgs
from IPython.display import Markdown as md
from dateutil.parser import parse as date_parse
import pandas as pd
import fire
import re

def load_story_data(ct):
    return [dict(
            identifier=n.id,
            story=n.ancestors[1].name,
            scene=n.name,
            notes=n.texts,
            content=n.content,
            document_link = next(n.links(label='Story|Document'), None))


def load_sequence(sequence_no, sequence, scene_no, scene):
    return dict(sequence=sequence.name,
                    sequence_no=sequence_no,
                    identifier=scene.id,
                    story_no=lno,
                    content=s.texts,
                    links=s.links(type='node'))


def load_link_data(sequence_node):
    return sorted (dict(
        identifier=sequence_node.id,
        link_no=lno,

    ))



def load_document_data(document_link):
    if not Path(str(document_link)).exists():
        print(f'document_link for {node.name} not valid')
        return False
    document = Document.read_file(str(document_link))
    data = dict(
        document_link=str(document_link),
        text=document.content.lstrip('\n')
    )
    for key in ('title', 'category', 'status'):
        data[key] = document.metadata.get(key, None)

    try:
        date = date_parse(document.date)
    except:
        date = None
    finally:
        data['date'] = date
    return data


CATEGORIES = ('Present', 'Past')

class DataFrame(Synopsis):
    def __init__(self, input_arg):
        if isinstance(input_arg, DataFrame):
            self.df = input_arg.df
        elif isinstance(input_arg, Screenplay):
            self.df = self._build_df(input_arg)
        else:
            raise AttributeError(input_arg, 'not recognized')

    def _build_df(self, input_arg):
        dfs=pd.DataFrame(input_arg.story_data)
        dfd=pd.DataFrame(filter(None, [doc_data(s['document_link']) for s in input_arg.story_data]))
        dfl=pd.DataFrame(input_arg.sequence_data)

        return dfs.merge(dfd, how='left', on='document_link').merge(dfl, how='left', on='identifier')

    def filter_stories(self, **kwargs):
        """returns subset filtered by sequence, level, category, story, scene regex patterns"""
        clauses = dict(
            sequence='(sequence.notnull()) & (sequence.str.contains("{}"))',
            level='level == {}',
            category='(category.notnull()) & (category.str.contains("{}"))',
            story='story.str.contains("{}")',
            scene='scene.str.contains("{}")',
            text='(text.notnull()) & (text.str.contains("{}"))'
        )
        query = ' & '.join(
            [f'({clauses[k].format(v)})' for k, v in kwargs.items()])
        return DataFrame(self.df.dropna(subset=kwargs).query(query))

    def unmade_stories(self):
        return DataFrame(self.df[self.df.document_link.isna()])

    def unplaced_stories(self):
        return DataFrame(self.df[self.df.sequence.isna()])

    def date_range(self, *bounds):
        min_date = date_parse(bounds.pop[0])
        max_date = date_parse(bounds[0]) if len(
            bounds) > 0 else date_parser('1 January 1990')
        query = 'min_date <= date <= max_date'
        return DataFrame(self.df.dropna(subset=['date']).query(query).groupby('sequence', sort=False).agg({'date': [min, max]}))

    @property
    def display_scenes(self):
        return self.df.sort_values(['sequence_no', 'story_no'])[['story', 'scene', 'date', 'sequence']]

    @property
    def display_text(self):
        for r in self.df.dropna(subset=['text']).sort_values(['sequence_no', 'story_no']).itertuples():
            try:
                display(
                    md(f'**{r.scene} - {r.date.strftime("%B %Y")}** :  {r.text.lstrip()}'))
            except Exception as e:
                print(f'Cannot display {r.scene} because {e}')

class Screenplay():
    def __init__(self):
        self.ct = CherryTree('screenplay.ctd')
        self.stories = [load_story(n)
                           for c in CATEGORIES
                           for n in ct.nodes(c)
                           if n.level > 2
                           if not n.name.startswith("~")]

        self.scenes = [load_scene(sno, s, l.no, l)
                                for sno, s in enumerate(ct.nodes('Synopsis'))
                                for lno, l in s.links(type='node')]


    def proof_content(self, output_file):
        pf = Proofer(output_file)

    def output_synopsis(self, outputfile):
        print(PandocArgs(input=[i['content'] for i in self.sequence_data], output=outputfile))

if __name__ == '__main__':
    fire.Fire(Screenplay)

'''
def output_treatment(self, output_file):
    rkey = RedisKey(namespace='omaf', component='slugline.data')

       try:
            previous_sibling_key = str(
                rkey(story_node.previous_sibling.id))
        except AttributeError:
            previous_sibling_key = str(rkey(0))

        data = dict(
            previous_sibling_key=previous_sibling_key,
            parent_key=str(rkey(story_node.parent.id)),
            level=story_node.level,
            name=story_node.name,
            id=story_node.id
        )
        story_key = str(rkey(story_node.id))
        [rds.hset(story_key, k,v) for k,v in data.items()]
        rds.expire(story_key, 120)
        print(PandocArgs(input=next(story_node.links(type='file')).href,
                         metadata=dict(slugline_data_key=story_key),
                         filters=['insert_slugline.lua', 'print_output_file.lua']))
        if i > 2:
            pass
'''
