---
category: past
date: 15 February 1948
status: expand
title: Muharto Shops in Manila

---


In mid February 1948 Muharto and Boedi shop for clothes for their fellow
officers.
