---
category: past
date: 04 July 1947
status: expand
title: Crushing Disappointment

---


Bambang prepares to fly as wing man to the squadron
tasked with bombing Dutch facilities on the north coast of Java. Bambang
is crushed when the final pre-flight check reveals that the machine gun
on his fighter is jammed and must be disassembled. Bambang can only
watch as the squadron flies off on their historic mission.
