---
category: past
date: 15 August 1947
status: rough
title: De Facto Liaison

---


Salipada Penatun arranges for Muharto and Pang to meet Major
Primitivo of the intelligence service. In the meeting, Primitivo says
that his government, to show solidarity with the embattled Republic,
wants to send a seasoned guerrilla fighter to train the youth militias,
but only under conditions of absolute secrecy. Primitivo then summons
and introduces Captain Ignacio Espina.
