---
category: past
date: 21 October 1947
status: expand
title: Ining Is Training Guerrillas

---


In late October 1947, Spoor learns that Espina is training guerrillas in
Jogja. He is concerned about foreigners are training local fighters as
this is a typical communist tactic.
