---
category: past
date: 10 June 1947
status: draft
title: Pilot Officer

---


At Manila airport  Bob is told to identify his co-pilot, a
requirement for twin-engine aircraft on long-haul flights. Muharto
gambles the Filipino officers cannot read Indonesia, and shows them his
Air Force identification and falsely claims the rank of "Pilot".
