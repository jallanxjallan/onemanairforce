---
category: past
date: 24 December 1947
status: rough
title: Back to Jogja

---


RI-002 returns to Jogja. Suryadarma tells Bob to lay
low while they deal with the fallout from Ining's death. Bob spends an
idyllic few days in Kaliurang, a resort on the slopes of Mount Merapi.
