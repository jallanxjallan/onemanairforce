---
category: past
date: 07 April 1948
status: draft
title: Father Interrogates

---


Ani's father questions Muharto about his career
path. He notes that as nominal co-pilot of RI-002 he is no more than an
airborne truck driver taking unnecessary risks. If he wants to marry his
daughter, he will need to put himself on a fast promotion track by
assuming managerial duties.
