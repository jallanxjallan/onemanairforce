---
category: present
date: 15 October 1988
status: draft
title: Julia Researches Emeria

---


Julia's curiosity about Emeria grows in the days after meeting Victor. She researches
Emeria in the art publications from the period. learing that she had been was the
first female Indonesian painter of modern art. Emeria was born into an aristocratic family and educated in Dutch schools for the native elite. This background gave her extensive connections at the highest levels of both Dutch and Indonesian society. However, she is intrigued to discover that there is not mention of her in any publication after 1950.
