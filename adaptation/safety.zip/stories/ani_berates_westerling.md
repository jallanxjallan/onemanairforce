---
category: past
date: 27 December 1948
status: draft
title: Ani Berates Westerling

---


A Dutch patrol stops Muharto and Ani as they return
home. The soldiers point to Muharto's khaki shorts and accuse him of
being in the military. Ani summons all the imperious passion of a
high-born Javanese women to give the commanding officer a vicious tongue
lashing, diverting attention while Muharto swallows his Air Force
identification.
