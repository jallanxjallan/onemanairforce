---
category: present
date: 07 October 1988
status: draft
title: Coffee With Julia

---


Cameron invites Julia to join him for coffee in the Hotel Hilton
before starting his shift at the Jakarta Post. Over coffee, Julia tells
Cameron of her dream of securing a scholarship to pursue post-graduate
studies in America. Cameron attempts, in turn, to tell of his dreams of
becoming an international investigative journalist, to be free to write
follow his own leads and write bestselling books. But Julia stops him,
saying, with a mischievous smile, that if she wants to know anything
about him she will simply ask her father, who is a senior officer in
military intelligence. Cameron puts down his coffee, looks around
involuntarily, then tells Julia it is time for him to go.
