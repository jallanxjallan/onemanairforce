---
category: past
date: 04 December 1947
status: expand
title: Ining Is Dood

---


During a routine radio contact with Jogja, Boedi is
told that Ining and Mas Ded were found dead of gunshot wounds at Ining's
house.
