---
category: past
date: 24 October 1948
status: rough
title: Muharto Marries Ani

---


Ani and Muharto marry. The day is marked by equal
measures of joy and sadness, as the absence of Bob Freeberg weighs heavy
on Muharto's heart.
