---
category: past
date: 07 October 1947
status: draft
title: Bob Meets Soekarno

---


Muharto takes Bob for an afternoon walk to show
him the town. Bob is impressed at the resilience of the people as they
struggle with the privation caused by the Dutch blockade. They visit the
palace of the former Dutch governor, now repurposed as the seat of the
Indonesian Republic. As Bob admires the architecture, he is astounded to
suddenly be ushered into the office of President Soekarno. As is his
custom in private conversation, Soekarno treats Bob as an equal and puts
him at ease, imploring the American to help his people in their struggle
for freedom.
