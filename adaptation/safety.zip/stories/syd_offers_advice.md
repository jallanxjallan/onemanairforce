---
category: interview
date: 02 October 1988
status: rough
title: Syd Offers Advice

---


Syd Jardine says that since unloading a quarter ton of gold would
require considerable resources, discovering who might have had the
motivation and ability to transport and sell the gold could solve the
mystery of RI-002. Muharto agrees, and Cameron eagerly offers to help.
He tells Muharto that he knows just the person who could help them do
the research.
