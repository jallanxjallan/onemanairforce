---
category: past
date: 28 September 1948
status: expand
title: RI-002 Drops Leaflets

---


RI-002 drops leaflets over Madiun. Santoso is
valuable in pointing out neighborhoods where residents may be receptive
to message from government to stay loyal to the Republic.
