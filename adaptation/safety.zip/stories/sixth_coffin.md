---
category: past
date: 29 July 1977
status: draft
title: Sixth Coffin

---


Five coffins draped in Indonesian flags lie on a
platform in an otherwise empty hanger. A sixth coffin, larger than the
rest and without a flag, rests on a separate platform. A flatbed truck
pulls into the hanger and a squad of airmen, in silence, pick up each of
the flag-draped coffins and place them on the truck. But they leave the
sixth coffin where it lies as the truck pulls away.
