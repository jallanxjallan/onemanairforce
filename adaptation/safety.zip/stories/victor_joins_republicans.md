---
category: past
date: 28 December 1948
status: draft
title: Victor Joins Republicans

---


Jogjakarta is declared  secure, and Victor
can walk around Jogja alone to document the condition of the town. A man
he recognizes as a friend of Emeria approaches him in a quiet alley to
say that if he wants to defect, Emeria is with Sudirman's forces in the
hinterland. Victor says he will bring his camera so the world can
witness the strength and courage of the Indonesians. The man nods in
agreement, then admonishes Victor to not forget his gun and as much
ammunition as he can carry.
