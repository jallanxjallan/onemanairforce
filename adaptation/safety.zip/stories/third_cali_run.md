---
category: past
date: 31 March 1947
status: draft
title: Third Cali Run

---


Muharto leads a blockade run with Bob Freeberg, then a
contract pilot for a Manila-based charter airline, as captain. Amid poor
visibility over Java, Bob demonstrates his piloting skill by diving
through a break in the clouds, leveling off under the cloud cover a few
hundred meters above the ground. Muharto spots a railway line, and tells
Bob that it leads along the valley to terminate in Jogja. Bob follows
the line, barely visible through the rain, and jokingly asks Muharto if
there are any tunnels between here the Jogja. The look on Muharto's face
suggests that he is not entirely sure.
