---
category: past
date: 05 October 1948
status: draft
title: Spoor has no clue

---


A reporter from the Bataviaasch Nieuwsblad newspaper
accosts General Spoor in the hallway and badgers him for information of
the fate of RI-002. Spoor claims ignorance, and grows visibly annoyed
when the reporter press him, breaking off the interview and slamming the
door to his office.
