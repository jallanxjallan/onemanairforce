---
category: past
date: 04 September 1947
status: draft
title: Krokodil Kourier

---


Samuel and his band play at an art exhibition at the
Kuntskring. In between sets, Samuel chats with a Dutch attendee, who
surreptitiously hands him a small package.

After the show, they are stopped by a Dutch patrol. Samuel tells them
they are musicians returning from a society gathering, and as proof the
take out their guitars and break into a Dutch-language Stamboel song.
The soldiers grin and let him pass.

They continue walking to the house in a "native" neighborhood where they
will spend the night. There, Samuel gives the package to a Republican
official.
