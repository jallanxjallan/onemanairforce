---
category: past
date: 08 June 1947
status: draft
title: Surprise Message

---


Muharto is surprised to be given a message from an army
lieutenant stationed in Tasikmalaya informing him that a foreign pilot
had landed an unmarked cargo aircraft on a nearby beach and,
astoundingly, had asked for Muharto by name. Muharto takes this
information to his commander, Suryadarma, who tells him to fly to Tasik
and find out which of Muharto's "foreign flyboy friends" it is.
