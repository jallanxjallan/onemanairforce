---
category: past
date: 10 June 1947
status: draft
title: Setting The Flaps

---


As they approach Manila, Bob invites Muharto to sit in
co-pilot seat and assist him with the flap controls. Muharto is nervous,
and pushes the flaps to full, causing the aircraft to make a sickening
lurch. Bob calmly reaches over, sets the flaps correctly, and gives
Muharto a friendly wink to show he is not angry at the mistake.
