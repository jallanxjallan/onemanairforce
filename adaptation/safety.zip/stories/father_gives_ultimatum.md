---
category: past
date: 15 May 1948
status: rough
title: Father Gives Ultimatum

---


Muharto tells Ani that he has been offered a promotion,
but wishes to decline so he can continue flying with Freeberg. Hearing
this, Ani's father says that he can only marry his daughter if he stops
flying around and takes a proper a desk job.
