---
category: past
date: 04 January 1948
status: expand
title: Cobley Makes Deal

---


Ralph Cobley, a semi-piratical British aviator,  arranges
with the finance ministry to make blockade runs in his amphibious
Catalina registered as RI-005.
