---
category: present
date: 10 October 1988
status: draft
title: Eddy Interrogates Cameron

---


Cameron is having a drink at the
Earthquake Bar, chatting with Sanyoto, when Colonel Eddy, out of
uniform, takes the empty seat beside him. Sanyoto introduces "Pak Eddy"
to Cameron and leaves them to chat. Eddy is affable, and asks Cameron
general questions about how he likes Indonesia and other inoccuous questions generally asked of foreigners. But the conversation shifts to pointed inquiries about Cameron's
education and life goals. After Eddy leaves, Cameron remarks to Sanyoto
that he feels like he has just been interrogated.
