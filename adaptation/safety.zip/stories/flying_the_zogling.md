---
category: past
date: 04 September 1946
status: draft
title: Flying the Zogling

---


Muharto pulls rank and commandeers the Zogling
training glider pulled by a Harley Davidson engine. When he lands,
Suryadarma is waiting, and angrily orders him back to his desk.
