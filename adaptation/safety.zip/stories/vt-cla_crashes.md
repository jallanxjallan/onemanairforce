---
category: past
date: 29 July 1947
status: draft
title: VT-CLA Crashes

---


Bob invites Muharto, Pang, and Boedi to his apartment
to celebrate that morning's verdict awarding the quinine to them. Bob's
housemate has a military-grade short-wave radio, which Boedi immediately
switches on and scans the military and civilian frequencies. The party
mood vanishes when a news broadcast announces that an Indian blockade
runner has been shot down on approach to Maguwo. All look toward Bob,
and he nods in acknowledgement that RI-002 might be the last remaining
hope to connect the Republic with the rest of the world.
