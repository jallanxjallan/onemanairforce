---
category: past
date: 01 July 1948
status: expand
title: Bob Defies Suryadarma

---


On his return to Jogja, Suryadarma orders Bob to Sumatra on another mission. Bob
refuses, and infuriates Suryadarma by flying to Manila that day.
