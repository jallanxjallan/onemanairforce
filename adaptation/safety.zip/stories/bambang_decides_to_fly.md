---
category: past
date: 05 October 1948
status: expand
title: Bambang Decides To Fly

---


Bambang decides to fly RI-002 back to Jogja, but
crashes on Mount Punggur.
