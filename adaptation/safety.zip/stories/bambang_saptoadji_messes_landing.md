---
category: past
date: 04 February 1947
status: expand
title: Bambang Saptoadji Messes Landing

---


In February 1947, Bambang Saptoadji messes up a landing during an air
show, severely damaging one of the Republic's few serviceable aircraft.
