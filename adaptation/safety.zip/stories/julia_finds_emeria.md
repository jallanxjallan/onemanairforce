---
category: present
date: 07 December 1988
status: rough
title: Julia Finds Emeria

---


Julia tracks down Emiria teaching art to children
in a village on the outskirts of Jogja. Emeria reveals that she after
independence she traveled to the Netherlands on a "colonial guilt"
scholarship and married a Dutch academic. On his retirement, they moved to Jogja. Emeria regrets using Victor, but says
that in war you have to choose sides.
