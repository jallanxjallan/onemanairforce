---
category: past
date: 18 October 1947
status: expand
title: Thai Authorities Released Freeberg

---


Spoor learns that Thai authorities have released
Freeberg.
