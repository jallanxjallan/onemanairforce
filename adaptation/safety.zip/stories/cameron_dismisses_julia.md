---
category: present
date: 15 November 1988
status: draft
title: Cameron Dismisses Julia

---


Julia tells Cameron about her discovery that Robert Koke had run a hotel in Bali, and that his seeming empathy and respect for Indoesians -- or at least the Balinese. Cameron
dismisses her, insisting that CIA agents are masters at dissemination.
Julia is annoyed and offended, but remains silent. Instead, she sends a
letter to Koke through the book's publisher, expressing her interest about his time in Batavia. 
