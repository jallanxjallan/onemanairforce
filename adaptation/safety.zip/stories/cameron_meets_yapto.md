---
category: present
date: 07 December 1988
status: rough
title: Cameron Meets Yapto

---


Sanyoto arranges meeting with Yapto, the head of
the Pemuda Pancasila. Yapto is affable, and expresses a sincere
apologize for the unpleasantness with his boys, which must have been a
case of mistaken identity. Yapto gives Cameron a signed business card to
show to any PP members who might threaten him in the future.
