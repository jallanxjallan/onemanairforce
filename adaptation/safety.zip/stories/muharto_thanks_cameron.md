---
category: present
date: 02 October 1988
status: rough
title: Muharto Thanks Cameron

---


Muharto
visits The Jakarta Post to personally thank Sabam and Cameron. He says
he he has been bombarded with calls from old Air Force comrades, asking
about what happened to the gold. Muharto goes on to say that he had
tried to solve the mystery himself, but had gotten nowhere.
