---
category: past
date: 10 October 1947
status: expand
title: Flying The GOC

---


Bob flies three United Nations representatives to
Sumatra, where they will assess popular support for the Republic.
