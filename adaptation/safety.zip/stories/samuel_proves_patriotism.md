---
category: interview
date: 15 October 1988
title: Samuel Proves Patriotism
status: expand
---


Samuel tells Julia that during the Bersiap period he sought the
protection of the local preman. To prove his loyalty to the Republic, he
offers to use his unique position of being able to access both colonial
and Republican worlds to act as a courier or even a spy.
