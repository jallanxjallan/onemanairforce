---
category: past
date: 15 August 1947
status: draft
title: Madras Curry

---


Muharto, Boedi and Pang are penniless as they wait
for a buyer for the quinine. Bob buys his "Javanese boys" a single meal
each day at the cheapest eatery in Manila: The Madras Curry Restaurant.
Though Muharto protests whenever Bob picks up the bill for their bowls
of curry, Bob insists that as captain of RI-002 he is responsible for
their well-being until he returns them safely to Java.
