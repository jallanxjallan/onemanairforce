---
category: interview
date: 15 October 1988
title: Auke Sonnega
status: expand
---


In mid October 1988 Julia interviews Auke Sonnega. He describes how
Emeria drew him into the Republican world.
