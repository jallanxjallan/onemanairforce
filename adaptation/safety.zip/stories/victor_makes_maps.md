---
category: past
date: 1 January 1947
status: draft
title: Victor Makes Maps

---


Victor is assigned to
the mapping department as a junior draftsman upon the recommendation of
an officer who had seen his sketches. In the mapping department, Victor
is also trained to develop photographs taken in the field to provide
references for the maps. The head cartographer, a civilian who is also
an amateur artist, realizes that Victor has a good eye for composition,
and allows him to learn photography by borrowing cameras to use during
his off-duty hours.
