---
category: past
date: 30 November 1947
status: draft
title: Mission To Bagiuo

---


Bob flies a team of
Republican officials and technocrats from Maguwo to a United Nation's
conference in the Philippines to make the case for Indonesian
independence. These highly educated, cosmopolitan men treat Bob with the
same great respect as do the common people of Jogja.
