---
category: interview
date: 15 October 1988
title: Samuel Quiko
status: expand
---

Julia goes alone to Kampung Tugu, a village on the
outskirts of Jakarta that is the home of keroncong, to interview Samuel
Quiko. Samuel tells of the peril his people faced after the war, being
regarded as "Brown Dutchmen"
