---
category: standalone
date: 08 June 1947
status: draft
title: Bob Lands On Beach

---


Bob Freeberg lands his unmarked Dakota cargo plane on
remote Cilotok beach in southwest Java, the huge aircraft shuddering to
a stop a few meters from a cliff at one end. Villagers appear, marveling
at this colossus from the sky. They are friendly and offer Bob and his
two Filipino crew members food and a place to sleep. But the following
morning, Indonesian soldiers appear. One points to the lack of
registration on the Dakotas tail and shouts "*Mata-Mata*!", "Spy!" They
point their rifles directly at Bob. He replies with the only words they
might understand, a name: "Captain Petit Muharto"
