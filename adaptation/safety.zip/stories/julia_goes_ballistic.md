---
category: present
date: 21 November 1988
status: draft
title: Julia Goes Ballistic

---


Cameron invites Julia to a party in Kemang in late November 1988. Julia
is quietly incensed when she overhears a group of Dutch men joking about
the laziness and incompetence of their Indonesian staff. She hides her
displeasure, but when another expat attempts to offer her money to leave
the party with him, she erupts in fury, shocking Cameron with her vehement denunciations of foreigners, and perhaps Cameron himself.  
