---
category: past
date: 29 December 1947
status: draft
title: Grounded In Changi

---


RI-002 departs for Pekanbaru carrying 14 Republican
officials and a coffin containing Ining's remains. Bad weather over
Pekanbaru forces RI-002 to divert to Singapore. Dutch representatives on
the island pressure the British into grounding the Dakota because of
"airworthiness" issues.
