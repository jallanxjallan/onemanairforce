---
category: past
date: 08 March 1948
status: rough
title: Cobley Threatens Freeberg

---


In the ballroom of the former Dutch
governor's palace in Bukittinggi, Richard Cobley drunkenly accuses Bob
of taking the best blockade-running contracts through his close
relationship with the Indonesian government. Later, while Bob stumbles
along an unlit path to his lodgings, Cobley confronts him, warning that
an "accident" might happen to his ramshackle Dakota unless he shares the
wealth.
