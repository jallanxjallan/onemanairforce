---
category: past
date: 10 November 1946
status: draft
title: Victor Arrives

---


Victor marches off troop ship with other recruits.
Among his possessions is a Malay-Dutch phrasebook and a sketchpad.
Victor had been told that he and his fellow recruits were being sent to
protect the Javanese subjects of the Dutch queen from a gang of
criminals and collaborators, so he had studied Malay on the voyage to be
about to communicate with the people under his protection. During the
voyage Victor had made extensive sketches of the landscape at ports of
call and along coastlines. This had attracted the attention of an
officer, who praised the rendering of detail.
