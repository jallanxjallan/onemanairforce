---
category: past
date: 15 August 1947
status: draft
title: Tom Lee Treats

---


Pang, Boedi and Muharto enjoy a brief respite from
their meager diet when Tom Lee invites them for drinks or dinner. During
these pleasant encounters, Tom expresses a lively interest in the
situation and politics of the Republic. Muharto is pleased that a
foreigner should care about the struggle of his people, and provides
voluminous answers to Tom's questions.
