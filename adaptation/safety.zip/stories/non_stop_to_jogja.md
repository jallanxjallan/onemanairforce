---
category: past
date: 21 September 1947
status: draft
title: Non Stop To Jogja

---


RI-002 returns to Java. Because the presence of Captain 
Espina must remain secret, RI-002 cannot refuel in British-controlled Labuan. They are dangerously low on fuel as
they reach Java. In the gathering darkness, Muharto has difficulty
identifying landmarks. Tension mounts in the cabin as the fuel gauges
slide toward empty. Bob admonishes Muharto saying: "This is your
country, you should now where we are!" Muharto draws on the vivid
schoolboy memory of his classmates giggling as they describe a range of
low, rounded hills near Jogja as female breasts. He soon spots the
distinctive geographic feature and, now oriented, guides Bob to a safe
landing in Jogja.
