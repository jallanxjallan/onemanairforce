---
category: past
date: 04 September 1948
status: draft
title: Suryadarma Cuts Off Fowler

---


Suryadarma takes away Fowler's fuel allowance. Fowler
resolves the issue by going over Suryadarma's head and complaining
directly to Muhammad Hatta.
