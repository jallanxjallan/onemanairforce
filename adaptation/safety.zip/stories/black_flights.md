---
category: past
date: 04 March 1948
status: draft
title: Black Flights

---


Suryadarma orders Bob to transport Republican opium to
Bukittinggi. Bob knows that if he is intercepted, the Dutch could jail
him for decades as a drug smuggler. Nevertheless, he accepts the
commission without complaint.
