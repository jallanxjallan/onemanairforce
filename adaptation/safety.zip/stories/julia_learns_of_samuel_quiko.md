---
category: present
date: 21 October 1988
status: rough
title: Julia Learns of Samuel Quiko

---


Cameron
mentions his meeting with Samuel Quiko when with Julia at the library. Julia remarks on distinctive
name, indicating a Portuguese heritage, and remembers seeing it in a
review of a musical performance in 1947. She disappears into the stacks,
reappearing with an armful of magazines containing articles about
keroncong. Julia sees that in several of the photos Samuel is with
Emeria. Julia suggests that they interview Samuel Quiko. Cameron demurs,
saying that a guy who plays "music for seniors" would be of little value
in investigating the fate of RI-002.
