---
category: past
date: 27 September 1948
status: expand
title: Bambang Watches Bob

---


During the propaganda leaflet run over Madiun on 27 September 1948,
Bambang watches Bob demonstrate how to guide RI-002 through low-level
maneuvers to evade enemy fighters.
