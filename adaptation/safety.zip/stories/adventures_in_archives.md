---
category: interview
date: 2 October 1988
status: expand
title: Adventures in Archives
---


Muharto tells Cameron and Sid of the frustrations he encountered trying
to find clues to solve the mystery in official archives and libraries.
