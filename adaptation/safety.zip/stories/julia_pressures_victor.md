---
category: present
date: 15 October 1988
status: rough
title: Julia Pressures Victor

---


Julia returns to IPPHOS seeking more information about Emeria. Victor is reticent to talk about it, but Julia charms him into revealing a few things. 
