---
category: past
date: 30 November 1947
status: draft
title: Ining Asks To Return

---


Ining writes a letter Major Primitivo asking to be
relieved of his assignment and returned home. He rushes to Maguwo, but
is seconds too late to give it to Muharto to take to Manila. George, on
duty as flight controller, is on the tarmac. He sees that Ining is
upset, so he asks Muharto's brother, Mas Ded, to take Ining back to
Jalan Jetis and stay with him until his calms down.
