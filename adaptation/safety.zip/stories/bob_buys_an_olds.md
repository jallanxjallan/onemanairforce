---
category: past
date: 04 February 1948
status: draft
title: Bob Buys An Olds

---


Bob finally receives his share from the sale of the
quinine. He sends a sizable amount to an automobile dealership in
Parsons to purchase an Oldsmobile for his parents.
