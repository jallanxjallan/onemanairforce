---
category: past
date: 04 August 1947
status: draft
title: Money For Nothing

---


One day in August 1947, Muharto attempts to pay for their meals at
Madras Curry, explaining that it is an honorarium for a talk about the
Indonesia struggle for freedom to a group of women lawyers. To his
surprise, Bob chastises him for "taking money for nothing".
