---
category: past
date: 27 December 1947
status: expand
title: RI-003 Crashes

---


RI-003 crashes on a beach in Malaya. Dutch embassy
representatives join the British investigation team at the crash site,
insisting that the aircraft had been attempting to smuggle guns into
Sumatra.
