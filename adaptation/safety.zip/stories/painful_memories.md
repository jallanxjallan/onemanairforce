---
category: interview
date: 21 October 1988
status: expand
title: Painful Memories
---


In late October 1988, Cameron tells Muharto of his interview with George
Rueneker. He cajoles Muharto into telling of the events following the
tragedy.
