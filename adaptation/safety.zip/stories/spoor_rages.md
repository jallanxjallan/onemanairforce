---
category: past
date: 18 October 1947
status: expand
title: Spoor Rages

---


Victor overhears Spoor raging at reports of RI-002
dropping paratroopers over Kalimantan. He directs his staff to pressure
regional aviation authorities to ground RI-002.
