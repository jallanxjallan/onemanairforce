---
category: past
date: 04 June 1947
status: draft
title: Subjects Of The Queen

---


Dutch representatives in Manila sue Muharto and Pang in
civil court for possession of the quinine. Fortunately, Muharto's
celebrity status also attracts the attention of Salipada Penatun, a
sitting Senator as well as a practicing lawyer. His family has close
cultural ties to Indonesia, and so offers his services pro bono.
