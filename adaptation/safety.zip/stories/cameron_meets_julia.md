---
category: writing
date: 27 September 1988
status: draft
title: Cameron Meets Julia
---


Cameron uses his Jakarta Post credentials to gain
access to the reference section of the National Library. Julia
Suryakusuma, an attractive, bookish woman in her early 20s, is the only
staffer speaking fluent English, and so is assigned to assist him, as
visitors are not allowed into the stacks. Cameron explains his mission,
and Julia disappears into the stacks, returning shortly with a few books
written by foreigners about the period. Skimming through the material,
Cameron's attention is drawn to a passage in a book by British diplomat
John Coast relating events at a gathering of foreign aviators in the
mountain town of Bukittinggi, a Republican base of operations.
