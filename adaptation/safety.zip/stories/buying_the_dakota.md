---
category: past
date: 04 March 1947
status: draft
title: Buying The Dakota

---


Bob Freeberg joins with Bob Walters to purchase a
war-surplus Dakota. They agree to equal ownership of the craft, and will
equally contribute to making it airworthy.
