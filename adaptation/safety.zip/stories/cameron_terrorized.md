---
category: present
date: 07 November 1988
status: rough
title: Cameron Terrorized

---


Cameron
receives a telephone call at the Jakarta Post. The gruff voice on the other end suggests
that Cameron stop poking into matters that are not his own business.
