---
category: interview
date: 07 December 1988
title: Captain Jack
status: draft
---

George Rueneker introduces Cameron to Captain
Jack, who had flown with Dave Fowler on oil-field supply runs. During
the hundreds of hours they spent together in the cockpit, Captain Jack
had heard all of Fowler's stories, and is happy to repeat them to
Cameron.
