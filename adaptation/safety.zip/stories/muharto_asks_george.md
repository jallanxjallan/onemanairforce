---
category: past
date: 21 October 1947
status: rough
title: Muharto Asks George

---


Muharto sees that Ining is isolated living among
the youth militia in the forest. He asks George Rueneker to keep Ining company in
his absence. George witnesses Ining berate the young recruits and sees
the displeasure on their faces. Ining asks George to bring whiskey
whenever his visits.
