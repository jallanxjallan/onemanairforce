---
category: interview
date: 04 November 1988
status: draft
title: Cameron Interviews Paul Verspoor
---

Muharto takes Cameron to meet his friend Alex
Kawilarang, Also present is a Paul Verspoor, a retired Dutch
airforce officer vacationing in Indonesia. Verspoor, who had been a KNIL
squadron leader, tells Cameron about his "very boring mission" waiting
to intercept RI-002 near Bukittinggi on 1 October 1948. Afterward, as he
escorts Muharto and Cameron to the door, Alex winks at Cameron and tells
him to keep looking, as his old friend Paul knows more than he lets on.
