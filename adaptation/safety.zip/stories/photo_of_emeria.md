---
category: interview
date: 15 October 1988
status: draft
title: Photo of Emeria
---


Victor searches for more shots of Batavia to prod his memory about
Spoor's efforts to stop the blockade runs. He stops when he comes across
a photo of a strikingly beautiful Indonesian woman who, though dressed
in baggy, paint-splattered overalls radiates elegance and poise. The
caption reads "Emeria Soenassa in her studio 1948". Julia asks Victor
who she is. Victor replies "No one important", snatches the photo from
the table and files it away.
