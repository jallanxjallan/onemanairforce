---
category: past
date: 10 September 1948
status: draft
title: Fighter Planes Tail Fowler

---


While flying a group of international journalists
to Jogja under cover of darkness, Fowler believes he spots fighter
planes tailing him. His radio operator hears traffic on Dutch military
frequencies. When when Fowler looks again, the fighters are gone.
