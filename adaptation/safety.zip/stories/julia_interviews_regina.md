---
category: interview
date: 21 October 1988
title: Julia interviews Regina
status: expand
---


In late October 1988, Julia interviews Regina. Regina describes her
experiences as a 16 year old village girl in Emeria's salon.
