---
category: wrapper
date: 5 October 1988
title: Julia Suggests Victor
status: draft
---


Julia notes that the snide tone of the language in the article suggests
the reporter was convinced that Spoor was hiding something. She says
they might get more information from Victor de Jong, a Dutch-born,
naturalized Indonesian photographer who consults for the museum. Victor,
Julia explains, had been a working in KNIL headquarters as an assistant
photographic technician/analyst and reporting directly to Spoor.
