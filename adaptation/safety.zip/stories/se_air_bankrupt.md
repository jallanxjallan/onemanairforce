---
category: past
date: 29 September 1948
status: draft
title: SE Air Bankrupt

---


Hugh Savage tells Bob that Southeast Airlines has
failed, their one aircraft has been repossessed, and he has lost his
investment.
