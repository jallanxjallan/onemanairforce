---
category: writing
date: 05 October 1988
status: draft
title: Julia Translates Newspapers
---


Cameron returns to the library to enlist Julia's
assistance. Julia is eager to help, and disappears into the stacks,
emerging with bound volumes of Dutch-language newspapers. She reads
aloud, in English, some news articles printed in the days after the
disappearance.
