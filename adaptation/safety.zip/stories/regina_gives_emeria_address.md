---
category: interview
date: 21 October 1988
title: Regina gives Emeria Address
status: expand
---


Regina suggests that Julia talk to Emeria herself. Julia is astounded to
learn that Emeria is not in Europe, but had returned to Indonesia and
now lives in Jogjakarta.
