---
category: past
date: 04 August 1947
status: draft
title: Victor Reviews Art

---


Several of the Indonesian draftsman in the mapping
office, who are are amateur artists themselves, invite Victor to
accompany them to the exhibitions of Batavia's arts scene, now regaining
vibrancy after years of privation. At an event featuring the flamboyant
Dutch artist Auke Sonnega, the artist overhears Victor giving astute
criticism of his paintings. He introduces himself and suggests Victor
write up some notes and send them, along with the photos, to a friend
who works for the Bataviaasch Nieuwsblad newspaper. Victor becomes a
regular contributor to the paper, covering the arts circuit and doing
photographic essays on street life, all while concealing his status as a
KNIL recruit.
