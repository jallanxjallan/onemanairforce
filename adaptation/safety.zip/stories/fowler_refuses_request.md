---
category: past
date: 29 September 1948
status: draft
title: Fowler Refuses Request

---


Suryadarma orders Fowler to transport a quarter ton
of gold to Bukittinggi. Fowler refuses the commission as being too
risky. Suryadarma has no choice but to turn to Bob Freeberg.
