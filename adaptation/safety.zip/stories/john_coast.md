---
category: writing
date: 04 March 1948
status: new
title: John Coast
---


In the ballroom of what used to be the Dutch governor's
palace, Richard Cobley, a semi-piratical British aviator, drunkenly
accuses Bob of taking the best contracts by scaring off others by
exaggerating the danger. Petit Muharto stands and defends his colleague,
saying that, if anything, Bob plays down the danger. Later, while Bob
stumbles along an unlit path to his lodgings, Cobley confronts him,
warning that an "accident" might happen to his ramshackle Dakota unless
he shares the wealth.
