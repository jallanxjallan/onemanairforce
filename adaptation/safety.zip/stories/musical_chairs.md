---
category: past
date: 15 March 1948
status: draft
title: Musical Chairs

---


Tensions rise in the RI-002 cockpit as Muharto and
Bambang argue over who gets to sit in the right-hand seat. Muharto
contends that as mission leader he should claim the coveted position.
Bambang counters that Muharto is not a pilot, and is denying him the
flying hours he needs to quality for piloting twin-engine craft.
