---
category: present
date: 15 October 1988
status: draft
title: Cameron at the Earthquake

---


After putting the paper to bed one evening, Syd invites
Cameron to join him for a few drinks at his favorite bar, the
Earthquake. He introduces Cameron to the owner. Sanyoto had been a drill
sergeant in the Air Force, then worked as a fixer for foreign oil
companies until he retired and opened the bar. Sanyoto maintains wide
contacts in the highest levels of government and the military, so the
Earthquake is popular with generals and cabinet ministers. Sanyoto tells
Cameron that, as a friend of Syd, he is always welcome here, as long as
he minds his manners and doesn't "needle" any of his regular guests.

That evening, the music is supplied by a band playing keroncong, a
guitar-driven genre that features sentimental Dutch-language lyrics.
Regarded as "music for old folks" the audience of senior and retired
military officers laps it up. Afterward, Sanyoto introduces Syd and
Cameron to Samuel Quiko, the band leader. Sanyoto mentions that Samuel
had been active in the revolution, and might have interesting stories to
tell.
