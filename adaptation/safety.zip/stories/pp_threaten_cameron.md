---
category: present
date: 07 December 1988
status: expand
title: PP Threaten Cameron

---


Leaving the Earthquake, Cameron is
waylaid by Pemuda Pancasila thugs. Sanyoto appears, and whacks the
leader on the nose with his cane.
