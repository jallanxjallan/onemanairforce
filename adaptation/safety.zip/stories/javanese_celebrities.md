---
category: past
date: 11 June 1947
status: expand
title: Javanese Celebrities

---


Muharto awakes to discover that he and his crew are
celebrities, with several newspapers giving front-page treatment to
RI-002 and the "Javanese Crew".
