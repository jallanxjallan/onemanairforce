---
category: interview
date: 7 October 1988
title: Pang Mentions Ining
status: draft
---


At the mention of Espina, Muharto's face clouds, and tells Pang they
must be going now. Cameron asks Muharto why they are in such a hurry,
but he does not respond.
