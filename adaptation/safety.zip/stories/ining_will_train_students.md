---
category: past
date: 07 October 1947
status: expand
title: Ining Will Train Students

---


Muharto moves Ining into a house on Jalan Jetis on
the slopes of Mount Merapi, adjacent to the forested areas where Ining
will train students to become guerrilla fighters. They toast the
occasion with whiskey brought from Manila.
