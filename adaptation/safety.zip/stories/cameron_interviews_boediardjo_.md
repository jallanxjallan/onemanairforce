---
category: interview
date: 15 October 1988
title: Cameron Interviews Boediardjo
status: expand
---


Muharto takes Cameron to a long-overdue reunion
with Boediardjo, the radio operator of RI-002. The two old comrades
revel in recounting their experiences on RI-002, including the time Bob
dove into a tropical storm to evade a Dutch patrol.
