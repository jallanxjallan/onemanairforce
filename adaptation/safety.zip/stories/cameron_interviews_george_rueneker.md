---
category: interview
date: 21 October 1988
title: Cameron Interviews George Rueneker
status: expand
---

Sanyoto introduces Cameron to George Rueneker, a retired Air Force officer
who owns an aviation-services company. George is of mixed
European-Indonesian heritage and, like many of his fellow "Indos"
decided to support the Indonesian struggle for freedom.
