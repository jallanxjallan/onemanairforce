---
category: present
date: 4 December 1988
status: rough
title: Eddy Offers Tuition

---


Julia confronts her father with the suspicion that he was behind the
PP harassment of Cameron. Eddy confesses, insisting he was doing it for
her. Anyway, he continues, this is all moot as he is not in a position
to fund her studies in an overseas graduate school. Julia refuses,
saying she would rather marry the wrong guy than see her father stoop to
corruption.
