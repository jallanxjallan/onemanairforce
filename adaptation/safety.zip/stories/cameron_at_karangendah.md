---
category: present
date: 16 December 1988
status: expand
title: Cameron at Karangendah

---


On 16 December 1988 Anwar arranges for Cameron to sneak into Karangendah
with his nephew, who is smuggling out tank diesel engine parts which are
military grade and reliable. Good for smuggling boats.
