---
category: interview
date: 07 November 1988
title: Ani Reminisces
status: draft
---

Cameron and Julia have dinner with Muharto and
Ani. Afterward, Cameron and Muharto fall deep into discussion about the
revelations of their investigations. Ani and Julia that their men
are plummeting down a conspiracy rabbit hole, but keep their
views to themselves. Instead Ani tells Julia stories when her husband
was a dashing young officer, and of the hardships of life in besieged
Jogja.
