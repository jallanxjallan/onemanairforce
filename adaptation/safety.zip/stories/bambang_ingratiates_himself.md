---
category: past
date: 15 June 1948
status: draft
title: Bambang Ingratiates Himself

---


On the Soekarno Tour Bambang ingratiates himself with
Soekarno in the hope of being selected to fly RI-001. Boedi finds his
efforts, and Soekarno's condescending replies, amusing.
