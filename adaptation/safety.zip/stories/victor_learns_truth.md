---
category: present
date: 07 December 1988
status: rough
title: Victor Learns Truth

---


Julia tells meets Victor to tell him about her
encounter with Emeria. Victor now confesses to Julia that he did not
resign from KNIL after independence, but deserted during the taking of
Jogja so he would be with Emeria. Julia then explains that Emeria was
just using him to get information about Spoor. Victor does not speak as
he turns away to sort photographs.
