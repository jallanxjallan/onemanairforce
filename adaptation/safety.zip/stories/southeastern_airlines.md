---
category: past
date: 04 December 1946
status: expand
title: Southeastern Airlines

---


Bob partners with Singapore-based businessman Hugh
Savage to start Southeastern Airlines.
