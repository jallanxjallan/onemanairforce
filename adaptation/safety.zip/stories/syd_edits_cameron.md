---
category: present
date: 26 September 1988
status: draft
title: Syd Edits Cameron

---


Cameron writes up the interview, and gives it to
managing editor Sabam Siagian, who had given him the assignment. Sabam
glances at the copy, grunts, then passes the pages to Syd Jardine, the
senior copy editor. Syd reads it, then remarks that Freeberg comes off
as a "super-pilot" and not entirely credible. He suggests Cameron find other
accounts of Bob by researching in the reference section of the newly
opened National Library.
