---
category: past
date: 04 April 1948
status: expand
title: Savage Loses confidence

---


Hugh Savage tells Bob that he is concerned that the Bob
Walter's fiasco has warned off potential customers and investors of SE
Airways.
