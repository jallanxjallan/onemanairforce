---
category: past
date: 04 September 1948
status: expand
title: Suryadarma Takes Fuel Allowance

---


Suryadarma takes away Bob's fuel allowance for
undisclosed reasons.
