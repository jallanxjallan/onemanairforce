---
category: present
date: 22 November 1988
status: rough
title: Cameron Grows Doubtful

---


Julia confronts Cameron with the evidence that
Muharto was the point man for the CIA air force. Cameron insists that
Julia has misinterpreted the article.
