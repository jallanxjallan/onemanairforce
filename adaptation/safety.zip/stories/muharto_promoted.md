---
category: past
date: 15 May 1948
status: expand
title: Muharto Promoted

---


Suryadarma gives Muharto the good news that he is being
promoted to major and reassigned. The bad news, at least according to
Muharto, is that his new position is administrative and he will be
piloting a desk.
