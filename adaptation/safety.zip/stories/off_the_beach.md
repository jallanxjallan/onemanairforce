---
category: past
date: 09 June 1947
status: draft
title: Off the Beach

---


Arriving at Cilotok, Muharto and Pang
marvel that Freeberg had been able to land on this short stretch of
beach, bookended by high bluffs. Muharto recognizes Freeberg and they
greet as friends. Fearing that a patrolling Dutch fighter could appear
at any time, Muharto, in a stirring speech, implores the assembled
villagers to tear apart their houses to fashion an improvised runway
from the bamboo mats used as walls. They do so, and with Muharto and
Pang on board, the Dakota takes off and flies to Maguwo.
