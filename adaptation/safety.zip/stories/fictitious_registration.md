---
category: past
date: 10 June 1947
status: draft
title: Fictitious Registration

---

In Maguwo  Suryadarma commissions Bob to
fly a cargo of high-value quinine to Manila and return with essential
medicines and spare parts. Suryadarma assigns Muharto as mission leader, and tells Pang Soeparto to accompany them, as the quinine is the property of the army. He also assigned a young airman, Boediardjo, a Dutch-and-English-speaking graduate of a technical college, as radio operator.  

Muharto expresses concern about the reception
that might await unmarked aircraft carrying high-value goods into
Manila. He suggests that they paint a fictitious registration number
onto the tail. Muharto suggests RI-002. Bob says it should be RI-001, as
his is the first aircraft. Suryadarma, imperiously, states that "RI-001"
is reserved for a future presidential aircraft. Bob grumbles as
Suryadarma issues the order to paint the number on the Dakota's tail. 
