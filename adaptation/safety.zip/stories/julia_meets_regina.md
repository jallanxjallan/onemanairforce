---
category: present
date: 15 November 1988
status: draft
title: Julia Meets Regina

---


Julia reads a notice about an upcoming exhibition
by an amateur watercolorist named Regina. Her bio mentions Emeria as one
of her influences. At the exhibition, Julia learns that Regina had been
Emeria's pembantu, and so arranges an interview.
