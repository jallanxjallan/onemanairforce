---
category: past
date: 04 September 1947
status: draft
title: Victor Assigned To Spoor

---


Arriving at work, Victor sees a sealed
envelope on his desk that he knows to be reassignment orders. He opens
the envelope with dread, certain that he is being sent to a combat unit.
But the orders are to report to KNIL headquarters, where he
will work as an assistant photographic technician with
Spoor's intelligence unit.
