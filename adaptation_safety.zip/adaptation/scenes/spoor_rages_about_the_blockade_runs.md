---
identifier: 9f108f29
title: Spoor pissed at Bob
date: January 1948 
location: KNIL Headquarters
---

``` {.synopsis}
Spoor rages about the news that RI-002 seemingly had assisted Espina to smuggle guns into Indonesia. He vows to end the blockade runs by any means nescessary.
```
