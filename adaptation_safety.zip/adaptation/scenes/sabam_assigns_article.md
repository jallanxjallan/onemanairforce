---
identifier: ee4c5683
title: Cameron Keeps Pestering
date: 27 September 1988 
location: Jakarta Post
---

``` {.synopsis}
In September 1988, Cameron, a  American journalism graduate doing a year's internship as a copy editor The Jakarta Post, an English-language daily newspaper, pitches a story idea to managing editor Sabam Siagian. Sabam rolls his eyes and explains, yet again, that, under the rules set down by the government,  non-Indonesian newsroom staff cannot do actual reporting. Then for a moment, Sabam relaxes his gruff demeanor and tells Cameron he can interview his old friend former Air Force officer Petit Muharto about his experiences during the post-war struggle against the Dutch. This is a feature, not news, and anyway, says Sabam "No one else has time."
```
