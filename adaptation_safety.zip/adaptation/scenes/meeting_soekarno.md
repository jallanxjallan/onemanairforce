---
identifier: da473ddd
title: Bob Meets Soekarno
date: October 1947 
location: Palace
---

``` {.synopsis}
Muharto takes Bob to meet Soekarno . At the presidential palace. As was
his custom in private conversation, Soekarno treats Bob as an equal and
urges him to stay and help the struggle.
```
