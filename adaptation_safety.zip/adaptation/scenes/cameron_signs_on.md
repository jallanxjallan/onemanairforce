---
identifier: 3d9947a1
title: Cameron Begins Investigation
date: 3 October 1988 
location: Muharto
---

``` {.synopsis}
Cameron visits Muharto to help solve the mystery of RI-002. Muharto is delighted, and suggest they begin with a visit to Jogjakarta, where pieces of the RI-002 wreckage is kept. 
```

Cameron visits Muharto to say that he would like to help Muharto finally
solve the mystery of RI-002. Muharto is delighted, saying that a good
place to start would be the Aviation Museum in Jogjakarta, where the
items recovered from the RI-002 wreckage are stored. In addition, he
could visit his spiritual advisor there to seek supernatural blessing 
for a successful outcome of their endeavors.
