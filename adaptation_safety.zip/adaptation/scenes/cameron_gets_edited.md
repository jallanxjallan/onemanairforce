---
identifier: e6f52dcc
title: Syd Edits Cameron
date: 29 September 1988 
location: JakPost
---

``` {.synopsis}
Syd Jardine, a burnt-out Old Asia Hand who is senior copy editor for the Jakarta Post, tells Cameron that his story on Bob Freeberg needs more historical context, and suggests he do additional research at the new National Library, a modern, well-run institution that he visits regularly.
```

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Cameron writes up the interview, and gives it to Sabam. However, Sabam is on his way to a diplomatic dinner, and simply hands the pages to Syd, an American  retired foreign correspondent who works as senior copy editor, and rushes out the door. Syd reads the piece, and suggests that Cameron corroborate 
Muharto's story with newspaper and other reports, which he can find at the newly opened National Library. 
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

In the Jakarta Post newsroom, Cameron finishes the first draft of the
Muharto interview, then hands it to Syd Jardine, a disheveled,
chain-smoking, older American sitting at the adjacent desk. After
reading it, Syd tells Cameron that the article is good, but a bit thin,
and needs more context to be understandable to the Post's foreign
readership. Syd suggests Cameron go to the national library and read the
book *Recruit to Revolution*, which has a chapter on Freeberg, and all
the historical background Cameron needs.