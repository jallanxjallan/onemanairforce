---
date: August 1947
location: ABBar
---

```synopsis
Tom Lee invites Muharto and Boedi to dinner, during which he displays a great interest in the political and military situation in Jogjakarta. Boedi hints that Tom's hospitality had another purpose.
```

Boedi and Muharto enjoy a brief respite from their meager diet when Tom Lee invites them for drinks and dinner. Tom Lee asks Muharto and Boedi about the
political situation in Java. Boedi attempts to the steer the
conversation onto a neutral subject, but Tom presses the inquiry, and
Muharto obliges with more detailed info. As Tom pays the bill at the counter, Muharto tells Boedi that he is pleased the Tom has such an interest in our struggle.
Muharto says he is guilty about accepting such generosity from the
American, and hopes that when the quinine his sold he can treat Tom to
dinner. Boedi just smiles.

