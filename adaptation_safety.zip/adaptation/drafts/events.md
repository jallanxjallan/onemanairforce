1. Soekarno and Hatta declare independence of Indonesia on  17 August 1945
2. Dutch return in force to reestablish authority in  January 1946
3. Republican government relocates to Jogjakarta in February 1946
4. Dutch and RI sign Linggarjati agreement 15 November 1946
5. Spoor orders a blockade around Republican areas  in December 1946.
6. Spoor orders Operation Product on 21 July to 4 August 1947. Dutch sweep out of Batavia to secure north coast. Took Karangendah airfield but stopped short to Jogja.
7. AURI bombers raid Dutch installations on the North Coast on 29 July 1947
8. DC3 carrying two AURI officers crashes on approach to Jogjakarta on 29 July 1947. Indonesians claim that aircraft was shot down. Dutch insist that fighters fired only warning shots, and the pilot panicked. 
9. RI-002 drops paratroopers over Kalimantan on 17 October 1947. It was the first jump for everyone, and many are terrified. One soldier pulls his ripcord, spilling his parachute on the deck. He swears it was an accident, but others grip their cords, possibly ready to do the same. Later, Bob discovers that all had been killed by the Dutch commandos within hours. crew Soeharnoko Harbani, Soenaryo, Bambang Saptoadji, Boedihardjo, Moelyono Adikusuma dan Dhomber (Dayak)


6. Dutch troops kill many civilians in the village of Rawagede on  9 December 1947 
2. Dutch and Indonesians sign Renville agreement on 17 January 1948. Resulted in Siliwangi Division relocating to Jogja, further straining resources.
3. Communist cadres launch rebellion in Madiun on 18 September 1948. Republican officials flee or are captured.
4. Dutch troops invade Jogja on 27 Dec 1948. Capture Nationalist leaders
