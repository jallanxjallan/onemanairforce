1. Muharto reads of crash site discovery in 1977.

2. Muharto researches in AURI archive and other collections. Finds only disorder and obstruction as librarians make life difficult. He finds the investigation report, which asks more questions than it answers. Photo of dynamo with bullet in windings. Sulaiman  and team investigate wreckage. Find empty crates of gold 

3. Muharto writes letters.  Old Auri classmate claims no knowledge. Victor Panggebean evasive.  Sulaiman does not reply.

4. Victor tells of the Dutch side of the RI-002 story, the almost comical interviews with Dutch officials who were driven to distraction by  Freeberg’s blockade runs.

5. Cameron receives photocopies of letters from the Freeberg family.

6. Reveal that Bob never mentioned Muharto by name. Cameron receives Freeberg letters from family. Freeberg never mentioned Muharto. learns that, despite his view as being Freeberg's close friend, Bob never mentions him or the other Indonesian crew. Only casually as: “My boys”

7. Muharto goes into trance holding dynamo. He is in rear of flight deck. Looks forward to see two silhouetted figures in pilot seats.

8. Hadi Santoso tells of stealing fathers necklace from casket when guard's back was turned. 

9. Ibu Santoso faints and has visions Tanjung Karang ceremony.

10. Muharto goes into trance holding necklace. He is in co-pilot seat. turns to left to see Bambang in pilot's chair. 

11. George Reuneker tells Cameron of issues with Ining. 
    interviews Victor arranges for Cameron to interview Frank Reuneker, and introduces Dave Fowler. 

12. Cameron interviews Boedi again, after first giving him the painting from Affandi. Boedi knows Affandi to be an excellent judge of character, and so warms to Cameron. He tells him all the details left out of previous conversations. Ining's death, and Muharto interrogated by Primitivo

13. Victor suggests Cameron talk to Julius Tahija. Cameron uses his JP credentials to interview Tahija without Sabam's knowledge. 

14. Julia finds photo of RI-002 at  Karangendah. 

15. Cameron is convinced answers lie in Karangendah. Cameron talks Julia into coming with him to check it out.

16. Cameron and Julia are introduced to Agus.

17. Agus tells of seeing Santoso with the others in detention. 

18. Agus sneaks Cameron and Julia onto Karangendah tank base. Have to dodge tanks on maneuver. 

19. Agus reveals that gold was used to purchase guns smuggled from Malaya, which then taken overland to Lampung by Sumatra preman.


