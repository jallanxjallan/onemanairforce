# BAMBANG SAPTOADJI
• Bambang born in village. 
• Bambang brash and overly confident in abilities.

# BOB WALTERS
1. Walters Tells Boedi stories of Dave Fowler and Rick Cobley
2. Walters badmouths Freeberg to Boediarjo. Insists Freeberg is a cheat.
3. Walters acts unhinged throughout the latter half of 1947.


# GEORGE REUNEKER
George is an indo who sided with the Republic. He and his son founded Aviation George went on to found an aviation company, which flourished servicing the foreign oil companies in remote regions.


# JUNE
•   June begs Bob to return to US.  "These people own you nothing. They are just using you.


# MAJOR PRIMITIVO
• Head of Philippine army intel
• Assigned by Roxas as liaison with RI through Muharto and Pang
• Virulent  anti-communist
• Close ties with American intel, including the newly formed CIA.


# MISS BROWN
Flight attendant of the three CALI blockade runs
Boedi runs into her while having coffee (in a respectable coffee shop) with another pilot.

☐ Stories Miss Brown can tell about CALI blockade runs and other pilots.

# MOELJONO
• Moeljono is an ace pilot. 
• Moeljono Friendly rival to Bambang Moeljono 
• Moeljono handsome. Like Gary Grant. Suave and charming. 
• Moeljono is given the prime assignment. Piloting the Hayabusa bomber for the Ambarrawa Raid.
• Moeljono selected to relocate RI-005 from Bukittinggi to Jogjakarta. 

# SIMON SPOOR
Bio
• Spoor concerned about gun running.
• Spoors orders operation product
• Spoor Furious at Bob over Ining incident. Vows to crack down on gun running
• Spoor has reservations about Westerling
• Spoor learns about KNIL corruption. The irony that his own officers were the gun runners. 


# SURYADARMA
• Suryadarma Chief of Staff of AURI
• Suryadarma Treats foreign pilots flying RI-00x registration like his own AURI pilots. Demands military chain of command. This puts him at serious odds with Aviation Brotherhood.
• Suryadarma has sense of entitlement


# TOM LEE
• Tom Lee is an American government lawyer and suspected intelligence asset. 
• Tom Lee advises Bob that deporting Walters would be a bad move.
• Muharto raises suspicion about Lee with Chrysler story.
• At the end revealed that Lee was only a lawyer.


# WALTER FOOTE
• Foote is pro-Dutch American consul in Batavia
• Shares Spoor's view that Indonesians cannot govern a nation.
• Worked closely with OSS during Operation Rust with Robert Koke
• Like to be called Uncle Billy. Treated Indonesians, including Hatta and Sjahrir as errant nephews.
• Affable but considered a lightweight

# AUKE SONNEGA
Harley riding painter, graphic designer
Center of Batavia Kuntskring
Crush on Emiria
Jealous of Victor. 
Undermines victor be getting word to Spoor that Victor is meeting with Republicans through Emiria.

# BOB FREEBERG
• Bob is a straight shooter. Others seduced by the easy life in the east. Bob compares Lives of expats in Manila contrasted to deprivation in jogja
• Bob is haggard. Grey hairs at 27.
• Bob is responsible for crew. Insists that as captain of RI-002 he is responsible for them until they return to Java As they wait for the verdict.
• Bob handles petty annoyances. Handles the little problems with his apartment and room mates, his jeep etc with a sort of gruff good nature.  
• Bob shows his appreciation for local customs when Boedi's mothers buntil becomes his favorite dish. 


# IGNATIO ESPINA
• Experienced guerrilla with Philippines army.
• Party animal 
• Arrogant and easy to offend
• drinking problem made worse by isolation
• Muharto organized the deal with Primitivo, so, as in the Indonesian fashion, is responsible for him
• Brings him whiskey on every flight to keep him happy.

# AFFANDI
• Cameron meets Affandi in Jogja. Deeply affected when taken into back room to see 
• Cameron loves resting guerilla. 


# AGUS
• Agus speaks Dutch. Agus did not tell anyone that he speaks Dutch, so overheard officers plan to take the gold, buy guns, and sell them back to the rebels. No word about a coup. It was all about corruption.
• Agus stole food. He stole other practical goods from the Dutch, and kept doing it under the Armyas Mess boy, invisible.
• Agus is a preman. part of Outlaw culture in South Sumatra.
• Agus friends smuggled guns across Dutch territory to Republican forces in Lampung.  
• Agus was Mess boy at karangendah during 40s
☐ How do they find out about Agus?

# ANI MUHARTO
• Ani has noblesse oblige. Ani and her mother help to organize food for the refugees flooding into Jogja.
• Ani teaches school. With no resources save a blackboard and half piece of chalk.
• Ani tells wedding guests to wear shabby clothes with pride.
• Ani endures hardships in preparing for marriage
• Ani bests Westerling when detained in market during Operation Crow


# BOEDIARDJO
Wiki bio
Introduction through Syd.
• Boedi interviewed surrounded by Affandi paintings
• Boedi serves Cameron buntil, from mother's recipe. 
• Boedi hangs out with Aviation Brotherhood. 
• Boedi started on First Flight. On every mission until after Soekarno Tour.
• Boedi mentions that when not resting or working on his plane, Freeberg would be writing letters home.
• Boedi strives to improve his (already adequate) English by hanging out with members of the Aviation Brotherhood, who enjoy his company. The pilots of the Aviation Brotherhood are reluctant to accept the stiff and reserved Muharto, but the charismatic Boedi is welcomed into the fold.  
• Tells Cameron that, even when telephones are available, anyone can drop in at the 4 pm visiting hour and he will receive them. Old Javanese custom. This will be important later, and also give Cameron a chance to meet other visitors. 

# GEORGE RUENEKER
• Change name and other details to deal with fact that George died ten years before. 
• George writes to Dave Fowler, who was in the indonesian aviation industry until 1956, and during the New Order until 1980. 
• George introduces story of Ining, which much surprises Cameron.

# JULIUS TAHIJA
• Julius was Spoors adjudant. As KNIL officer adjutant to Spoor
• Julius not a confidant. Spoor cannot confide. All in Tahija as he is Indonesian at heart. 
• Julius witnesses Spoor daily duties., Westerling, and the colonial government.
• Julius still running Caltex when Cam interviews him. 
• Julius raised money for Freeport. And was Chairman of the Board. Tahija worked to get best possible deal for Indonesians when working with foreign scoundrels. 
• Julius tells Cameron that much of his career has been spent keeping foreign investors on line. At the end Cameron asks about his time with spoor. Saying he had come across his readings. Julius grins saying no one likes to talk about that any more.

Bio

# SUDARYONO
Sudaryono is Adisucipto's younger brother
• Sudaryono saw VT-CLA crash.

# ALEX KAWILARANG
 Cameron meets Alex.
  Cameron mentions his suspicions about  Kopassus  and gold.
  Alex angrily says: “My boys are killers, not thieves”
  Then tells Cameron to be careful. The authorities already know what you are doing. But you are too insignificant to bother with...yet.
Reveals that Spoor called off attack on POAS journalists flight
Mentions that Karangendah was Palembang II.

# JIM CASTLE
 40 years ago these guys were shopkeepers. They still look like it. Guy sitting outside a diesel parts shop does a ten million sales a year. So they are easy picking s for the scammers. Bruce rappapprt and sutowo.

# CAMERON
• 22 years old.
• Just graduated with degree in journalism. Favorite professor who knows Sabam from Harvard arranged for one year internship with Jakarta Post.  
• Cameron graduated with degree. Worked for local newspaper but unhappy with trivial work and low pay.
• Cameron worked in boiler room. College drinking buddy got Cam a job as stock broker in US boiler room. Narrowly escaped jail when company raided
• Partially based on Paul Handley. 
• Our reporter tells him “Any hack can get himself kicked out of the country”
• Cameron flees to Jakarta to live with sister working in American bank invites him to use spare room in Kemang mansion until case settles down.
• Cameron meets Sabam at one of her parties. Invited to join Post newsroom staff because of familiarity with both journalism and financial matters to explain the deregulation packages of 1988. JP gearing up to be reliable source of info for foreign investors as the banks and capital markets are deregulated in 1988.
• Cameron rides a Harley Davidson he bought from a friend of Syd. 

# JULIA
• Julia is from a priyayi family. 
• Only child, which is unusual in Indonesia. So her father will give her anything she wants. 
• Envious of all her anak jendral friends being able to take master's degrees in America and Europe. 

• Juila impressed by Ani. Tales of hardship and resilience in Jogja make Julia think she can make a difference.

• Same background as Ani. Both from Jogja so distant connection between families. This is when Julia's parents to not object to her traveling to Jogja with Cameron is given permission to stay at Ani's sister's house. 
• Julia got full scholarship to take degree at UI. Now working in library both for credit and pocket money
• Julia loves reading which is rare in Indonesian women. Always saw her father reading. His job was to read books for censorship.
• Auntie Sita would bring her books from the Netherlands, so she learned to read Dutch as well as English. 
• Got position in library because of ability to read Dutch and English. 
• Julia pushed to marry Cameron. Friends from OKB families. Pushing her to marry Cameron for the perceived money of a bule.
• Family pushes her to marry Javanese guy. bobot, bibit, bebet 
• Though having no formal library training, Julia's fluency in both Dutch and English, passion for reading and a talent for organization were deemed sufficient qualifications for this job. She is also informally the person delegated to attending to foreign visitors. 
•  First fight between Cameron and Julia is when he takes her to a Kemang party and she is mistaken for a bar girl


# PETIT MUHARTO
• Muharto insists that he and Bob were close friends. 
• Muharto has tidy home in southern suburbs. Full of Javanese bric a brac.
• Initially Muharto does not mention Ining because the memory is painful. 

# SABAM SIAGIAN
Bio
• Trained at Harvard
• founding editor of post
• left in 91 to become Ambassador to Australia


# SYD JARDINE
Model
• Based on partially on Syd Perret and David Jardine. 
• Wicked sense of humor. 
Background
• Syd  is a washed out old Asia hand, former foreign correspondent
• Syd  crusading journo, high ideals in his day.
• Syd  Arrived in HK in the 60s on a boat like John McBeth.
• Syd  settled in Indonesia after marrying an Indonesian woman he knocked up. 
• Now divorced and penniless.
Jakarta Post
• Syd  is a good copy editor, works cheap, always shows up. So Sabam must keep Syd  instincts in check. This is difficult, as he is the last person to see the copy before it goes to the press.  
• OR speaks fluent Javanese and thoroughly familiar with Jakarta bahasa gaul and allusion
• Always trying to sneak Pos Kota sex-crime translations into Post when Sabam is preoccupied. Running gag.
• Sabam cannot fire him because his knowledge of Indonesian culture enables him to pick up potentially damaging references that have escaped the new recruits. Comes out in session with sabam in lapo.
• Sabam often confers with Syd in office. Syd advises him on reporting government corruption scandal. 
• Cam always asks how you get away with it. Syd only smiles.
Behavior
• Syd  lives in room in Jalan Jaksa like David Jardine. 
• Syd  encourages Julia to read.
• Syd  Fluent in both proper indonesian and slang, which he used to use in previous job. 


# VICTOR
• Julia introduces Cameron to Victor. Says he is always there.
• Chronic skin condition from confinement. Like the cold climate of the newspaper archive.
• Victor helps Julia with obscure Dutch vocabulary in newspapers.
• On visit to library, Julia points out Victor. Says he is here at least one day a week.

-  KNIL conscript
   talented artist and photographer
   worked for mapping department
   attended art exhibits so met progressive Dutch and educated Indonesians
   flew to Karangendah to map area
   Spoor used him as documentary photographer. Blended into the background, saw encounters like the friendly meetings of Spoor and Walter Foote.
  Deserted in Jogja during Operation Crow. 
  Received Indonesian citizenship right after transfer of sovereignty

# GENERAL EDDY
• Eddy born in 1945 in Semarang from priyayi parents like Muharto
• Speaks Dutch and English fluently. Reads for pleasure
• Followed family tradition of military service. Father and uncles were guerilla fighters.
• Rose through ranks of intel because of ability to read and absorb information.
• Never corrupt. Always on a budget


