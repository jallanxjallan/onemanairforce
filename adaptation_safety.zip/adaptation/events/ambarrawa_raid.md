---
identifier: e5f45d8b
title: Ambarrawa Raid
date:  
location: 
---

7.  AURI bombers raid Dutch installations on the North Coast on 29 July
    1947
