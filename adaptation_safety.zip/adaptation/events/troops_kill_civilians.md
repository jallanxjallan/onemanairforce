---
identifier: c5a947e8
title: Troops Kill Civilians
date: 9December 1947
location: Rawagede
---

Dutch troops kill many civilians 