---
identifier: 41c79289
title: Madiun Rebellion
date:  
location: 
---

3.  Communist cadres launch rebellion in Madiun on 18 September 1948.
    Republican officials flee or are captured.
