---
identifier: d33469d2
title: Renville Agreement
date:  
location: 
---

2.  Dutch and Indonesians sign Renville agreement on 17 January 1948.
    Resulted in Siliwangi Division relocating to Jogja, further
    straining resources.
