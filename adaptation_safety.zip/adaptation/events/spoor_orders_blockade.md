---
identifier: 31f64a3b
title: Spoor Orders Blockade
date:  
location: 
---

5.  Spoor orders a blockade around Republican areas in December 1946.
