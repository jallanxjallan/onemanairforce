---
identifier: 82217952
title: VTCLA Crashes
date: 29 July 1947 
location: Bob
---

``` {.synopsis}
Muharto and Boedi listen in horror to shortwave radio reports that a blockade runner has been shot down on
approach to Maguwo. 
```

Bob, Muharto and Boedi listen in horror to shortwave radio reports that
the blockade runner that Suryadarma had chartered had been shot down on
approach to Maguwo. Muharto turns to Bob and asks if he is still willing
to aid the Republic by flying through the blockade at the risk of being
shot down. Bob nods.
