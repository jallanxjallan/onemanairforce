---
identifier: f868409f
title: Initial Muharto Interview
date: 28 September 1988 
location: Muharto living room
---

``` {.treatment}
Cameron meets Muharto, a dapper, energetic Indonesian man in his
late sixties, at his tidy residence in a Jakarta suburb. Muharto recounts his exploits in RI-002 in such vivid detail that Cameron can clearly visualize the events Muharto is describing starting with a surprise telephone call he received at Maguwo Airbase in Jogjakarta on June 1947.
```
