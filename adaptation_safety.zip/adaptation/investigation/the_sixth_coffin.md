---
identifier: a05b0dff
title: The Sixth Coffin
date: 29 July 1977 
location: Teluk Betulu Air Force base
---

``` {.treatment}
In an otherwise empty hanger, five coffins draped in Indonesian flags
lay on a platform. A sixth coffin, larger than the rest and without a
flag, rests on a separate platform. A flatbed truck pulls in to the
hanger and a a squad of airmen, all silent and respectful pick up each
of the coffins and place them on the truck. But they leave the sixth
coffin where it lies as the truck pulls away.
```

In an otherwise empty hanger, five coffins draped in Indonesian flags
lay on a platform. A sixth coffin, larger than the rest and without a
flag, rests on a separate platform. A flatbed truck pulls in to the
hanger and a a squad of airmen, all silent and respectful pick up each
of the coffins and place them on the truck. But they leave the sixth
coffin where it lies as the truck pulls away.
