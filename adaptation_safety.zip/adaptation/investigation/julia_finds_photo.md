---
identifier: 6cb93a11
title: Julia Finds Photo
date:  
location: 
---

14. Julia finds photo of RI-002 at Karangendah.
