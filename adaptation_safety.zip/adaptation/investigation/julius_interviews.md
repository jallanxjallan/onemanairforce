---
identifier: 8d4f0574
title: Julius Interviews
date:  
location: 
---

13. Victor suggests Cameron talk to Julius Tahija. Cameron uses his JP
    credentials to interview Tahija without Sabam's knowledge.
14. Julius reveals that Spoor used Victor to gather intel on the
    left-leaning artsy crowd. He was in Spoor's words, a "Useful Idiot"
