---
identifier: d8b9bd29
title: Santoso Interview
date:  
location: 
---

9.  Ibu Santoso faints and has visions Tanjung Karang ceremony.

10. 8.  Hadi Santoso tells of stealing fathers necklace from casket when
        guard's back was turned.

11. 10. Muharto goes into trance holding necklace. He is in co-pilot
        seat. turns to left to see Bambang in pilot's chair.
