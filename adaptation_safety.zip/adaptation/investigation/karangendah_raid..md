---
identifier: 59d67d18
title: Karangendah Raid.
date:  
location: 
---

16. Cameron and Julia are introduced to Agus by ?
17. Cameron is convinced answers lie in Karangendah. Cameron talks Julia
    into coming with him to check it out.
18. Agus sneaks Cameron and Julia onto Karangendah tank base. Have to
    dodge tanks on maneuver.
