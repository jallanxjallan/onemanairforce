---
identifier: 54e51fee
title: Ani Serves Rice
date:  
location: 
---

3.  Ani serves rice to refugees. She has no idea what to do in kitchen,
    never having been in one before.
