---
identifier: 93737e8e
title: POAS Flights
date:  
location: 
---

3.  Dave Fowler begins POAS flights from Bangkok to Jogja.
