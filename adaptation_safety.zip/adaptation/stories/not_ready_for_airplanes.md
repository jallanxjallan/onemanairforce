---
identifier: fdf190fd
title: Not Ready for Airplanes
date:  
location: 
---

7.  Bob is annoyed when Bambang shows up late for opium run, forcing him
    to cancel the mission.
