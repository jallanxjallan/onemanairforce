---
identifier: abdca5a0
title: Arts Circle
date:  
location: 
---

2.  Attends art exhibitions and takes photographs of event. One of other
    guests talks to him and hears astute art criticism, so suggests he
    write up reviews and so sell his photos to the newspapers. He does
    this several times, and also does good photos of street life.
