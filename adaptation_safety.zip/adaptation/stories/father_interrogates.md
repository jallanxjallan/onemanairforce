---
identifier: 9af7318a
title: Father Interrogates
date:  
location: 
---

1.  Ani's father questions Muharto's "demotion" from Lt Col. to Captain
