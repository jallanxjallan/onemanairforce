---
identifier: b8a33df3
title: Grad School Offer
date: October 1988 
location: Julia
---

``` {.synopsis}
The day after her date with Eric, General Eddy hints that the business deal with Eric's father will provide him with enough funds to send Julia to graduate school in America, fulfilling her dream. 
```

General Eddy asks Julia about her date with Eric. Julia does not want to
tell her father that she finds Eric an egoistical bore, so she says that
a relationship would be impossible because he will shortly to America
for post-graduate study. At that Eddy smiles, and tells Julia that she
could do the same. Julia counters it would be too expensive, but her
father says not to worry.
