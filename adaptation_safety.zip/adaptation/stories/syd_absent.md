---
identifier: f0db1165
title: Syd Absent
date:  
location: 
---

7.  Syd does not show up for work. Cameron drops by Syd's shabby room in
    Jalan jaksa and finds him dead in his favorite reading chair.
