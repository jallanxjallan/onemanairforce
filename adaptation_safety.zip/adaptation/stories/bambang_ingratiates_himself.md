---
identifier: 6fece512
title: Bambang Ingratiates Himself
date:  
location: 
---

9.  During the Soekarno tour, Bambang ingratiates himself with Soekarno
    in the hope of being selected to fly RI-001. Boedi finds his
    efforts, and Soekarnos condescending replies amusing.
