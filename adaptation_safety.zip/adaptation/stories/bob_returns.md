---
identifier: d8d2580e
title: Bob Returns
date:  
location: 
---

14. Bob returns from a six-week layover in Manila with both pilot and
    aircraft in good shape.
