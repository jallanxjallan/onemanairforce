---
identifier: d885200d
title: Ani Gives Muharto
date:  
location: 
---

5.  Ani gives Muharto a long list of household items to pick up in
    Manila.
