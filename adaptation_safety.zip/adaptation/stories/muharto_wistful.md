---
identifier: 93d0539c
title: Muharto Regrets
date: 28 September 1988 
location: Muharto
---

``` {.synopsis}
Muharto tells Cameron that the sixth coffin, presumably containing Bob’s
remains, could not be buried with the others as a foreigner cannot be interred in a cemetery for national heroes, however much he may deserve the honor himself through his services to the nation.

Muharto’s expression as he finished his reminiscences convinces
Cameron that he regarded Freeberg as a close friend, and is seeking
closure about his mysterious disappearance. Muharto wonders that if he had turned down promotion and had been with Bob on the final flight, maybe it would not have ended in tragedy. 
```

Muharto tells Cameron that the sixth coffin, presumably containing Bob's
remains, could not be buried with the others because he was a foreigner.
Muharto explains that he became aware of the discovery of the crash
site, wholly accident, some five years previously. He wrote his contacts
in the air force and to the officers who participated in the crash-site
investigation, but received only vague, non-committal replies -- or only
silence. Muharto's expression as he finished his reminiscences convinces
Cameron that he regarded Freeberg as a close friend, and is seeking
closure about his mysterious disappearance. Muharto finishes by saying,
wistfully, that his is sure many people know more about the mystery of
RI-002 than they are telling.
