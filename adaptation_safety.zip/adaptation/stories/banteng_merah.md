---
identifier: 0346ab73
title: Banteng Merah
date:  
location: 
---

1.  In March 1946, one of a handful of Indonesian aviators, Augustinus
    Adisucipto, flies a reconditioned biplane left behind by the
    Japanese.
