---
identifier: 91919c5a
title: Funding the Coup
date:  
location: 
---

19. Agus reveals that gold was used to purchase guns smuggled from
    Malaya, which then taken overland to Lampung by Sumatra preman.
