---
identifier: 8f0848f2
title: Last Corned Beef
date: November 1947 
location: Merdeka
---

``` {.synopsis}
On the day the GOC members leave Jogja, Bob invites Boedi and Muharto to join him for dinner at the Hotel Merdeka. He is embarrassed
when a waiter insists he be served the last can of American corned beef
left behind by visiting United Nations officials. 
```
