---
identifier: fae01f67
title: Sabam Fires Cameron
date:  
location: 
---

14. Sabam has no choice but to fire Cameron and has his visa canceled,
    effective immediately.
