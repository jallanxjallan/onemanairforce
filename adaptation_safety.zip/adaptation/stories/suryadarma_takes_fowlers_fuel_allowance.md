---
identifier: 56445d58
title: Suryadarma Takes Fowlers Fuel Allowance
date:  
location: 
---

5.  Suryadarma takes away Fowlers fuel allowance. Dave resolves it by
    going over Suryadarma's head, to Hatta.
