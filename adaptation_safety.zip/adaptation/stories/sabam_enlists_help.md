---
identifier: 50b3e03f
title: Sabam Enlists Help
date:  
location: 
---

1.  Sabam enlists Syd's help in crafting stories about government
    corruption that does not offend.
