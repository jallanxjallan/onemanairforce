---
identifier: 0867f7eb
title: CALI Runs
date:  
location: 
---

3.  Muharto negotiates a deal with CALI, an air-charter company based in
    the Philippines, to fly to humanitarian supplies to Jogjakarta. The
    flight lands in the middle of an air show, to the delight of the
    crowd.
4.  Bob Freeberg is the pilot of the third CALI blockade run.
