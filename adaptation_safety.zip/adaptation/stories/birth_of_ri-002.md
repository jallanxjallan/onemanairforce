---
identifier: 44db7f8d
title: Birth of RI-002
date: 9 June 1947 
location: Maguwo
---

``` {.synopsis}
In Jogja, Suradarma commissions Bob to fly a cargo valuable quinine to Manila and return with medicine and other goods. To forestall possible problems with authorities in Manila Muharto suggests that they paint a registration number, RI-002, on the unregistered war-surplus Dakota. 
```

The Dakota lands in Jogjakarta, where Suryadarma commissions Bob to fly
a cargo of high-value quinine to Manila and return with essential
medicines and spare parts. The war-surplus Dakota is still unregistered,
so to forestall potential problems with Philippine authorities, Muharto
suggests that the designation RI-002 be painted on the tail. Bob
protests that since his is the first aircraft registered by Indonesia,
it should be RI-001. Suryadarma explains the RI-001 is being held in
reserve for a future presidential aircraft, which cannot be owned by a
foreigner.
