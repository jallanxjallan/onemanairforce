---
identifier: c525a485
title: Victor Defects.
date:  
location: 
---

8.  Victor defects into hills with friend of Regina.
