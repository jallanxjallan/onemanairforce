---
identifier: ca64aa85
title: Muharto Distressed
date:  
location: 
---

12. Muharto is shocked and saddened when he hears reports that RI-002
    has vanished.
