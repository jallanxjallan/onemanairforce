---
identifier: 5d9ff194
title: Sabam Gets Warning
date:  
location: 
---

4.  Sabam gets last warning from military.
