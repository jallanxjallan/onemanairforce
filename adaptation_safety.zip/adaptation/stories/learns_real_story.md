---
identifier: d5c6e48f
title: Learns Real Story
date:  
location: 
---

9.  In present day, Victor discovers Spoor was investigating corruption,
    not planning a coup.
