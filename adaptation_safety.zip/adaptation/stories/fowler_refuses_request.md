---
identifier: c9f84e67
title: Fowler Refuses Request
date:  
location: 
---

7.  Fowler refuses request from Suryadarma to transport a quarter ton of
    gold to Bukittinggi, thinking the job is too dangerous after his
    near miss with the journalists.
