---
identifier: 8bde9067
title: Promoted to Major
date:  
location: 
---

8.  Suryadarma promotes Muharto to major and assigns him to desk duties
    at Maguwo.
