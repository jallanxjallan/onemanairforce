---
identifier: 861b14c4
title: Buying the Dakota
date:  
location: 
---

4.  Bob Freeberg joins with Bob Walters to purchase a war-surplus
    Dakota.
