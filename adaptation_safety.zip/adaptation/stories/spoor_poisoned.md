---
identifier: e16618e1
title: Spoor poisoned
date:  
location: 
---

12. Spoor dies after a seafood lunch in which his dining companies also
    suffered food poisoning.
