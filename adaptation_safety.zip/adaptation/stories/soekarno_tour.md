---
identifier: 8925b00e
title: Soekarno tour
date: June 1948 
location: RI-002 cockpit
---

``` {.treatment}
Soekarno gives a speech near where RI-002 had landed. Soekarno points to
Bob resting in the shade with Boedi under a wing and says: "Here is a
foreigner, but he is on our side."
```

Soekarno Tour props up support for the independence struggle and to
raise money to purchase a presidential aircraft, to be named RI-001.

``` {.treatment}
During the Soekarno Tour, Bob refuses Soekarno's order to land on what Bob judged to be an unsafe runway. Soekarno insists, saying: "To as I say. I'm the president!" Bob replies, in a measured tone: "Indeed, sir. Down there you are the president. But up here, I'm the captain." 
```

Bob flies low over a town where an important regional leader lives to
determine whether he can land RI-002 safely on an overgrown grass
airstrip. Bob decides not to risk the safety of his passengers, which
infuriates Soekarno. He demands that Bob land on the strip, declaring:
"I'm the president!" Bob replies, pointing downward: "Down there, sir,
indeed you are the president. But up here, I'm the captain."
