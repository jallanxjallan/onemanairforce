---
identifier: 0c28fe75
title: Unequal Friendship
date:  
location: 
---

6.  Reveal that Bob never mentioned Muharto by name. Cameron receives
    Freeberg letters from family. Freeberg never mentioned Muharto.
    learns that, despite his view as being Freeberg's close friend, Bob
    never mentions him or the other Indonesian crew. Only casually as:
    âMy boysâ
