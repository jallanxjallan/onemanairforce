---
identifier: 59061c8d
title: SE Airlines
date:  
location: 
---

2.  Bob partners with Hugh Savage, a Singapore-based expat to start
    Southeastern Airlines.
