---
identifier: 4ab05089
title: Ining Flirts
date:  
location: 
---

3.  Ining kisses teenage daughter of American pilot. At the party to
    celebrate the sale of the quinine and their return to Java. Freeberg
    and Boedi have to hustle him out of the bar.
