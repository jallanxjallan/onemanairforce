---
identifier: 78237304
title: Muharto Wants To Decline
date:  
location: 
---

6.  Muharto wants to decline promotion and keep flying because he is
    worried about Bob, and saddened about the Smuggled Gems incident.
    But Ani insists that he take a safe desk job.
