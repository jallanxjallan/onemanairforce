---
identifier: 6d170c07
title: Cameron Keeps Pestering
date: 27 September 1988 
location: Jakarta Post
---

``` {.synopsis}
Sabam Siagian, managing editor of the Jakarta Post, assigns Cameron, a
young American recently hired as a copy editor, to interview his friend
Petit Muharto about his experiences running the Dutch blockade with Bob
Freeberg.
```
