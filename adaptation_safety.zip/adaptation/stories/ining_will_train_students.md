---
identifier: 15f26301
title: Ining Will Train Students
date:  
location: 
---

4.  Muharto moves Ining into a house on the slopes of Mount Merapi. it
    is next next to the forest where Ining will train students to become
    guerrilla fighters. They toast the occasion with whiskey brought
    from Manila.
