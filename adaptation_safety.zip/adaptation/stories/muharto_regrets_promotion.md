---
identifier: 1974c32b
title: Muharto regrets promotion
date:  
location: 
---

9.  Cameron repeats muharto claim about regretting promotion.
