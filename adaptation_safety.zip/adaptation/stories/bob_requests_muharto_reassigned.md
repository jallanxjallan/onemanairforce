---
identifier: 3c27f0df
title: Bob Requests Muharto Reassigned
date:  
location: 
---

13. In present day, Muharto learns that Bob had requested he be
    reassigned.
