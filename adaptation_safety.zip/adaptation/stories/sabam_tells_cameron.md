---
identifier: c7f40939
title: Sabam Tells Cameron
date:  
location: 
---

5.  Sabam tells Cameron that Muharto was delighted with the story.
