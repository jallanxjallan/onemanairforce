---
identifier: 223cf54d
title: Reconciling With Muharto.
date:  
location: 
---

10. Boedi talks Bob into reconciling with Muharto.
