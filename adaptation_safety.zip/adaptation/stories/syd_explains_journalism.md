---
identifier: ab1b7d1e
title: Syd Explains Journalism
date:  
location: 
---

5.  Syd explains journalism in Indonesia like walking a tightrope,\" Syd
    says, "and I'm the safety net."
