---
identifier: 5ded3bf3
title: Assigned to Westerling
date:  
location: 
---

6.  Spoor assigns Victor to Westerling.
7.  Victor watches Ani berate Westerling.
