---
identifier: f10b8796
title: Sabam Furious
date:  
location: 
---

12. Sabam is furious at Cameron for interviewing Tahija without
    authorization.
