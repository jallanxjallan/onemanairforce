---
identifier: 39b5db29
title: Muharto Reports Incident
date:  
location: 
---

8.  Muharto reports the incident to Major Primitivo, who accuses Muharto
    of being a communist and Mas Ded being complicit in Ining âs
    death.
