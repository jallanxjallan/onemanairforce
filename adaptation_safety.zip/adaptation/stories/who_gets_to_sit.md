---
identifier: c64fde69
title: Who Gets To Sit
date:  
location: 
---

6.  Muharto and Bambang argue over who gets to sit in the right-hand
    seat. Muharto says it is his right as mission leader. Bambang
    rejoins that Muharto cannot actually fly. Bob and Boedi exchange wry
    glances as the two spat.
