---
identifier: ec73ad7e
title: Ri-002 Drops Leaflets
date:  
location: 
---

15. RI-002 drops leaflets over Madiun. Santoso is valuable in pointing
    out neighborhoods where residents may be receptive to message from
    government to stay loyal to the Republic.
