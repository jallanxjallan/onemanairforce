---
identifier: dfa76318
title: Suryadarma Takes Fuel Allowance
date:  
location: 
---

    Suryadarma  takes away Bob's fuel allowance. 
